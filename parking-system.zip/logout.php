<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Registrar logout
if (isset($_SESSION['user_id'])) {
    try {
        logActivity($_SESSION['user_id'], 'logout', 'Logout do sistema');
    } catch (Exception $e) {
        // Ignora erro de log para permitir o logout
    }
}

// Destruir sessão
session_unset();
session_destroy();

// Redirecionar para login
header('Location: login.php');
exit;
?>

