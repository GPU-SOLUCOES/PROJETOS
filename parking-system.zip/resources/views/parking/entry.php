<?php include(resource_path('views/layouts/header.php')); ?>

<div class="container-fluid py-4">
    <h1 class="h3 mb-2 text-gray-800">Entrada de Veículo</h1>
    <p class="mb-4">Preencha os dados abaixo para registrar a entrada de um veículo</p>
    
    <!-- Alertas -->
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo session('error'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Dados do Veículo</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo route('parking.entry.post'); ?>" method="POST" id="entryForm">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="proprietario" class="form-label">Nome do Proprietário</label>
                                <input type="text" class="form-control <?php echo $errors->has('proprietario') ? 'is-invalid' : ''; ?>" 
                                       id="proprietario" name="proprietario" value="<?php echo old('proprietario'); ?>" required>
                                <?php if($errors->has('proprietario')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('proprietario'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="documento" class="form-label">Documento (CPF/RG)</label>
                                <input type="text" class="form-control <?php echo $errors->has('documento') ? 'is-invalid' : ''; ?>" 
                                       id="documento" name="documento" value="<?php echo old('documento'); ?>" required>
                                <?php if($errors->has('documento')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('documento'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="modelo" class="form-label">Modelo do Veículo</label>
                                <input type="text" class="form-control <?php echo $errors->has('modelo') ? 'is-invalid' : ''; ?>" 
                                       id="modelo" name="modelo" value="<?php echo old('modelo'); ?>" required>
                                <?php if($errors->has('modelo')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('modelo'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="cor" class="form-label">Cor</label>
                                <input type="text" class="form-control <?php echo $errors->has('cor') ? 'is-invalid' : ''; ?>" 
                                       id="cor" name="cor" value="<?php echo old('cor'); ?>" required>
                                <?php if($errors->has('cor')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('cor'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="placa" class="form-label">Placa</label>
                                <input type="text" class="form-control <?php echo $errors->has('placa') ? 'is-invalid' : ''; ?>" 
                                       id="placa" name="placa" value="<?php echo old('placa'); ?>" 
                                       placeholder="AAA-1234 ou AAA1A23" required>
                                <?php if($errors->has('placa')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('placa'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="estacionamento_id" class="form-label">Estacionamento</label>
                                <select class="form-select <?php echo $errors->has('estacionamento_id') ? 'is-invalid' : ''; ?>" 
                                        id="estacionamento_id" name="estacionamento_id" required>
                                    <option value="">Selecione um estacionamento</option>
                                    <?php foreach($estacionamentos as $estacionamento): ?>
                                        <option value="<?php echo $estacionamento->id; ?>" <?php echo old('estacionamento_id') == $estacionamento->id ? 'selected' : ''; ?>>
                                            <?php echo $estacionamento->nome; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if($errors->has('estacionamento_id')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('estacionamento_id'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="servico_id" class="form-label">Tipo de Serviço</label>
                            <select class="form-select <?php echo $errors->has('servico_id') ? 'is-invalid' : ''; ?>" 
                                    id="servico_id" name="servico_id" required disabled>
                                <option value="">Selecione um tipo de serviço</option>
                            </select>
                            <?php if($errors->has('servico_id')): ?>
                            <div class="invalid-feedback">
                                <?php echo $errors->first('servico_id'); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex justify-content-end mt-4">
                            <a href="<?php echo route('dashboard'); ?>" class="btn btn-secondary me-2">
                                <i class="fas fa-times me-1"></i> Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary" id="btnSubmit">
                                <i class="fas fa-check me-1"></i> Registrar Entrada
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informações</h6>
                </div>
                <div class="card-body">
                    <div id="parkingInfo" class="d-none">
                        <div class="bg-light rounded p-3 mb-3">
                            <h6 class="font-weight-bold">Vagas disponíveis</h6>
                            <div class="h3 mb-0 font-weight-bold text-gray-800" id="vagasDisponiveis">-</div>
                            <div id="semVagas" class="text-danger mt-2 d-none">
                                <i class="fas fa-exclamation-circle me-1"></i> Não há vagas disponíveis no momento.
                            </div>
                        </div>
                        
                        <div id="servicosInfo" class="d-none">
                            <h6 class="font-weight-bold mb-2">Tipos de Serviço</h6>
                            <ul class="list-group" id="servicosList">
                                <!-- Lista de serviços será preenchida via JavaScript -->
                            </ul>
                        </div>
                    </div>
                    
                    <div id="parkingInfoEmpty">
                        <p class="text-muted">
                            Selecione um estacionamento para ver informações.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const estacionamentoSelect = document.getElementById('estacionamento_id');
        const servicoSelect = document.getElementById('servico_id');
        const parkingInfo = document.getElementById('parkingInfo');
        const parkingInfoEmpty = document.getElementById('parkingInfoEmpty');
        const vagasDisponiveis = document.getElementById('vagasDisponiveis');
        const semVagas = document.getElementById('semVagas');
        const servicosInfo = document.getElementById('servicosInfo');
        const servicosList = document.getElementById('servicosList');
        const btnSubmit = document.getElementById('btnSubmit');
        const placaInput = document.getElementById('placa');
        
        // Formatar placa automaticamente
        placaInput.addEventListener('input', function(e) {
            let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            
            if (value.length <= 7) {
                if (value.length > 3) {
                    value = value.substring(0, 3) + '-' + value.substring(3);
                }
            }
            
            e.target.value = value;
        });
        
        // Carregar serviços quando o estacionamento for selecionado
        estacionamentoSelect.addEventListener('change', function() {
            const estacionamentoId = this.value;
            
            if (estacionamentoId) {
                // Mostrar informações do estacionamento
                parkingInfo.classList.remove('d-none');
                parkingInfoEmpty.classList.add('d-none');
                
                // Carregar informações do estacionamento
                fetch(`/api/parking-lots/${estacionamentoId}/info`)
                    .then(response => response.json())
                    .then(data => {
                        vagasDisponiveis.textContent = data.vagasDisponiveis;
                        
                        if (data.vagasDisponiveis > 0) {
                            semVagas.classList.add('d-none');
                            btnSubmit.disabled = false;
                        } else {
                            semVagas.classList.remove('d-none');
                            btnSubmit.disabled = true;
                        }
                    });
                
                // Carregar serviços
                servicoSelect.disabled = true;
                servicoSelect.innerHTML = '<option value="">Carregando...</option>';
                
                fetch(`/api/parking-lots/${estacionamentoId}/services`)
                    .then(response => response.json())
                    .then(data => {
                        servicoSelect.innerHTML = '<option value="">Selecione um tipo de serviço</option>';
                        
                        if (data.length > 0) {
                            data.forEach(servico => {
                                const option = document.createElement('option');
                                option.value = servico.id;
                                
                                if (servico.tipo === 'hora') {
                                    option.textContent = `Hora - R$ ${parseFloat(servico.valor).toFixed(2).replace('.', ',')}/hora`;
                                } else if (servico.tipo === 'diaria') {
                                    option.textContent = `Diária - R$ ${parseFloat(servico.valor).toFixed(2).replace('.', ',')}/dia`;
                                } else {
                                    option.textContent = 'Mensalista';
                                }
                                
                                servicoSelect.appendChild(option);
                            });
                            
                            // Preencher lista de serviços na coluna de informações
                            servicosInfo.classList.remove('d-none');
                            servicosList.innerHTML = '';
                            
                            data.forEach(servico => {
                                const li = document.createElement('li');
                                li.className = 'list-group-item d-flex justify-content-between align-items-center';
                                
                                const tipoSpan = document.createElement('span');
                                tipoSpan.className = 'fw-bold';
                                
                                if (servico.tipo === 'hora') {
                                    tipoSpan.textContent = 'Hora';
                                } else if (servico.tipo === 'diaria') {
                                    tipoSpan.textContent = 'Diária';
                                } else {
                                    tipoSpan.textContent = 'Mensalista';
                                }
                                
                                const valorSpan = document.createElement('span');
                                valorSpan.className = 'badge bg-primary rounded-pill';
                                
                                if (servico.tipo === 'hora') {
                                    valorSpan.textContent = `R$ ${parseFloat(servico.valor).toFixed(2).replace('.', ',')}/hora`;
                                } else if (servico.tipo === 'diaria') {
                                    valorSpan.textContent = `R$ ${parseFloat(servico.valor).toFixed(2).replace('.', ',')}/dia`;
                                } else {
                                    valorSpan.textContent = 'Mensalista';
                                }
                                
                                li.appendChild(tipoSpan);
                                li.appendChild(valorSpan);
                                servicosList.appendChild(li);
                            });
                        }
                        
                        servicoSelect.disabled = false;
                    });
            } else {
                // Esconder informações do estacionamento
                parkingInfo.classList.add('d-none');
                parkingInfoEmpty.classList.remove('d-none');
                
                // Limpar e desabilitar select de serviços
                servicoSelect.innerHTML = '<option value="">Selecione um tipo de serviço</option>';
                servicoSelect.disabled = true;
            }
        });
        
        // Verificar se já existe um estacionamento selecionado (em caso de erro de validação)
        if (estacionamentoSelect.value) {
            estacionamentoSelect.dispatchEvent(new Event('change'));
        }
    });
</script>

<?php include(resource_path('views/layouts/footer.php')); ?>

