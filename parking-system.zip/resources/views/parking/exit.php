<?php include(resource_path('views/layouts/header.php')); ?>

<div class="container-fluid py-4">
    <h1 class="h3 mb-2 text-gray-800">Saída de Veículo</h1>
    <p class="mb-4">Registre a saída do veículo e efetue o pagamento</p>
    
    <!-- Alertas -->
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo session('error'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-light">
                    <h6 class="m-0 font-weight-bold text-primary">Dados do Veículo</h6>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Proprietário</h6>
                            <p class="mb-3"><?php echo $registro->veiculo->proprietario; ?></p>
                            
                            <h6 class="text-muted mb-1">Documento</h6>
                            <p class="mb-3"><?php echo $registro->veiculo->documento; ?></p>
                            
                            <h6 class="text-muted mb-1">Veículo</h6>
                            <p class="mb-3"><?php echo $registro->veiculo->modelo; ?> / <?php echo $registro->veiculo->cor; ?></p>
                            
                            <h6 class="text-muted mb-1">Placa</h6>
                            <p class="mb-0"><?php echo $registro->veiculo->placa; ?></p>
                        </div>
                        
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Estacionamento</h6>
                            <p class="mb-3"><?php echo $registro->estacionamento->nome; ?></p>
                            
                            <h6 class="text-muted mb-1">Entrada</h6>
                            <p class="mb-3"><?php echo Carbon\Carbon::parse($registro->data_entrada)->format('d/m/Y H:i:s'); ?></p>
                            
                            <h6 class="text-muted mb-1">Permanência</h6>
                            <p class="mb-3"><?php echo $diffHoras; ?>h <?php echo $diffMinutos; ?>min</p>
                            
                            <h6 class="text-muted mb-1">Tipo de Serviço</h6>
                            <?php if($registro->servico->tipo === 'hora'): ?>
                                <span class="badge bg-secondary">Hora</span>
                            <?php elseif($registro->servico->tipo === 'diaria'): ?>
                                <span class="badge bg-primary">Diária</span>
                            <?php else: ?>
                                <span class="badge bg-light text-dark">Mensalista</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <hr class="my-4">
                    
                    <form action="<?php echo route('parking.exit.post', ['id' => $registro->id]); ?>" method="POST" id="exitForm">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="valor_pago" class="form-label">Valor a Pagar</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control <?php echo $errors->has('valor_pago') ? 'is-invalid' : ''; ?>" 
                                           id="valor_pago" name="valor_pago" value="<?php echo number_format($valorPagar, 2, ',', '.'); ?>" 
                                           <?php echo $registro->servico->tipo === 'mensalista' ? 'readonly' : ''; ?> required>
                                    <?php if($errors->has('valor_pago')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo $errors->first('valor_pago'); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if($registro->servico->tipo === 'mensalista'): ?>
                                <small class="text-muted">Cliente mensalista - não há cobrança.</small>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="forma_pagamento" class="form-label">Forma de Pagamento</label>
                                <select class="form-select <?php echo $errors->has('forma_pagamento') ? 'is-invalid' : ''; ?>" 
                                        id="forma_pagamento" name="forma_pagamento" required>
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                    <option value="pix">PIX</option>
                                    <?php if($registro->servico->tipo === 'mensalista'): ?>
                                    <option value="mensalidade">Mensalidade</option>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('forma_pagamento')): ?>
                                <div class="invalid-feedback">
                                    <?php echo $errors->first('forma_pagamento'); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div id="trocoContainer" class="row mb-3 d-none">
                            <div class="col-md-6">
                                <label for="valor_recebido" class="form-label">Valor Recebido</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="valor_recebido" name="valor_recebido">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="troco" class="form-label">Troco</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="troco" readonly>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end mt-4">
                            <a href="<?php echo route('dashboard'); ?>" class="btn btn-secondary me-2">
                                <i class="fas fa-times me-1"></i> Cancelar
                            </a>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-check me-1"></i> Confirmar Saída
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Resumo</h6>
                </div>
                <div class="card-body">
                    <div class="bg-light rounded p-3 mb-4">
                        <h6 class="font-weight-bold mb-3">Detalhes do Pagamento</h6>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Tempo de Permanência:</span>
                            <span><?php echo $diffHoras; ?>h <?php echo $diffMinutos; ?>min</span>
                        </div>
                        
                        <?php if($registro->servico->tipo === 'hora'): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Valor por Hora:</span>
                                <span>R$ <?php echo number_format($registro->servico->valor, 2, ',', '.'); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Horas Cobradas:</span>
                                <span><?php echo ceil($totalMinutos / 60); ?></span>
                            </div>
                        <?php elseif($registro->servico->tipo === 'diaria'): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Valor da Diária:</span>
                                <span>R$ <?php echo number_format($registro->servico->valor, 2, ',', '.'); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-content-between font-weight-bold mt-2 pt-2 border-top">
                            <span>Total a Pagar:</span>
                            <span>R$ <?php echo number_format($valorPagar, 2, ',', '.'); ?></span>
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-outline-primary w-100" id="btnPrint">
                        <i class="fas fa-print me-2"></i> Imprimir Recibo
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const formaPagamentoSelect = document.getElementById('forma_pagamento');
        const trocoContainer = document.getElementById('trocoContainer');
        const valorPagoInput = document.getElementById('valor_pago');
        const valorRecebidoInput = document.getElementById('valor_recebido');
        const trocoInput = document.getElementById('troco');
        const btnPrint = document.getElementById('btnPrint');
        
        // Formatar valor pago
        valorPagoInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (parseInt(value) / 100).toFixed(2).replace('.', ',');
            e.target.value = value;
        });
        
        // Formatar valor recebido
        valorRecebidoInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (parseInt(value) / 100).toFixed(2).replace('.', ',');
            e.target.value = value;
            
            // Calcular troco
            const valorPago = parseFloat(valorPagoInput.value.replace(',', '.')) || 0;
            const valorRecebido = parseFloat(value.replace(',', '.')) || 0;
            
            if (valorRecebido >= valorPago) {
                const troco = valorRecebido - valorPago;
                trocoInput.value = troco.toFixed(2).replace('.', ',');
            } else {
                trocoInput.value = '0,00';
            }
        });
        
        // Mostrar/esconder campo de troco
        formaPagamentoSelect.addEventListener('change', function() {
            if (this.value === 'dinheiro') {
                trocoContainer.classList.remove('d-none');
            } else {
                trocoContainer.classList.add('d-none');
            }
        });
        
        // Imprimir recibo
        btnPrint.addEventListener('click', function() {
            window.print();
        });
    });
</script>

<?  function() {
            window.print();
        });
    });
</script>

<?php include(resource_path('views/layouts/footer.php')); ?>

