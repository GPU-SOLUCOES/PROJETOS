<?php include(resource_path('views/layouts/header.php')); ?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <p class="mb-0 text-muted">Estacionamento: <?php echo $estacionamentoAtual->nome; ?></p>
        </div>
        
        <div class="d-flex align-items-center">
            <form action="<?php echo route('dashboard'); ?>" method="GET" class="me-2">
                <div class="input-group">
                    <select name="estacionamento_id" class="form-select" onchange="this.form.submit()">
                        <?php foreach ($estacionamentos as $estacionamento): ?>
                            <option value="<?php echo $estacionamento->id; ?>" <?php echo $estacionamento->id == $estacionamentoAtual->id ? 'selected' : ''; ?>>
                                <?php echo $estacionamento->nome; ?>
                                <?php if (Auth::user()->tipo_acesso === 'super_admin' && $estacionamento->cliente): ?>
                                    (<?php echo $estacionamento->cliente->nome; ?>)
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-outline-secondary" type="submit">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Alertas -->
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i> <?php echo session('success'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo session('error'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php endif; ?>
    
    <!-- Cards de Estatísticas -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Vagas Disponíveis</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $vagasDisponiveis; ?></div>
                            <div class="text-xs text-muted">de <?php echo $estacionamentoAtual->capacidade; ?> vagas totais</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-parking fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Taxa de Ocupação</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($taxaOcupacao, 1); ?>%</div>
                            <div class="text-xs text-muted"><?php echo $estacionamentoAtual->capacidade - $vagasDisponiveis; ?> vagas ocupadas</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-percentage fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Entradas Hoje</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $entradasHoje; ?></div>
                            <div class="text-xs text-muted">veículos registrados hoje</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-car fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Faturamento Hoje</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">R$ <?php echo number_format($faturamentoHoje, 2, ',', '.'); ?></div>
                            <div class="text-xs text-muted">valor total recebido hoje</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Botão Nova Entrada -->
    <div class="mb-4">
        <a href="<?php echo route('parking.entry'); ?>" class="btn btn-primary">
            <i class="fas fa-plus-circle me-2"></i> Nova Entrada de Veículo
        </a>
    </div>
    
    <!-- Gráficos -->
    <div class="row">
        <!-- Gráfico de Ocupação por Hora -->
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Ocupação por Hora</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="occupancyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gráfico de Receita dos Últimos 7 Dias -->
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Receita dos Últimos 7 Dias</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tabela de Veículos Estacionados -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Veículos Estacionados</h6>
            <div class="input-group w-25">
                <input type="text" class="form-control" id="searchVehicle" placeholder="Buscar veículo...">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
            </div>
        </div>
        <div class="card-body">
            <?php if(count($veiculosEstacionadosDetalhes) === 0): ?>
                <div class="text-center py-5">
                    <p class="text-muted">Não há veículos estacionados no momento.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered" id="vehiclesTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Placa</th>
                                <th>Modelo/Cor</th>
                                <th>Proprietário</th>
                                <th>Entrada</th>
                                <th>Permanência</th>
                                <th>Tipo</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($veiculosEstacionadosDetalhes as $registro): ?>
                                <tr>
                                    <td class="font-weight-bold"><?php echo $registro->veiculo->placa; ?></td>
                                    <td><?php echo $registro->veiculo->modelo; ?> / <?php echo $registro->veiculo->cor; ?></td>
                                    <td><?php echo $registro->veiculo->proprietario; ?></td>
                                    <td><?php echo Carbon\Carbon::parse($registro->data_entrada)->format('d/m/Y H:i:s'); ?></td>
                                    <td>
                                        <?php 
                                            $entrada = Carbon\Carbon::parse($registro->data_entrada);
                                            $agora = Carbon\Carbon::now();
                                            $diff = $entrada->diff($agora);
                                            echo $diff->h . 'h ' . $diff->i . 'min';
                                        ?>
                                    </td>
                                    <td>
                                        <?php if($registro->servico->tipo === 'hora'): ?>
                                            <span class="badge bg-secondary">Hora</span>
                                        <?php elseif($registro->servico->tipo === 'diaria'): ?>
                                            <span class="badge bg-primary">Diária</span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-dark">Mensalista</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo route('parking.exit', ['id' => $registro->id]); ?>" class="btn btn-danger btn-sm">
                                            <i class="fas fa-sign-out-alt me-1"></i> Saída
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Scripts para os gráficos -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Dados para o gráfico de ocupação
    const occupancyData = <?php echo json_encode($dadosOcupacao); ?>;
    const occupancyLabels = occupancyData.map(item => item.hora);
    const occupancyValues = occupancyData.map(item => item.ocupacao);
    
    // Dados para o gráfico de receita
    const revenueData = <?php echo json_encode($dadosReceita); ?>;
    const revenueLabels = revenueData.map(item => item.data);
    const revenueValues = revenueData.map(item => item.total);
    
    // Configurar gráfico de ocupação
    const occupancyCtx = document.getElementById('occupancyChart').getContext('2d');
    const occupancyChart = new Chart(occupancyCtx, {
        type: 'bar',
        data: {
            labels: occupancyLabels,
            datasets: [{
                label: 'Taxa de Ocupação (%)',
                data: occupancyValues,
                backgroundColor: 'rgba(78, 115, 223, 0.7)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.raw + '%';
                        }
                    }
                }
            }
        }
    });
    
    // Configurar gráfico de receita
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: revenueLabels,
            datasets: [{
                label: 'Receita (R$)',
                data: revenueValues,
                backgroundColor: 'rgba(28, 200, 138, 0.1)',
                borderColor: 'rgba(28, 200, 138, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(28, 200, 138, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toFixed(2).replace('.', ',');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': R$ ' + context.raw.toFixed(2).replace('.', ',');
                        }
                    }
                }
            }
        }
    });
    
    // Filtro para tabela de veículos
    document.getElementById('searchVehicle').addEventListener('keyup', function() {
        const searchValue = this.value.toLowerCase();
        const table = document.getElementById('vehiclesTable');
        const rows = table.getElementsByTagName('tr');
        
        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const cells = row.getElementsByTagName('td');
            let found = false;
            
            for (let j = 0; j < cells.length; j++) {
                const cellText = cells[j].textContent.toLowerCase();
                if (cellText.indexOf(searchValue) > -1) {
                    found = true;
                    break;
                }
            }
            
            row.style.display = found ? '' : 'none';
        }
    });
</script>

<?php include(resource_path('views/layouts/footer.php')); ?>

