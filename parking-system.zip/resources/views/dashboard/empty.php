<?php include(resource_path('views/layouts/header.php')); ?>

<div class="container-fluid py-4">
    <div class="text-center py-5">
        <div class="mb-4">
            <i class="fas fa-parking fa-5x text-muted"></i>
        </div>
        <h2 class="h4 mb-3">Nenhum estacionamento disponível</h2>
        <p class="text-muted mb-4">
            Você não possui estacionamentos cadastrados ou não tem permissão para acessá-los.
        </p>
        
        <?php if(Auth::user()->tipo_acesso === 'admin' || Auth::user()->tipo_acesso === 'super_admin'): ?>
            <a href="<?php echo route('admin.estacionamentos.create'); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle me-2"></i> Cadastrar Estacionamento
            </a>
        <?php endif; ?>
    </div>
</div>

<?php include(resource_path('views/layouts/footer.php')); ?>

