<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão de Estacionamentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --info-color: #3498db;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar {
            min-width: 250px;
            max-width: 250px;
            background-color: var(--secondary-color);
            color: white;
            min-height: calc(100vh - 56px);
            transition: all 0.3s;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.25rem;
            border-radius: 0.25rem;
            margin: 0.2rem 0.5rem;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .sidebar .nav-link.active {
            color: white;
            background-color: var(--primary-color);
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-heading {
            padding: 0.75rem 1rem;
            font-size: 0.75rem;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.5);
        }
        
        .content {
            flex: 1;
            width: 100%;
        }
        
        .navbar {
            background-color: white;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        
        .navbar-brand {
            font-weight: 600;
            color: var(--secondary-color);
        }
        
        .navbar-toggler {
            border: none;
        }
        
        .dropdown-menu {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            border: none;
        }
        
        .dropdown-item {
            padding: 0.5rem 1.5rem;
        }
        
        .dropdown-item:hover {
            background-color: rgba(52, 152, 219, 0.1);
        }
        
        .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        .card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            padding: 1rem 1.25rem;
        }
        
        .border-left-primary {
            border-left: 0.25rem solid var(--primary-color) !important;
        }
        
        .border-left-success {
            border-left: 0.25rem solid var(--success-color) !important;
        }
        
        .border-left-info {
            border-left: 0.25rem solid var(--info-color) !important;
        }
        
        .border-left-warning {
            border-left: 0.25rem solid var(--warning-color) !important;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            border-color: var(--danger-color);
        }
        
        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }
        
        .text-primary {
            color: var(--primary-color) !important;
        }
        
        .text-success {
            color: var(--success-color) !important;
        }
        
        .text-warning {
            color: var(--warning-color) !important;
        }
        
        .text-danger {
            color: var(--danger-color) !important;
        }
        
        .text-info {
            color: var(--info-color) !important;
        }
        
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        
        @media (max-width: 991.98px) {
            .sidebar {
                margin-left: -250px;
                position: fixed;
                top: 56px;
                left: 0;
                height: calc(100vh - 56px);
                z-index: 1000;
                overflow-y: auto;
            }
            
            .sidebar.show {
                margin-left: 0;
            }
            
            .content {
                width: 100%;
            }
        }
        
        @media print {
            .sidebar, .navbar, .btn, .no-print {
                display: none !important;
            }
            
            .content {
                margin: 0 !important;
                padding: 0 !important;
            }
            
            .card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container-fluid">
            <button class="navbar-toggler me-2" type="button" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?php echo route('dashboard'); ?>">
                <i class="fas fa-parking me-2"></i>
                Sistema de Estacionamentos
            </a>
            
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="d-none d-lg-inline text-gray-600 me-2"><?php echo Auth::user()->nome; ?></span>
                        <img class="img-profile rounded-circle" src="https://ui-avatars.com/api/?name=<?php echo urlencode(Auth::user()->nome); ?>&background=random" width="32" height="32">
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li>
                            <span class="dropdown-item-text">
                                <strong><?php echo Auth::user()->nome; ?></strong><br>
                                <small class="text-muted"><?php echo Auth::user()->email; ?></small>
                            </span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo route('profile'); ?>"><i class="fas fa-user"></i> Perfil</a></li>
                        <li><a class="dropdown-item" href="<?php echo route('settings'); ?>"><i class="fas fa-cog"></i> Configurações</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item text-danger" href="<?php echo route('logout'); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt"></i> Sair
                            </a>
                            <form id="logout-form" action="<?php echo route('logout'); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="py-4">
                <div class="sidebar-heading">
                    Principal
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('dashboard') ? 'active' : ''; ?>" href="<?php echo route('dashboard'); ?>">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('parking.entry') ? 'active' : ''; ?>" href="<?php echo route('parking.entry'); ?>">
                            <i class="fas fa-car"></i> Entrada de Veículo
                        </a>
                    </li>
                </ul>
                
                <?php if(Auth::user()->tipo_acesso === 'admin' || Auth::user()->tipo_acesso === 'gerente' || Auth::user()->tipo_acesso === 'super_admin'): ?>
                <div class="sidebar-heading mt-3">
                    Administração
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('admin.estacionamentos.*') ? 'active' : ''; ?>" href="<?php echo route('admin.estacionamentos.index'); ?>">
                            <i class="fas fa-parking"></i> Estacionamentos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('admin.servicos.*') ? 'active' : ''; ?>" href="<?php echo route('admin.servicos.index'); ?>">
                            <i class="fas fa-tags"></i> Serviços
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('admin.usuarios.*') ? 'active' : ''; ?>" href="<?php echo route('admin.usuarios.index'); ?>">
                            <i class="fas fa-users"></i> Usuários
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('admin.relatorios.*') ? 'active' : ''; ?>" href="<?php echo route('admin.relatorios.index'); ?>">
                            <i class="fas fa-chart-bar"></i> Relatórios
                        </a>
                    </li>
                </ul>
                <?php endif; ?>
                
                <?php if(Auth::user()->tipo_acesso === 'super_admin'): ?>
                <div class="sidebar-heading mt-3">
                    Super Admin
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('super_admin.dashboard') ? 'active' : ''; ?>" href="<?php echo route('super_admin.dashboard'); ?>">
                            <i class="fas fa-chart-line"></i> Dashboard Financeiro
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('super_admin.clientes.*') ? 'active' : ''; ?>" href="<?php echo route('super_admin.clientes.index'); ?>">
                            <i class="fas fa-building"></i> Gerenciar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('super_admin.pagamentos.*') ? 'active' : ''; ?>" href="<?php echo route('super_admin.pagamentos.index'); ?>">
                            <i class="fas fa-credit-card"></i> Pagamentos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo request()->routeIs('super_admin.notificacoes.*') ? 'active' : ''; ?>" href="<?php echo route('super_admin.notificacoes.index'); ?>">
                            <i class="fas fa-bell"></i> Notificações
                        </a>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Content -->
        <div class="content">

