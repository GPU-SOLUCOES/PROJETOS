<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Gestão de Estacionamentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --info-color: #3498db;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            height: 100vh;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        .login-container {
            height: 100vh;
            background-image: url('<?php echo asset("assets/images/parking-background.jpg"); ?>');
            background-size: cover;
            background-position: center;
            position: relative;
        }
        
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to right, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5));
            z-index: 1;
        }
        
        .login-content {
            position: relative;
            z-index: 2;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-row {
            width: 100%;
            max-width: 1200px;
        }
        
        .welcome-text {
            color: white;
            padding: 2rem;
        }
        
        .welcome-text h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }
        
        .welcome-text p {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        
        .login-card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            padding: 2rem;
            backdrop-filter: blur(10px);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-icon {
            width: 70px;
            height: 70px;
            background-color: rgba(52, 152, 219, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
        }
        
        .login-icon i {
            font-size: 30px;
            color: var(--primary-color);
        }
        
        .login-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .login-subtitle {
            color: #6c757d;
            font-size: 0.95rem;
        }
        
        .form-floating {
            margin-bottom: 1.25rem;
        }
        
        .form-floating .form-control {
            padding-left: 2.5rem;
            height: calc(3.5rem + 2px);
            border-radius: 8px;
            border: 1px solid #ced4da;
        }
        
        .form-floating label {
            padding-left: 2.5rem;
        }
        
        .input-icon {
            position: absolute;
            top: 50%;
            left: 0.75rem;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 2;
        }
        
        .btn-login {
            background-color: var(--primary-color);
            border: none;
            border-radius: 8px;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }
        
        .alert {
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.1);
            border-color: rgba(231, 76, 60, 0.2);
            color: #c0392b;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.1);
            border-color: rgba(46, 204, 113, 0.2);
            color: #27ae60;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        @media (max-width: 991.98px) {
            .welcome-text {
                display: none;
            }
            
            .login-card {
                margin: 0 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="overlay"></div>
        <div class="login-content">
            <div class="container">
                <div class="row login-row">
                    <!-- Texto de boas-vindas (visível apenas em telas maiores) -->
                    <div class="col-lg-6 welcome-text d-none d-lg-block">
                        <h1>Gestão Inteligente de Estacionamentos</h1>
                        <p>Controle total do seu estacionamento com tecnologia avançada e interface intuitiva. Monitore vagas, registre entradas e saídas, e gerencie seus clientes em um único sistema.</p>
                    </div>
                    
                    <!-- Formulário de login -->
                    <div class="col-lg-6">
                        <div class="login-card">
                            <div class="login-header">
                                <div class="login-icon">
                                    <i class="fas fa-parking"></i>
                                </div>
                                <h2 class="login-title">Acesso ao Sistema</h2>
                                <p class="login-subtitle">Entre com suas credenciais para continuar</p>
                            </div>
                            
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <?php echo session('error'); ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if(session('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <i class="fas fa-check-circle me-2"></i>
                                <?php echo session('success'); ?>
                            </div>
                            <?php endif; ?>
                            
                            <form action="<?php echo route('login.post'); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-floating mb-3">
                                    <span class="input-icon">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control <?php echo $errors->has('email') ? 'is-invalid' : ''; ?>" 
                                           id="email" name="email" placeholder="nome@exemplo.com" 
                                           value="<?php echo old('email'); ?>" required autofocus>
                                    <label for="email">Email</label>
                                    <?php if($errors->has('email')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo $errors->first('email'); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-floating mb-4">
                                    <span class="input-icon">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control <?php echo $errors->has('password') ? 'is-invalid' : ''; ?>" 
                                           id="password" name="password" placeholder="Senha" required>
                                    <label for="password">Senha</label>
                                    <?php if($errors->has('password')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo $errors->first('password'); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                    <label class="form-check-label" for="remember">
                                        Lembrar-me
                                    </label>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-login w-100">
                                    <i class="fas fa-sign-in-alt me-2"></i> Entrar
                                </button>
                            </form>
                            
                            <div class="login-footer">
                                <p>&copy; <?php echo date('Y'); ?> Sistema de Gestão de Estacionamentos</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Esconder alertas após 5 segundos
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html>

