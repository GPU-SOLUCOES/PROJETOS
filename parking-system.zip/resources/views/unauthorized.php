<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso Não Autorizado - Sistema de Gestão de Estacionamentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .unauthorized-container {
            max-width: 600px;
            padding: 2rem;
            text-align: center;
        }
        
        .unauthorized-icon {
            font-size: 5rem;
            color: #e74c3c;
            margin-bottom: 1.5rem;
        }
        
        .unauthorized-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 1rem;
        }
        
        .unauthorized-message {
            font-size: 1.1rem;
            color: #7f8c8d;
            margin-bottom: 2rem;
        }
        
        .btn-back {
            background-color: #3498db;
            border: none;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .btn-back:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }
    </style>
</head>
<body>
    <div class="unauthorized-container">
        <div class="unauthorized-icon">
            <i class="fas fa-exclamation-circle"></i>
        </div>
        <h1 class="unauthorized-title">Acesso Não Autorizado</h1>
        <p class="unauthorized-message">
            <?php echo session('error') ?: 'Você não tem permissão para acessar esta página. Verifique suas credenciais ou entre em contato com o administrador do sistema.'; ?>
        </p>
        <a href="<?php echo route('dashboard'); ?>" class="btn btn-primary btn-back">
            <i class="fas fa-arrow-left me-2"></i> Voltar para o Dashboard
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

