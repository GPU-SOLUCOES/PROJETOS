import type { NextApiRequest, NextApiResponse } from "next"
import { query, transaction } from "../../../../lib/db"
import { verifyToken, logActivity } from "../../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  const { id } = req.query

  // GET - Obter informações para saída
  if (req.method === "GET") {
    try {
      // Obter registro
      const recordResult = await query(
        `SELECT 
           pr.id, pr.entry_date as "entryDate", pr.exit_date as "exitDate",
           v.id as "vehicleId", v.plate, v.model, v.color, v.owner, v.document,
           s.id as "serviceId", s.type as "serviceType", s.value as "serviceValue",
           pl.id as "parkingLotId", pl.name as "parkingLotName"
         FROM parking_records pr
         JOIN vehicles v ON pr.vehicle_id = v.id
         JOIN services s ON pr.service_id = s.id
         JOIN parking_lots pl ON pr.parking_lot_id = pl.id
         WHERE pr.id = $1`,
        [id],
      )

      if (recordResult.rows.length === 0) {
        return res.status(404).json({ error: "Registro não encontrado" })
      }

      const record = recordResult.rows[0]

      if (record.exitDate) {
        return res.status(400).json({ error: "Este veículo já saiu do estacionamento" })
      }

      // Calcular duração e valor a pagar
      const entryDate = new Date(record.entryDate)
      const exitDate = new Date()

      const diffMs = exitDate.getTime() - entryDate.getTime()
      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60))
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
      const totalMinutes = diffHrs * 60 + diffMins

      let amountToPay = 0

      if (record.serviceType === "hour") {
        // Valor por hora, com fração mínima de 1 hora
        const totalHours = Math.ceil(totalMinutes / 60)
        amountToPay = totalHours * Number.parseFloat(record.serviceValue)
      } else if (record.serviceType === "day") {
        // Valor fixo por dia
        amountToPay = Number.parseFloat(record.serviceValue)
      } else if (record.serviceType === "month") {
        // Mensalista não paga na saída
        amountToPay = 0
      }

      return res.status(200).json({
        record,
        duration: {
          hours: diffHrs,
          minutes: diffMins,
          totalMinutes: totalMinutes,
        },
        amountToPay,
      })
    } catch (error) {
      console.error("Erro ao obter dados de saída:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // POST - Registrar saída
  if (req.method === "POST") {
    try {
      const { paymentMethod, paidAmount } = req.body

      // Validar dados
      if (!paymentMethod) {
        return res.status(400).json({ error: "Forma de pagamento é obrigatória" })
      }

      // Obter registro
      const recordResult = await query(
        `SELECT 
           pr.id, pr.entry_date as "entryDate", pr.exit_date as "exitDate",
           v.id as "vehicleId", v.plate,
           s.id as "serviceId", s.type as "serviceType", s.value as "serviceValue"
         FROM parking_records pr
         JOIN vehicles v ON pr.vehicle_id = v.id
         JOIN services s ON pr.service_id = s.id
         WHERE pr.id = $1`,
        [id],
      )

      if (recordResult.rows.length === 0) {
        return res.status(404).json({ error: "Registro não encontrado" })
      }

      const record = recordResult.rows[0]

      if (record.exitDate) {
        return res.status(400).json({ error: "Este veículo já saiu do estacionamento" })
      }

      // Calcular valor a pagar
      const entryDate = new Date(record.entryDate)
      const exitDate = new Date()

      const diffMs = exitDate.getTime() - entryDate.getTime()
      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60))
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
      const totalMinutes = diffHrs * 60 + diffMins

      let calculatedAmount = 0

      if (record.serviceType === "hour") {
        // Valor por hora, com fração mínima de 1 hora
        const totalHours = Math.ceil(totalMinutes / 60)
        calculatedAmount = totalHours * Number.parseFloat(record.serviceValue)
      } else if (record.serviceType === "day") {
        // Valor fixo por dia
        calculatedAmount = Number.parseFloat(record.serviceValue)
      } else if (record.serviceType === "month") {
        // Mensalista não paga na saída
        calculatedAmount = 0
      }

      // Registrar saída
      const updatedRecord = await transaction(async (client) => {
        // Atualizar registro
        await client.query(
          `UPDATE parking_records
           SET exit_date = NOW(),
               paid_amount = $1,
               payment_method = $2,
               exit_user_id = $3
           WHERE id = $4`,
          [calculatedAmount, paymentMethod, decodedToken.id, id],
        )

        // Buscar registro atualizado
        const updatedRecordResult = await client.query(
          `SELECT 
             pr.id, pr.entry_date as "entryDate", pr.exit_date as "exitDate",
             pr.paid_amount as "paidAmount", pr.payment_method as "paymentMethod",
             v.id as "vehicleId", v.plate, v.model, v.color, v.owner
           FROM parking_records pr
           JOIN vehicles v ON pr.vehicle_id = v.id
           WHERE pr.id = $1`,
          [id],
        )

        return updatedRecordResult.rows[0]
      })

      // Registrar log
      await logActivity(
        decodedToken.id,
        "vehicle_exit",
        `Registro de saída do veículo ${record.plate}`,
        (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress,
      )

      return res.status(200).json(updatedRecord)
    } catch (error) {
      console.error("Erro ao registrar saída:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // Método não permitido
  return res.status(405).json({ error: "Método não permitido" })
}

