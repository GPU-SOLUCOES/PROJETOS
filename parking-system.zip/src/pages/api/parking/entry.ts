import type { NextApiRequest, NextApiResponse } from "next"
import { query, transaction } from "../../../lib/db"
import { verifyToken, logActivity } from "../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Apenas método POST é permitido
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método não permitido" })
  }

  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  try {
    const { parkingLotId, owner, document, model, color, plate, serviceId } = req.body

    // Validar dados
    if (!parkingLotId || !owner || !document || !model || !color || !plate || !serviceId) {
      return res.status(400).json({ error: "Todos os campos são obrigatórios" })
    }

    // Verificar se o veículo já está estacionado
    const parkedVehicleResult = await query(
      `SELECT pr.id 
       FROM parking_records pr
       JOIN vehicles v ON pr.vehicle_id = v.id
       WHERE v.plate = $1 AND pr.exit_date IS NULL`,
      [plate],
    )

    if (parkedVehicleResult.rows.length > 0) {
      return res.status(400).json({ error: "Este veículo já está estacionado" })
    }

    // Verificar disponibilidade de vagas
    const parkingLotResult = await query("SELECT capacity FROM parking_lots WHERE id = $1", [parkingLotId])

    if (parkingLotResult.rows.length === 0) {
      return res.status(404).json({ error: "Estacionamento não encontrado" })
    }

    const parkingLot = parkingLotResult.rows[0]

    const parkedVehiclesResult = await query(
      "SELECT COUNT(*) as count FROM parking_records WHERE parking_lot_id = $1 AND exit_date IS NULL",
      [parkingLotId],
    )

    const parkedVehiclesCount = Number.parseInt(parkedVehiclesResult.rows[0].count, 10)

    if (parkedVehiclesCount >= parkingLot.capacity) {
      return res.status(400).json({ error: "Não há vagas disponíveis" })
    }

    // Usar transação para garantir consistência dos dados
    const result = await transaction(async (client) => {
      // Verificar se o veículo já existe
      const vehicleResult = await client.query("SELECT id FROM vehicles WHERE plate = $1", [plate])

      let vehicleId

      if (vehicleResult.rows.length === 0) {
        // Criar novo veículo
        const newVehicleResult = await client.query(
          `INSERT INTO vehicles (plate, model, color, owner, document, created_at)
           VALUES ($1, $2, $3, $4, $5, NOW())
           RETURNING id`,
          [plate, model, color, owner, document],
        )
        vehicleId = newVehicleResult.rows[0].id
      } else {
        // Atualizar dados do veículo
        vehicleId = vehicleResult.rows[0].id
        await client.query(
          `UPDATE vehicles 
           SET model = $1, color = $2, owner = $3, document = $4
           WHERE id = $5`,
          [model, color, owner, document, vehicleId],
        )
      }

      // Registrar entrada
      const parkingRecordResult = await client.query(
        `INSERT INTO parking_records 
         (vehicle_id, parking_lot_id, service_id, entry_date, entry_user_id)
         VALUES ($1, $2, $3, NOW(), $4)
         RETURNING id`,
        [vehicleId, parkingLotId, serviceId, decodedToken.id],
      )

      const parkingRecordId = parkingRecordResult.rows[0].id

      // Buscar detalhes completos do registro
      const completeRecordResult = await client.query(
        `SELECT 
           pr.id, pr.entry_date as "entryDate",
           v.id as "vehicleId", v.plate, v.model, v.color, v.owner,
           s.id as "serviceId", s.type as "serviceType", s.value as "serviceValue"
         FROM parking_records pr
         JOIN vehicles v ON pr.vehicle_id = v.id
         JOIN services s ON pr.service_id = s.id
         WHERE pr.id = $1`,
        [parkingRecordId],
      )

      return completeRecordResult.rows[0]
    })

    // Registrar log
    await logActivity(
      decodedToken.id,
      "vehicle_entry",
      `Registro de entrada do veículo ${plate}`,
      (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress,
    )

    return res.status(201).json(result)
  } catch (error) {
    console.error("Erro ao registrar entrada:", error)
    return res.status(500).json({ error: "Erro ao processar a solicitação" })
  }
}

