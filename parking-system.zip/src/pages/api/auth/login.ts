import type { NextApiRequest, NextApiResponse } from "next"
import {
  getUserByEmail,
  verifyPassword,
  generateToken,
  updateLastAccess,
  logActivity,
  checkClientStatus,
} from "../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Apenas método POST é permitido
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método não permitido" })
  }

  try {
    const { email, password } = req.body

    // Validar dados de entrada
    if (!email || !password) {
      return res.status(400).json({ error: "Email e senha são obrigatórios" })
    }

    // Buscar usuário pelo email
    const user = await getUserByEmail(email)
    if (!user) {
      return res.status(401).json({ error: "Credenciais inválidas" })
    }

    // Verificar senha
    const isPasswordValid = await verifyPassword(password, user.password)
    if (!isPasswordValid) {
      return res.status(401).json({ error: "Credenciais inválidas" })
    }

    // Verificar status do cliente (exceto para super_admin)
    if (user.role !== "super_admin" && user.clientId) {
      const clientStatus = await checkClientStatus(user.clientId)

      if (!clientStatus.active) {
        return res.status(403).json({ error: "Cliente inativo" })
      }

      if (clientStatus.blocked) {
        return res.status(403).json({
          error: "Cliente bloqueado",
          reason: clientStatus.blockReason || "Entre em contato com o suporte",
        })
      }
    }

    // Atualizar último acesso
    await updateLastAccess(user.id)

    // Registrar log de atividade
    await logActivity(
      user.id,
      "login",
      "Login no sistema",
      (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress,
    )

    // Gerar token JWT
    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role,
      clientId: user.clientId,
    })

    // Remover senha do objeto de usuário
    const { password: _, ...userWithoutPassword } = user

    // Retornar token e dados do usuário
    return res.status(200).json({
      token,
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Erro no login:", error)
    return res.status(500).json({ error: "Erro interno do servidor" })
  }
}

