import type { NextApiRequest, NextApiResponse } from "next"
import { query, transaction } from "../../../lib/db"
import { verifyToken, logActivity } from "../../../lib/auth"
import Stripe from "stripe"
import { config } from "../../../lib/config"

// Inicializar Stripe
const stripe = config.stripeSecretKey
  ? new Stripe(config.stripeSecretKey, {
      apiVersion: "2023-10-16",
    })
  : null

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  // GET - Listar assinaturas do cliente
  if (req.method === "GET") {
    try {
      // Verificar se é super_admin ou se está acessando suas próprias assinaturas
      const clientId = req.query.clientId || decodedToken.clientId

      if (decodedToken.role !== "super_admin" && decodedToken.clientId !== clientId) {
        return res.status(403).json({ error: "Acesso negado" })
      }

      const subscriptionsResult = await query(
        `SELECT 
           s.id, s.client_id as "clientId", s.plan_id as "planId",
           s.start_date as "startDate", s.end_date as "endDate",
           s.status, s.auto_renew as "autoRenew", s.price,
           p.name as "planName", p.description as "planDescription",
           p.max_users as "maxUsers", p.max_parking_lots as "maxParkingLots"
         FROM subscriptions s
         JOIN plans p ON s.plan_id = p.id
         WHERE s.client_id = $1
         ORDER BY s.start_date DESC`,
        [clientId],
      )

      return res.status(200).json(subscriptionsResult.rows)
    } catch (error) {
      console.error("Erro ao listar assinaturas:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // POST - Criar nova assinatura
  if (req.method === "POST") {
    try {
      const { planId, clientId, paymentMethod, autoRenew = true } = req.body

      // Validar dados
      if (!planId || !clientId || !paymentMethod) {
        return res.status(400).json({ error: "Todos os campos são obrigatórios" })
      }

      // Verificar permissões
      if (decodedToken.role !== "super_admin" && decodedToken.clientId !== clientId) {
        return res.status(403).json({ error: "Acesso negado" })
      }

      // Buscar plano
      const planResult = await query("SELECT id, name, price, duration FROM plans WHERE id = $1", [planId])

      if (planResult.rows.length === 0) {
        return res.status(404).json({ error: "Plano não encontrado" })
      }

      const plan = planResult.rows[0]

      // Calcular datas
      const startDate = new Date()
      const endDate = new Date()
      endDate.setMonth(endDate.getMonth() + plan.duration)

      // Processar pagamento com Stripe
      let paymentIntentId = null

      if (stripe) {
        try {
          // Criar um PaymentIntent no Stripe
          const paymentIntent = await stripe.paymentIntents.create({
            amount: Math.round(plan.price * 100), // Stripe trabalha com centavos
            currency: "brl",
            description: `Assinatura do plano ${plan.name} para cliente ${clientId}`,
            metadata: {
              clientId,
              planId,
              planName: plan.name,
            },
          })

          paymentIntentId = paymentIntent.id
        } catch (stripeError) {
          console.error("Erro ao processar pagamento com Stripe:", stripeError)
          return res.status(400).json({ error: "Erro ao processar pagamento" })
        }
      }

      // Criar assinatura no banco de dados
      const result = await transaction(async (client) => {
        // Inserir assinatura
        const subscriptionResult = await client.query(
          `INSERT INTO subscriptions 
           (client_id, plan_id, start_date, end_date, status, auto_renew, price, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
           RETURNING id`,
          [clientId, planId, startDate, endDate, "pending", autoRenew, plan.price],
        )

        const subscriptionId = subscriptionResult.rows[0].id

        // Inserir pagamento
        await client.query(
          `INSERT INTO payments
           (subscription_id, amount, date, status, payment_method, transaction_id, created_at)
           VALUES ($1, $2, NOW(), $3, $4, $5, NOW())`,
          [subscriptionId, plan.price, "pending", paymentMethod, paymentIntentId],
        )

        // Buscar detalhes completos da assinatura
        const completeSubscriptionResult = await client.query(
          `SELECT 
             s.id, s.client_id as "clientId", s.plan_id as "planId",
             s.start_date as "startDate", s.end_date as "endDate",
             s.status, s.auto_renew as "autoRenew", s.price,
             p.name as "planName", p.description as "planDescription"
           FROM subscriptions s
           JOIN plans p ON s.plan_id = p.id
           WHERE s.id = $1`,
          [subscriptionId],
        )

        return {
          subscription: completeSubscriptionResult.rows[0],
          paymentIntentId,
          clientSecret: paymentIntentId
            ? (await stripe?.paymentIntents.retrieve(paymentIntentId))?.client_secret
            : null,
        }
      })

      // Registrar log
      await logActivity(
        decodedToken.id,
        "subscription_created",
        `Assinatura criada para o cliente ${clientId}, plano ${plan.name}`,
        (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress,
      )

      return res.status(201).json(result)
    } catch (error) {
      console.error("Erro ao criar assinatura:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // Método não permitido
  return res.status(405).json({ error: "Método não permitido" })
}

