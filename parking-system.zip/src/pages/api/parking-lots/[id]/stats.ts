import type { NextApiRequest, NextApiResponse } from "next"
import { query } from "../../../../lib/db"
import { verifyToken } from "../../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  const { id } = req.query

  // GET - Obter estatísticas do estacionamento
  if (req.method === "GET") {
    try {
      // Verificar se o estacionamento existe
      const parkingLotResult = await query(
        'SELECT id, capacity, client_id as "clientId" FROM parking_lots WHERE id = $1',
        [id],
      )

      if (parkingLotResult.rows.length === 0) {
        return res.status(404).json({ error: "Estacionamento não encontrado" })
      }

      const parkingLot = parkingLotResult.rows[0]

      // Verificar permissões
      if (decodedToken.role !== "super_admin" && decodedToken.clientId !== parkingLot.clientId) {
        return res.status(403).json({ error: "Acesso negado" })
      }

      // Contar veículos atualmente estacionados
      const parkedVehiclesResult = await query(
        "SELECT COUNT(*) as count FROM parking_records WHERE parking_lot_id = $1 AND exit_date IS NULL",
        [id],
      )

      const parkedVehiclesCount = Number.parseInt(parkedVehiclesResult.rows[0].count, 10)

      // Obter data de hoje (início do dia)
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      // Contar entradas de hoje
      const todayEntriesResult = await query(
        "SELECT COUNT(*) as count FROM parking_records WHERE parking_lot_id = $1 AND entry_date >= $2",
        [id, today],
      )

      const todayEntries = Number.parseInt(todayEntriesResult.rows[0].count, 10)

      // Calcular faturamento de hoje
      const todayRevenueResult = await query(
        "SELECT COALESCE(SUM(paid_amount), 0) as total FROM parking_records WHERE parking_lot_id = $1 AND exit_date >= $2",
        [id, today],
      )

      const todayRevenue = Number.parseFloat(todayRevenueResult.rows[0].total)

      // Calcular estatísticas
      const availableSpots = parkingLot.capacity - parkedVehiclesCount
      const occupancyRate = (parkedVehiclesCount / parkingLot.capacity) * 100

      return res.status(200).json({
        availableSpots,
        totalSpots: parkingLot.capacity,
        occupancyRate,
        todayEntries,
        todayRevenue,
      })
    } catch (error) {
      console.error("Erro ao obter estatísticas:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // Método não permitido
  return res.status(405).json({ error: "Método não permitido" })
}

