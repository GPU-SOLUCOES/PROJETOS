import type { NextApiRequest, NextApiResponse } from "next"
import { query } from "../../../../lib/db"
import { verifyToken } from "../../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  const { id } = req.query

  // GET - Obter veículos estacionados
  if (req.method === "GET") {
    try {
      // Verificar se o estacionamento existe
      const parkingLotResult = await query('SELECT id, client_id as "clientId" FROM parking_lots WHERE id = $1', [id])

      if (parkingLotResult.rows.length === 0) {
        return res.status(404).json({ error: "Estacionamento não encontrado" })
      }

      const parkingLot = parkingLotResult.rows[0]

      // Verificar permissões
      if (decodedToken.role !== "super_admin" && decodedToken.clientId !== parkingLot.clientId) {
        return res.status(403).json({ error: "Acesso negado" })
      }

      // Obter veículos estacionados
      const parkedVehiclesResult = await query(
        `SELECT 
           pr.id, pr.entry_date as "entryDate", pr.exit_date as "exitDate",
           pr.vehicle_id as "vehicleId", pr.service_id as "serviceId",
           v.plate, v.model, v.color, v.owner, v.document,
           s.type as "serviceType", s.value as "serviceValue"
         FROM parking_records pr
         JOIN vehicles v ON pr.vehicle_id = v.id
         JOIN services s ON pr.service_id = s.id
         WHERE pr.parking_lot_id = $1 AND pr.exit_date IS NULL
         ORDER BY pr.entry_date DESC`,
        [id],
      )

      // Formatar dados para o frontend
      const parkedVehicles = parkedVehiclesResult.rows.map((record) => ({
        id: record.id,
        entryDate: record.entryDate,
        exitDate: record.exitDate,
        vehicle: {
          id: record.vehicleId,
          plate: record.plate,
          model: record.model,
          color: record.color,
          owner: record.owner,
          document: record.document,
        },
        service: {
          id: record.serviceId,
          type: record.serviceType,
          value: record.serviceValue,
        },
      }))

      return res.status(200).json(parkedVehicles)
    } catch (error) {
      console.error("Erro ao obter veículos estacionados:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // Método não permitido
  return res.status(405).json({ error: "Método não permitido" })
}

