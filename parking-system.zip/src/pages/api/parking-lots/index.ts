import type { NextApiRequest, NextApiResponse } from "next"
import { query } from "../../../lib/db"
import { verifyToken } from "../../../lib/auth"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Verificar autenticação
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Não autorizado" })
  }

  const token = authHeader.substring(7)
  const decodedToken = verifyToken(token)

  if (!decodedToken) {
    return res.status(401).json({ error: "Token inválido ou expirado" })
  }

  // GET - Listar estacionamentos
  if (req.method === "GET") {
    try {
      let parkingLotsQuery
      const queryParams: any[] = []

      if (decodedToken.role === "super_admin") {
        // Super admin pode ver todos os estacionamentos
        parkingLotsQuery = `
          SELECT 
            pl.id, pl.name, pl.address, pl.capacity, 
            pl.opening_time as "openingTime", 
            pl.closing_time as "closingTime",
            pl.client_id as "clientId", 
            pl.branch_id as "branchId",
            c.name as "clientName"
          FROM parking_lots pl
          JOIN clients c ON pl.client_id = c.id
          ORDER BY c.name, pl.name
        `
      } else {
        // Outros usuários só veem estacionamentos do seu cliente
        parkingLotsQuery = `
          SELECT 
            pl.id, pl.name, pl.address, pl.capacity, 
            pl.opening_time as "openingTime", 
            pl.closing_time as "closingTime",
            pl.client_id as "clientId", 
            pl.branch_id as "branchId"
          FROM parking_lots pl
          WHERE pl.client_id = $1
          ORDER BY pl.name
        `
        queryParams.push(decodedToken.clientId)
      }

      const result = await query(parkingLotsQuery, queryParams)
      return res.status(200).json(result.rows)
    } catch (error) {
      console.error("Erro ao listar estacionamentos:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // POST - Criar estacionamento
  if (req.method === "POST") {
    try {
      const { name, address, capacity, openingTime, closingTime, clientId, branchId } = req.body

      // Validar dados
      if (!name || !capacity || !clientId) {
        return res.status(400).json({ error: "Nome, capacidade e cliente são obrigatórios" })
      }

      // Verificar permissões
      if (decodedToken.role !== "super_admin" && decodedToken.role !== "admin") {
        return res.status(403).json({ error: "Acesso negado" })
      }

      // Verificar se o usuário tem permissão para este cliente
      if (decodedToken.role !== "super_admin" && decodedToken.clientId !== clientId) {
        return res.status(403).json({ error: "Acesso negado" })
      }

      const result = await query(
        `INSERT INTO parking_lots 
         (name, address, capacity, opening_time, closing_time, client_id, branch_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
         RETURNING id, name, address, capacity, opening_time as "openingTime", closing_time as "closingTime", client_id as "clientId", branch_id as "branchId"`,
        [name, address, capacity, openingTime, closingTime, clientId, branchId],
      )

      return res.status(201).json(result.rows[0])
    } catch (error) {
      console.error("Erro ao criar estacionamento:", error)
      return res.status(500).json({ error: "Erro ao processar a solicitação" })
    }
  }

  // Método não permitido
  return res.status(405).json({ error: "Método não permitido" })
}

