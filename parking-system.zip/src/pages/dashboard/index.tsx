"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/router"
import axios from "axios"
import { Car, DollarSign, Percent, ParkingSquare, Search, LogOut, Plus } from "lucide-react"
import Layout from "@/components/Layout"
import ParkingLotSelector from "@/components/ParkingLotSelector"
import type { ParkingLot, ParkingRecord } from "@/types"

export default function Dashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [parkingLots, setParkingLots] = useState<ParkingLot[]>([])
  const [selectedParkingLot, setSelectedParkingLot] = useState<ParkingLot | null>(null)
  const [stats, setStats] = useState({
    availableSpots: 0,
    totalSpots: 0,
    occupancyRate: 0,
    todayEntries: 0,
    todayRevenue: 0,
  })
  const [parkedVehicles, setParkedVehicles] = useState<ParkingRecord[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Verificar autenticação
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/login")
      return
    }

    // Carregar estacionamentos
    const fetchParkingLots = async () => {
      try {
        const response = await axios.get("/api/parking-lots", {
          headers: { Authorization: `Bearer ${token}` },
        })

        setParkingLots(response.data)

        if (response.data.length > 0) {
          const lotId = router.query.parkingLotId || response.data[0].id
          const selectedLot = response.data.find((lot: ParkingLot) => lot.id === lotId) || response.data[0]
          setSelectedParkingLot(selectedLot)
          fetchParkingLotData(selectedLot.id)
        } else {
          setIsLoading(false)
        }
      } catch (error) {
        console.error("Erro ao carregar estacionamentos:", error)
        setIsLoading(false)
      }
    }

    fetchParkingLots()
  }, [router])

  const fetchParkingLotData = async (parkingLotId: string) => {
    setIsLoading(true)
    const token = localStorage.getItem("token")

    try {
      // Carregar estatísticas
      const statsResponse = await axios.get(`/api/parking-lots/${parkingLotId}/stats`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      setStats(statsResponse.data)

      // Carregar veículos estacionados
      const vehiclesResponse = await axios.get(`/api/parking-lots/${parkingLotId}/vehicles`, {
        headers: { Authorization: `Bearer ${token}` },
      })

      setParkedVehicles(vehiclesResponse.data)
    } catch (error) {
      console.error("Erro ao carregar dados do estacionamento:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleParkingLotChange = (parkingLotId: string) => {
    const selectedLot = parkingLots.find((lot) => lot.id === parkingLotId)
    if (selectedLot) {
      setSelectedParkingLot(selectedLot)
      router.push(`/dashboard?parkingLotId=${parkingLotId}`, undefined, { shallow: true })
      fetchParkingLotData(parkingLotId)
    }
  }

  // Filtrar veículos com base na busca
  const filteredVehicles = parkedVehicles.filter(
    (record) =>
      record.vehicle?.plate.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.vehicle?.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.vehicle?.owner.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Calcular duração da permanência
  const calculateDuration = (entryTime: Date) => {
    const now = new Date()
    const entry = new Date(entryTime)

    const diffMs = now.getTime() - entry.getTime()
    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

    return `${diffHrs}h ${diffMins}min`
  }

  return (
    <Layout>
      <div className="px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="mt-1 text-sm text-gray-500">
              {selectedParkingLot ? `Estacionamento: ${selectedParkingLot.name}` : "Selecione um estacionamento"}
            </p>
          </div>

          {parkingLots.length > 0 && (
            <div className="mt-4 sm:mt-0">
              <ParkingLotSelector
                parkingLots={parkingLots}
                selectedParkingLotId={selectedParkingLot?.id || ""}
                onChange={handleParkingLotChange}
              />
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : parkingLots.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <ParkingSquare className="h-8 w-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Nenhum estacionamento disponível</h2>
            <p className="text-gray-500 mb-6">
              Você não possui estacionamentos cadastrados ou não tem permissão para acessá-los.
            </p>
            <button
              onClick={() => router.push("/admin/parking-lots/new")}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Plus className="mr-2 h-4 w-4" />
              Cadastrar Estacionamento
            </button>
          </div>
        ) : (
          <>
            {/* Estatísticas */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                      <ParkingSquare className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Vagas Disponíveis</dt>
                        <dd className="flex items-baseline">
                          <div className="text-2xl font-semibold text-gray-900">{stats.availableSpots}</div>
                          <div className="ml-2 text-sm text-gray-500">de {stats.totalSpots}</div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                      <Percent className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Taxa de Ocupação</dt>
                        <dd className="flex items-baseline">
                          <div className="text-2xl font-semibold text-gray-900">{stats.occupancyRate.toFixed(1)}%</div>
                          <div className="ml-2 text-sm text-gray-500">
                            {stats.totalSpots - stats.availableSpots} ocupadas
                          </div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-orange-100 rounded-md p-3">
                      <Car className="h-6 w-6 text-orange-600" />
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Entradas Hoje</dt>
                        <dd className="flex items-baseline">
                          <div className="text-2xl font-semibold text-gray-900">{stats.todayEntries}</div>
                          <div className="ml-2 text-sm text-gray-500">veículos</div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-purple-100 rounded-md p-3">
                      <DollarSign className="h-6 w-6 text-purple-600" />
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Faturamento Hoje</dt>
                        <dd className="flex items-baseline">
                          <div className="text-2xl font-semibold text-gray-900">
                            R$ {stats.todayRevenue.toFixed(2).replace(".", ",")}
                          </div>
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Botão de Nova Entrada */}
            <div className="mb-6">
              <button
                onClick={() => router.push("/parking/entry")}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Plus className="mr-2 h-5 w-5" />
                Nova Entrada de Veículo
              </button>
            </div>

            {/* Veículos Estacionados */}
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
                <div className="flex flex-wrap items-center justify-between">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Veículos Estacionados</h3>
                  <div className="mt-2 sm:mt-0 w-full sm:w-64">
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        placeholder="Buscar veículo..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                {filteredVehicles.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-gray-500">
                      {searchQuery
                        ? "Nenhum veículo encontrado para esta busca."
                        : "Não há veículos estacionados no momento."}
                    </p>
                  </div>
                ) : (
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Placa
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Modelo/Cor
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Proprietário
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Entrada
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Permanência
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Tipo
                        </th>
                        <th
                          scope="col"
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          Ações
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredVehicles.map((record) => (
                        <tr key={record.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {record.vehicle?.plate}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {record.vehicle?.model} / {record.vehicle?.color}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.vehicle?.owner}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(record.entryDate).toLocaleString("pt-BR")}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {calculateDuration(record.entryDate)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span
                              className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                record.service?.type === "hour"
                                  ? "bg-blue-100 text-blue-800"
                                  : record.service?.type === "day"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {record.service?.type === "hour"
                                ? "Hora"
                                : record.service?.type === "day"
                                  ? "Diária"
                                  : "Mensalista"}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <button
                              onClick={() => router.push(`/parking/exit/${record.id}`)}
                              className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                            >
                              <LogOut className="mr-1 h-3 w-3" />
                              Saída
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </Layout>
  )
}

