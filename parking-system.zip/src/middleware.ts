import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

// Rotas que não precisam de autenticação
const publicRoutes = ["/login", "/register", "/api/auth", "/pricing"]

// Rotas que precisam de permissões específicas
const roleRoutes = {
  "/admin": ["admin", "super_admin"],
  "/super-admin": ["super_admin"],
  "/reports": ["manager", "admin", "super_admin"],
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Verificar se é uma rota pública
  if (publicRoutes.some((route) => pathname.startsWith(route))) {
    return NextResponse.next()
  }

  // Verificar se é uma rota de API pública
  if (pathname.startsWith("/api/auth")) {
    return NextResponse.next()
  }

  // Verificar token JWT
  const token = await getToken({ req: request, secret: process.env.NEXTAUTH_SECRET })

  // Se não estiver autenticado, redirecionar para login
  if (!token) {
    const url = new URL("/login", request.url)
    url.searchParams.set("callbackUrl", encodeURI(request.url))
    return NextResponse.redirect(url)
  }

  // Verificar permissões para rotas específicas
  for (const [route, roles] of Object.entries(roleRoutes)) {
    if (pathname.startsWith(route) && !roles.includes(token.role as string)) {
      return NextResponse.redirect(new URL("/unauthorized", request.url))
    }
  }

  // Verificar se o cliente está bloqueado (exceto para super_admin)
  if (token.role !== "super_admin" && token.clientId && pathname !== "/blocked") {
    const clientResponse = await fetch(`${process.env.NEXTAUTH_URL}/api/clients/${token.clientId}/status`, {
      headers: {
        Authorization: `Bearer ${token.jwt}`,
      },
    })

    if (clientResponse.ok) {
      const clientStatus = await clientResponse.json()

      if (clientStatus.blocked) {
        return NextResponse.redirect(new URL("/blocked", request.url))
      }
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.png$).*)"],
}

