import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { formatDistanceToNow, format } from "date-fns"
import { ptBR } from "date-fns/locale"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value)
}

export function formatDate(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date
  return format(dateObj, "dd/MM/yyyy", { locale: ptBR })
}

export function formatDateTime(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date
  return format(dateObj, "dd/MM/yyyy HH:mm", { locale: ptBR })
}

export function formatTimeAgo(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date
  return formatDistanceToNow(dateObj, { addSuffix: true, locale: ptBR })
}

export function calculateParkingFee(entryDate: Date, exitDate: Date, hourlyRate: number, dailyRate: number): number {
  const diffInMilliseconds = exitDate.getTime() - entryDate.getTime()
  const diffInHours = diffInMilliseconds / (1000 * 60 * 60)

  // Se for mais de 12 horas, cobra diária
  if (diffInHours > 12) {
    const days = Math.ceil(diffInHours / 24)
    return days * dailyRate
  }

  // Caso contrário, cobra por hora (mínimo de 1 hora)
  const hours = Math.ceil(diffInHours)
  return Math.max(1, hours) * hourlyRate
}

export function generateTicketNumber(): string {
  const timestamp = Date.now().toString(36)
  const randomStr = Math.random().toString(36).substring(2, 8)
  return `${timestamp}${randomStr}`.toUpperCase()
}

export function maskPlate(plate: string): string {
  // Remove espaços e caracteres especiais
  const cleanPlate = plate.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()

  // Formato brasileiro: AAA-0000 ou Mercosul: AAA0A00
  if (cleanPlate.length === 7) {
    if (/^[A-Z]{3}\d{4}$/.test(cleanPlate)) {
      // Formato antigo
      return `${cleanPlate.substring(0, 3)}-${cleanPlate.substring(3)}`
    } else if (/^[A-Z]{3}\d[A-Z]\d{2}$/.test(cleanPlate)) {
      // Formato Mercosul
      return cleanPlate
    }
  }

  // Se não reconhecer o formato, retorna como está
  return plate
}

export function maskDocument(document: string): string {
  // Remove caracteres não numéricos
  const numbers = document.replace(/\D/g, "")

  // CPF: 000.000.000-00
  if (numbers.length === 11) {
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  // CNPJ: 00.000.000/0000-00
  if (numbers.length === 14) {
    return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5")
  }

  // Se não for CPF nem CNPJ, retorna como está
  return document
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return `${text.substring(0, maxLength)}...`
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((part) => part.charAt(0))
    .join("")
    .toUpperCase()
    .substring(0, 2)
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  return String(error)
}

