// Configurações da aplicação

interface Config {
  environment: string
  port: number
  databaseUrl: string
  jwtSecret: string
  jwtExpiresIn: string
  redisUrl?: string
  stripeSecretKey?: string
  stripeWebhookSecret?: string
  mailService?: {
    host: string
    port: number
    auth: {
      user: string
      pass: string
    }
  }
  frontendUrl: string
  mobileAppUrl: string
}

export const config: Config = {
  environment: process.env.NODE_ENV || "development",
  port: Number.parseInt(process.env.PORT || "3000", 10),
  databaseUrl: process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/parking_system",
  jwtSecret: process.env.JWT_SECRET || "your-secret-key",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "7d",
  redisUrl: process.env.REDIS_URL,
  stripeSecretKey: process.env.STRIPE_SECRET_KEY,
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
  mailService: process.env.MAIL_HOST
    ? {
        host: process.env.MAIL_HOST,
        port: Number.parseInt(process.env.MAIL_PORT || "587", 10),
        auth: {
          user: process.env.MAIL_USER || "",
          pass: process.env.MAIL_PASS || "",
        },
      }
    : undefined,
  frontendUrl: process.env.FRONTEND_URL || "http://localhost:3000",
  mobileAppUrl: process.env.MOBILE_APP_URL || "exp://localhost:19000",
}

