import type { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { PrismaAdapter } from "@auth/prisma-adapter"
import { prisma } from "@/lib/prisma"
import bcrypt from "bcryptjs"
import { UserRole } from "@/types"

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 dias
  },
  pages: {
    signIn: "/login",
    error: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error("Credenciais inválidas")
        }

        const user = await prisma.user.findUnique({
          where: {
            email: credentials.email,
          },
        })

        if (!user) {
          throw new Error("Usuário não encontrado")
        }

        const isPasswordValid = await bcrypt.compare(credentials.password, user.password)

        if (!isPasswordValid) {
          throw new Error("Senha incorreta")
        }

        // Verificar se o cliente está ativo e não bloqueado (exceto para super_admin)
        if (user.role !== UserRole.SUPER_ADMIN && user.clientId) {
          const client = await prisma.client.findUnique({
            where: {
              id: user.clientId,
            },
          })

          if (!client) {
            throw new Error("Cliente não encontrado")
          }

          if (!client.active) {
            throw new Error("Cliente inativo")
          }

          if (client.blocked) {
            throw new Error(`Cliente bloqueado: ${client.blockReason || "Entre em contato com o suporte"}`)
          }
        }

        // Registrar login
        await prisma.activityLog.create({
          data: {
            userId: user.id,
            action: "login",
            details: "Login no sistema",
            ip: "127.0.0.1", // Em produção, usar o IP real
          },
        })

        // Atualizar último acesso
        await prisma.user.update({
          where: {
            id: user.id,
          },
          data: {
            lastAccess: new Date(),
          },
        })

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          clientId: user.clientId || null,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.role = user.role
        token.clientId = user.clientId
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as UserRole
        session.user.clientId = token.clientId as string | null
      }
      return session
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
}

