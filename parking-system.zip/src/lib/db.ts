import { Pool } from "pg"
import { config } from "./config"

// Criando um pool de conexões com o PostgreSQL
const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: config.environment === "production" ? { rejectUnauthorized: false } : false,
})

// Testando a conexão
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("Erro ao conectar ao banco de dados:", err)
  } else {
    console.log("Conexão com o banco de dados estabelecida:", res.rows[0])
  }
})

// Função para executar queries
export async function query(text: string, params?: any[]) {
  try {
    const start = Date.now()
    const res = await pool.query(text, params)
    const duration = Date.now() - start

    console.log("Query executada:", { text, duration, rows: res.rowCount })

    return res
  } catch (error) {
    console.error("Erro ao executar query:", error)
    throw error
  }
}

// Função para transações
export async function transaction<T>(callback: (client: any) => Promise<T>): Promise<T> {
  const client = await pool.connect()

  try {
    await client.query("BEGIN")
    const result = await callback(client)
    await client.query("COMMIT")
    return result
  } catch (error) {
    await client.query("ROLLBACK")
    throw error
  } finally {
    client.release()
  }
}

// Função para encerrar o pool (útil para testes)
export function end() {
  return pool.end()
}

