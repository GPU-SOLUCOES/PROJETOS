"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/router"
import Link from "next/link"
import {
  LayoutDashboard,
  Car,
  Settings,
  FileText,
  Building,
  CreditCard,
  LogOut,
  Menu,
  X,
  User,
  Bell,
} from "lucide-react"
import type { User as UserType } from "@/types"

interface LayoutProps {
  children: React.ReactNode
}

export default function Layout({ children }: LayoutProps) {
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [user, setUser] = useState<UserType | null>(null)

  useEffect(() => {
    // Verificar autenticação
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token) {
      router.push("/login")
      return
    }

    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/login")
  }

  const isSuperAdmin = user?.role === "super_admin"
  const isAdmin = user?.role === "admin" || user?.role === "gerente"

  const routes = [
    {
      href: "/dashboard",
      icon: LayoutDashboard,
      title: "Dashboard",
    },
    {
      href: "/parking/entry",
      icon: Car,
      title: "Entrada de Veículo",
    },
  ]

  // Adicionar rotas de admin/gerente
  if (isAdmin || isSuperAdmin) {
    routes.push(
      {
        href: "/admin",
        icon: Settings,
        title: "Administração",
      },
      {
        href: "/financeiro",
        icon: CreditCard,
        title: "Financeiro",
      },
    )
  }

  // Adicionar rotas de super admin
  if (isSuperAdmin) {
    routes.unshift(
      {
        href: "/super-admin/dashboard",
        icon: FileText,
        title: "Dashboard Financeiro",
      },
      {
        href: "/super-admin/clients",
        icon: Building,
        title: "Gerenciar Clientes",
      },
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm lg:static lg:overflow-y-visible">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative flex justify-between h-16">
            <div className="flex items-center px-2 lg:px-0">
              <div className="flex-shrink-0 flex items-center">
                <Link href="/dashboard">
                  <div className="h-8 w-auto cursor-pointer">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="32"
                      height="32"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-blue-600"
                    >
                      <rect width="18" height="18" x="3" y="3" rx="2" />
                      <path d="M7 7h.01" />
                      <path d="M17 7h.01" />
                      <path d="M7 17h.01" />
                      <path d="M17 17h.01" />
                      <path d="M12 12h.01" />
                    </svg>
                  </div>
                </Link>
                <span className="ml-2 text-lg font-bold text-gray-900 hidden md:block">Sistema de Estacionamento</span>
              </div>
            </div>

            <div className="flex items-center lg:hidden">
              <button
                type="button"
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                <span className="sr-only">Abrir menu principal</span>
                {isMobileMenuOpen ? (
                  <X className="block h-6 w-6" aria-hidden="true" />
                ) : (
                  <Menu className="block h-6 w-6" aria-hidden="true" />
                )}
              </button>
            </div>

            <div className="hidden lg:flex lg:items-center">
              <button
                type="button"
                className="flex-shrink-0 p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <span className="sr-only">Ver notificações</span>
                <Bell className="h-6 w-6" aria-hidden="true" />
              </button>

              {/* Profile dropdown */}
              <div className="ml-4 relative flex-shrink-0">
                <div className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <User className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-700">{user?.name}</p>
                    <p className="text-xs text-gray-500">{user?.role}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden">
            <div className="pt-2 pb-3 space-y-1">
              {routes.map((route) => (
                <Link
                  key={route.href}
                  href={route.href}
                  className={`${
                    router.pathname === route.href
                      ? "bg-blue-50 border-blue-500 text-blue-700"
                      : "border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800"
                  } block pl-3 pr-4 py-2 border-l-4 text-base font-medium`}
                >
                  <div className="flex items-center">
                    <route.icon className="mr-3 h-5 w-5" />
                    {route.title}
                  </div>
                </Link>
              ))}
              <button
                onClick={handleLogout}
                className="border-transparent text-red-600 hover:bg-red-50 hover:border-red-300 block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left"
              >
                <div className="flex items-center">
                  <LogOut className="mr-3 h-5 w-5" />
                  Sair
                </div>
              </button>
            </div>
          </div>
        )}
      </header>

      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex">
          {/* Sidebar for desktop */}
          <div className="hidden lg:block lg:col-span-3 xl:col-span-2">
            <nav aria-label="Sidebar" className="sticky top-6 divide-y divide-gray-300">
              <div className="pb-8 space-y-1">
                {routes.map((route) => (
                  <Link
                    key={route.href}
                    href={route.href}
                    className={`${
                      router.pathname === route.href ? "bg-gray-200 text-gray-900" : "text-gray-600 hover:bg-gray-50"
                    } group flex items-center px-3 py-2 text-sm font-medium rounded-md`}
                  >
                    <route.icon
                      className={`${
                        router.pathname === route.href ? "text-gray-500" : "text-gray-400 group-hover:text-gray-500"
                      } flex-shrink-0 -ml-1 mr-3 h-6 w-6`}
                      aria-hidden="true"
                    />
                    <span className="truncate">{route.title}</span>
                  </Link>
                ))}
                <button
                  onClick={handleLogout}
                  className="text-red-600 hover:bg-red-50 group flex items-center px-3 py-2 text-sm font-medium rounded-md w-full"
                >
                  <LogOut
                    className="text-red-400 group-hover:text-red-500 flex-shrink-0 -ml-1 mr-3 h-6 w-6"
                    aria-hidden="true"
                  />
                  <span className="truncate">Sair</span>
                </button>
              </div>
            </nav>
          </div>

          {/* Main content */}
          <main className="flex-1 lg:pl-8">{children}</main>
        </div>
      </div>
    </div>
  )
}

