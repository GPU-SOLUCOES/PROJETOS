"use client"

import type React from "react"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { formatDate } from "@/lib/utils"
import { Building, MoreHorizontal, PlusCircle, Users } from "lucide-react"

const clientFormSchema = z.object({
  name: z.string().min(3, { message: "Nome deve ter pelo menos 3 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  phone: z.string().min(10, { message: "Telefone deve ter pelo menos 10 dígitos" }),
  address: z.string().min(5, { message: "Endereço deve ter pelo menos 5 caracteres" }),
  logo: z.string().optional(),
  active: z.boolean().default(true),
  notes: z.string().optional(),
})

type ClientFormValues = z.infer<typeof clientFormSchema>

interface Client {
  id: string
  name: string
  email?: string
  phone?: string
  address?: string
  logo?: string
  active: boolean
  blocked: boolean
  blockReason?: string
  registrationDate: Date
  _count: {
    parkingLots: number
    users: number
  }
}

interface ClientManagementProps {
  initialClients: Client[]
}

export function ClientManagement({ initialClients }: ClientManagementProps) {
  const { toast } = useToast()
  const [clients, setClients] = useState<Client[]>(initialClients)
  const [isLoading, setIsLoading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<Client | null>(null)
  const [blockDialogOpen, setBlockDialogOpen] = useState(false)
  const [blockReason, setBlockReason] = useState("")
  const [clientToBlock, setClientToBlock] = useState<Client | null>(null)

  const form = useForm<ClientFormValues>({
    resolver: zodResolver(clientFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      address: "",
      logo: "",
      active: true,
      notes: "",
    },
  })

  async function fetchClients() {
    try {
      const response = await fetch("/api/clients")
      if (!response.ok) {
        throw new Error("Erro ao carregar clientes")
      }
      const data = await response.json()
      setClients(data)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os clientes",
      })
    }
  }

  function handleEditClient(client: Client) {
    setEditingClient(client)
    form.reset({
      name: client.name,
      email: client.email || "",
      phone: client.phone || "",
      address: client.address || "",
      logo: client.logo || "",
      active: client.active,
      notes: "",
    })
    setIsDialogOpen(true)
  }

  function handleAddClient() {
    setEditingClient(null)
    form.reset({
      name: "",
      email: "",
      phone: "",
      address: "",
      logo: "",
      active: true,
      notes: "",
    })
    setIsDialogOpen(true)
  }

  function handleBlockClient(client: Client) {
    setClientToBlock(client)
    setBlockReason("")
    setBlockDialogOpen(true)
  }

  function handleUnblockClient(client: Client) {
    if (!confirm("Tem certeza que deseja desbloquear este cliente?")) {
      return
    }

    unblockClient(client.id)
  }

  async function blockClient(id: string, reason: string) {
    try {
      const response = await fetch(`/api/clients/${id}/block`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ reason }),
      })

      if (!response.ok) {
        throw new Error("Erro ao bloquear cliente")
      }

      toast({
        title: "Sucesso",
        description: "Cliente bloqueado com sucesso",
      })

      fetchClients()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível bloquear o cliente",
      })
    }
  }

  async function unblockClient(id: string) {
    try {
      const response = await fetch(`/api/clients/${id}/unblock`, {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Erro ao desbloquear cliente")
      }

      toast({
        title: "Sucesso",
        description: "Cliente desbloqueado com sucesso",
      })

      fetchClients()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível desbloquear o cliente",
      })
    }
  }

  async function onSubmit(values: ClientFormValues) {
    setIsLoading(true)

    try {
      const url = editingClient ? `/api/clients/${editingClient.id}` : "/api/clients"

      const method = editingClient ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Erro ao salvar cliente")
      }

      toast({
        title: "Sucesso",
        description: editingClient ? "Cliente atualizado com sucesso" : "Cliente criado com sucesso",
      })

      setIsDialogOpen(false)
      fetchClients()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao salvar o cliente",
      })
    } finally {
      setIsLoading(false)
    }
  }

  function handleBlockSubmit() {
    if (!clientToBlock) return

    blockClient(clientToBlock.id, blockReason)
    setBlockDialogOpen(false)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={handleAddClient}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Adicionar Cliente
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Contato</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Estacionamentos</TableHead>
              <TableHead>Usuários</TableHead>
              <TableHead>Cadastro</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {clients.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center">
                  Nenhum cliente encontrado
                </TableCell>
              </TableRow>
            ) : (
              clients.map((client) => (
                <TableRow key={client.id}>
                  <TableCell className="font-medium">{client.name}</TableCell>
                  <TableCell>
                    {client.email && <div className="text-sm">{client.email}</div>}
                    {client.phone && <div className="text-sm text-muted-foreground">{client.phone}</div>}
                  </TableCell>
                  <TableCell>
                    {client.blocked ? (
                      <Badge variant="destructive">Bloqueado</Badge>
                    ) : client.active ? (
                      <Badge variant="default">Ativo</Badge>
                    ) : (
                      <Badge variant="outline">Inativo</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Building className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{client._count.parkingLots}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{client._count.users}</span>
                    </div>
                  </TableCell>
                  <TableCell>{formatDate(client.registrationDate)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Ações</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handleEditClient(client)}>Editar</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => (window.location.href = `/super-admin/clients/${client.id}`)}>
                          Ver detalhes
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {client.blocked ? (
                          <DropdownMenuItem onClick={() => handleUnblockClient(client)}>Desbloquear</DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem className="text-destructive" onClick={() => handleBlockClient(client)}>
                            Bloquear
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Dialog para adicionar/editar cliente */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{editingClient ? "Editar Cliente" : "Adicionar Cliente"}</DialogTitle>
            <DialogDescription>
              {editingClient
                ? "Edite as informações do cliente abaixo"
                : "Preencha as informações para adicionar um novo cliente"}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome</FormLabel>
                    <FormControl>
                      <Input placeholder="Nome da empresa" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="contato@empresa.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone</FormLabel>
                      <FormControl>
                        <Input placeholder="(00) 00000-0000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Endereço</FormLabel>
                    <FormControl>
                      <Input placeholder="Endereço completo" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="logo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Logo (URL)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://exemplo.com/logo.png" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Ativo</FormLabel>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Observações sobre o cliente" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Salvando..." : "Salvar"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Dialog para bloquear cliente */}
      <Dialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bloquear Cliente</DialogTitle>
            <DialogDescription>Informe o motivo do bloqueio do cliente {clientToBlock?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="blockReason">Motivo do Bloqueio</Label>
              <Textarea
                id="blockReason"
                placeholder="Informe o motivo do bloqueio"
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBlockDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleBlockSubmit} disabled={!blockReason.trim()}>
              Bloquear
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Componente Label para o formulário de bloqueio
function Label({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) {
  return (
    <label
      htmlFor={htmlFor}
      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
    >
      {children}
    </label>
  )
}

