"use client"

import { useTheme } from "next-themes"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface OccupancyChartProps {
  className?: string
}

export function OccupancyChart({ className }: OccupancyChartProps) {
  const { theme } = useTheme()

  // Dados de exemplo - em produção, estes viriam da API
  const data = [
    { hour: "08:00", occupancy: 20 },
    { hour: "09:00", occupancy: 35 },
    { hour: "10:00", occupancy: 45 },
    { hour: "11:00", occupancy: 55 },
    { hour: "12:00", occupancy: 70 },
    { hour: "13:00", occupancy: 65 },
    { hour: "14:00", occupancy: 60 },
    { hour: "15:00", occupancy: 75 },
    { hour: "16:00", occupancy: 85 },
    { hour: "17:00", occupancy: 90 },
    { hour: "18:00", occupancy: 80 },
    { hour: "19:00", occupancy: 60 },
    { hour: "20:00", occupancy: 40 },
  ]

  return (
    <Card className={cn("col-span-4", className)}>
      <CardHeader>
        <CardTitle>Ocupação por Hora</CardTitle>
        <CardDescription>Percentual de ocupação do estacionamento ao longo do dia</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <XAxis dataKey="hour" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `${value}%`}
            />
            <Tooltip
              formatter={(value: number) => [`${value}%`, "Ocupação"]}
              contentStyle={{
                backgroundColor: theme === "dark" ? "#1f2937" : "#ffffff",
                borderColor: theme === "dark" ? "#374151" : "#e5e7eb",
              }}
            />
            <Bar dataKey="occupancy" fill="currentColor" radius={[4, 4, 0, 0]} className="fill-primary" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

