"use client"

import { useState } from "react"
import Link from "next/link"
import type { ParkingRecord } from "@/types"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { formatDateTime, formatTimeAgo, maskPlate } from "@/lib/utils"

interface ParkedVehiclesTableProps {
  vehicles: ParkingRecord[]
}

export function ParkedVehiclesTable({ vehicles }: ParkedVehiclesTableProps) {
  const [sortColumn, setSortColumn] = useState<string>("entryDate")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortColumn(column)
      setSortDirection("asc")
    }
  }

  const sortedVehicles = [...vehicles].sort((a, b) => {
    if (sortColumn === "entryDate") {
      return sortDirection === "asc"
        ? new Date(a.entryDate).getTime() - new Date(b.entryDate).getTime()
        : new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime()
    }
    if (sortColumn === "plate") {
      return sortDirection === "asc"
        ? a.vehicle!.plate.localeCompare(b.vehicle!.plate)
        : b.vehicle!.plate.localeCompare(a.vehicle!.plate)
    }
    if (sortColumn === "model") {
      return sortDirection === "asc"
        ? a.vehicle!.model.localeCompare(b.vehicle!.model)
        : b.vehicle!.model.localeCompare(a.vehicle!.model)
    }
    return 0
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle>Veículos Estacionados</CardTitle>
        <CardDescription>Lista de veículos atualmente no estacionamento</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="cursor-pointer" onClick={() => handleSort("plate")}>
                Placa
                {sortColumn === "plate" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("model")}>
                Modelo
                {sortColumn === "model" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
              </TableHead>
              <TableHead>Cor</TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("entryDate")}>
                Entrada
                {sortColumn === "entryDate" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
              </TableHead>
              <TableHead>Tempo</TableHead>
              <TableHead>Serviço</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedVehicles.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center">
                  Nenhum veículo estacionado no momento
                </TableCell>
              </TableRow>
            ) : (
              sortedVehicles.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">{maskPlate(record.vehicle!.plate)}</TableCell>
                  <TableCell>{record.vehicle!.model}</TableCell>
                  <TableCell>{record.vehicle!.color}</TableCell>
                  <TableCell>{formatDateTime(record.entryDate)}</TableCell>
                  <TableCell>{formatTimeAgo(record.entryDate)}</TableCell>
                  <TableCell>
                    {record.service!.type === "hourly"
                      ? "Hora"
                      : record.service!.type === "daily"
                        ? "Diária"
                        : "Mensalista"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Link href={`/parking/exit/${record.id}`}>
                      <Button size="sm" variant="outline">
                        Saída
                      </Button>
                    </Link>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

