"use client"

import { useTheme } from "next-themes"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface RevenueChartProps {
  className?: string
}

export function RevenueChart({ className }: RevenueChartProps) {
  const { theme } = useTheme()

  // Dados de exemplo - em produção, estes viriam da API
  const data = [
    { day: "Seg", revenue: 1200 },
    { day: "Ter", revenue: 1400 },
    { day: "Qua", revenue: 1300 },
    { day: "Qui", revenue: 1500 },
    { day: "Sex", revenue: 2100 },
    { day: "Sáb", revenue: 1800 },
    { day: "Dom", revenue: 1000 },
  ]

  return (
    <Card className={cn("col-span-3", className)}>
      <CardHeader>
        <CardTitle>Receita Semanal</CardTitle>
        <CardDescription>Receita diária dos últimos 7 dias</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="day" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `R$${value}`}
            />
            <Tooltip
              formatter={(value: number) => [`R$${value.toFixed(2)}`, "Receita"]}
              contentStyle={{
                backgroundColor: theme === "dark" ? "#1f2937" : "#ffffff",
                borderColor: theme === "dark" ? "#374151" : "#e5e7eb",
              }}
            />
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="currentColor"
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
              className="stroke-primary"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

