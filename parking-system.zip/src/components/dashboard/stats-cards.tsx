import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/utils"
import { Car, CreditCard, Percent, TrendingUp } from "lucide-react"

interface StatsCardsProps {
  totalVehicles: number
  availableSpots: number
  dailyRevenue: number
  monthlyRevenue: number
}

export function StatsCards({ totalVehicles, availableSpots, dailyRevenue, monthlyRevenue }: StatsCardsProps) {
  // Calcular a ocupação em porcentagem
  const totalSpots = totalVehicles + availableSpots
  const occupancyRate = totalSpots > 0 ? Math.round((totalVehicles / totalSpots) * 100) : 0

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Veículos Estacionados</CardTitle>
          <Car className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalVehicles}</div>
          <p className="text-xs text-muted-foreground">{availableSpots} vagas disponíveis</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Taxa de Ocupação</CardTitle>
          <Percent className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{occupancyRate}%</div>
          <p className="text-xs text-muted-foreground">
            {totalVehicles} de {totalSpots} vagas
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receita Diária</CardTitle>
          <CreditCard className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatCurrency(dailyRevenue)}</div>
          <p className="text-xs text-muted-foreground">+10% em relação a ontem</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatCurrency(monthlyRevenue)}</div>
          <p className="text-xs text-muted-foreground">+15% em relação ao mês anterior</p>
        </CardContent>
      </Card>
    </>
  )
}

