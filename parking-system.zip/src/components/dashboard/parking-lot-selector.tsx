"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { ParkingLot } from "@/types"
import { cn } from "@/lib/utils"

interface ParkingLotSelectorProps {
  parkingLots: ParkingLot[]
  defaultValue: string
  className?: string
}

export function ParkingLotSelector({ parkingLots, defaultValue, className }: ParkingLotSelectorProps) {
  const router = useRouter()
  const [selectedParkingLot, setSelectedParkingLot] = useState(defaultValue)

  const handleParkingLotChange = (value: string) => {
    setSelectedParkingLot(value)
    router.push(`/dashboard?parkingLotId=${value}`)
    router.refresh()
  }

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      <p className="text-sm font-medium">Estacionamento:</p>
      <Select value={selectedParkingLot} onValueChange={handleParkingLotChange}>
        <SelectTrigger className="w-[240px]">
          <SelectValue placeholder="Selecione um estacionamento" />
        </SelectTrigger>
        <SelectContent>
          {parkingLots.map((parkingLot) => (
            <SelectItem key={parkingLot.id} value={parkingLot.id}>
              {parkingLot.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

