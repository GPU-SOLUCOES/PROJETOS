"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import type { ServiceType } from "@/types"
import { formatCurrency } from "@/lib/utils"
import { Pencil, Trash2, PlusCircle } from "lucide-react"

const serviceFormSchema = z.object({
  type: z.enum(["hourly", "daily", "monthly"], {
    required_error: "Selecione um tipo de serviço",
  }),
  value: z.coerce.number().min(0.01, { message: "Valor deve ser maior que 0" }),
  parkingLotId: z.string().min(1, { message: "Selecione um estacionamento" }),
})

type ServiceFormValues = z.infer<typeof serviceFormSchema>

interface Service {
  id: string
  type: ServiceType
  value: number
  parkingLotId: string
  parkingLot: {
    name: string
  }
}

interface ParkingLot {
  id: string
  name: string
}

export function ServiceManagement() {
  const { toast } = useToast()
  const [services, setServices] = useState<Service[]>([])
  const [parkingLots, setParkingLots] = useState<ParkingLot[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingService, setEditingService] = useState<Service | null>(null)

  const form = useForm<ServiceFormValues>({
    resolver: zodResolver(serviceFormSchema),
    defaultValues: {
      type: "hourly",
      value: 0,
      parkingLotId: "",
    },
  })

  useEffect(() => {
    fetchServices()
    fetchParkingLots()
  }, [])

  useEffect(() => {
    if (editingService) {
      form.reset({
        type: editingService.type,
        value: editingService.value,
        parkingLotId: editingService.parkingLotId,
      })
    } else {
      form.reset({
        type: "hourly",
        value: 0,
        parkingLotId: parkingLots.length > 0 ? parkingLots[0].id : "",
      })
    }
  }, [editingService, form, parkingLots])

  async function fetchServices() {
    try {
      const response = await fetch("/api/services")
      if (!response.ok) {
        throw new Error("Erro ao carregar serviços")
      }
      const data = await response.json()
      setServices(data)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os serviços",
      })
    }
  }

  async function fetchParkingLots() {
    try {
      const response = await fetch("/api/parking-lots")
      if (!response.ok) {
        throw new Error("Erro ao carregar estacionamentos")
      }
      const data = await response.json()
      setParkingLots(data)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os estacionamentos",
      })
    }
  }

  async function onSubmit(values: ServiceFormValues) {
    setIsLoading(true)

    try {
      const url = editingService ? `/api/services/${editingService.id}` : "/api/services"

      const method = editingService ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Erro ao salvar serviço")
      }

      toast({
        title: "Sucesso",
        description: editingService ? "Serviço atualizado com sucesso" : "Serviço criado com sucesso",
      })

      setIsDialogOpen(false)
      fetchServices()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao salvar o serviço",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function handleDeleteService(id: string) {
    if (!confirm("Tem certeza que deseja excluir este serviço?")) {
      return
    }

    try {
      const response = await fetch(`/api/services/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Erro ao excluir serviço")
      }

      toast({
        title: "Sucesso",
        description: "Serviço excluído com sucesso",
      })

      fetchServices()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir o serviço",
      })
    }
  }

  function handleEditService(service: Service) {
    setEditingService(service)
    setIsDialogOpen(true)
  }

  function handleAddService() {
    setEditingService(null)
    setIsDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddService}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Adicionar Serviço
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingService ? "Editar Serviço" : "Adicionar Serviço"}</DialogTitle>
              <DialogDescription>
                {editingService
                  ? "Edite as informações do serviço abaixo"
                  : "Preencha as informações para adicionar um novo serviço"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="parkingLotId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estacionamento</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione um estacionamento" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {parkingLots.map((parkingLot) => (
                            <SelectItem key={parkingLot.id} value={parkingLot.id}>
                              {parkingLot.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Serviço</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione um tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="hourly">Hora</SelectItem>
                          <SelectItem value="daily">Diária</SelectItem>
                          <SelectItem value="monthly">Mensalista</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="value"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valor (R$)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" min="0" placeholder="0.00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Salvando..." : "Salvar"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Estacionamento</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Valor</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {services.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center">
                  Nenhum serviço encontrado
                </TableCell>
              </TableRow>
            ) : (
              services.map((service) => (
                <TableRow key={service.id}>
                  <TableCell>{service.parkingLot.name}</TableCell>
                  <TableCell>
                    {service.type === "hourly" ? "Hora" : service.type === "daily" ? "Diária" : "Mensalista"}
                  </TableCell>
                  <TableCell>{formatCurrency(service.value)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleEditService(service)}>
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Editar</span>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteService(service.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                      <span className="sr-only">Excluir</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

