"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Pencil, Trash2, PlusCircle } from "lucide-react"

const parkingLotFormSchema = z.object({
  name: z.string().min(3, { message: "Nome deve ter pelo menos 3 caracteres" }),
  address: z.string().min(5, { message: "Endereço deve ter pelo menos 5 caracteres" }),
  capacity: z.coerce.number().min(1, { message: "Capacidade deve ser maior que 0" }),
  openingTime: z.string().optional(),
  closingTime: z.string().optional(),
})

type ParkingLotFormValues = z.infer<typeof parkingLotFormSchema>

interface ParkingLot {
  id: string
  name: string
  address: string
  capacity: number
  openingTime?: string
  closingTime?: string
}

export function ParkingLotManagement() {
  const { toast } = useToast()
  const [parkingLots, setParkingLots] = useState<ParkingLot[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingParkingLot, setEditingParkingLot] = useState<ParkingLot | null>(null)

  const form = useForm<ParkingLotFormValues>({
    resolver: zodResolver(parkingLotFormSchema),
    defaultValues: {
      name: "",
      address: "",
      capacity: 0,
      openingTime: "08:00",
      closingTime: "18:00",
    },
  })

  useEffect(() => {
    fetchParkingLots()
  }, [])

  useEffect(() => {
    if (editingParkingLot) {
      form.reset({
        name: editingParkingLot.name,
        address: editingParkingLot.address,
        capacity: editingParkingLot.capacity,
        openingTime: editingParkingLot.openingTime || "08:00",
        closingTime: editingParkingLot.closingTime || "18:00",
      })
    } else {
      form.reset({
        name: "",
        address: "",
        capacity: 0,
        openingTime: "08:00",
        closingTime: "18:00",
      })
    }
  }, [editingParkingLot, form])

  async function fetchParkingLots() {
    try {
      const response = await fetch("/api/parking-lots")
      if (!response.ok) {
        throw new Error("Erro ao carregar estacionamentos")
      }
      const data = await response.json()
      setParkingLots(data)
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os estacionamentos",
      })
    }
  }

  async function onSubmit(values: ParkingLotFormValues) {
    setIsLoading(true)

    try {
      const url = editingParkingLot ? `/api/parking-lots/${editingParkingLot.id}` : "/api/parking-lots"

      const method = editingParkingLot ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Erro ao salvar estacionamento")
      }

      toast({
        title: "Sucesso",
        description: editingParkingLot ? "Estacionamento atualizado com sucesso" : "Estacionamento criado com sucesso",
      })

      setIsDialogOpen(false)
      fetchParkingLots()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao salvar o estacionamento",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function handleDeleteParkingLot(id: string) {
    if (!confirm("Tem certeza que deseja excluir este estacionamento?")) {
      return
    }

    try {
      const response = await fetch(`/api/parking-lots/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Erro ao excluir estacionamento")
      }

      toast({
        title: "Sucesso",
        description: "Estacionamento excluído com sucesso",
      })

      fetchParkingLots()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir o estacionamento",
      })
    }
  }

  function handleEditParkingLot(parkingLot: ParkingLot) {
    setEditingParkingLot(parkingLot)
    setIsDialogOpen(true)
  }

  function handleAddParkingLot() {
    setEditingParkingLot(null)
    setIsDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddParkingLot}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Adicionar Estacionamento
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingParkingLot ? "Editar Estacionamento" : "Adicionar Estacionamento"}</DialogTitle>
              <DialogDescription>
                {editingParkingLot
                  ? "Edite as informações do estacionamento abaixo"
                  : "Preencha as informações para adicionar um novo estacionamento"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome</FormLabel>
                      <FormControl>
                        <Input placeholder="Nome do estacionamento" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Endereço</FormLabel>
                      <FormControl>
                        <Input placeholder="Endereço completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Capacidade (vagas)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" placeholder="Número de vagas" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="openingTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Horário de Abertura</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="closingTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Horário de Fechamento</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Salvando..." : "Salvar"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Endereço</TableHead>
              <TableHead>Capacidade</TableHead>
              <TableHead>Horário</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {parkingLots.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center">
                  Nenhum estacionamento encontrado
                </TableCell>
              </TableRow>
            ) : (
              parkingLots.map((parkingLot) => (
                <TableRow key={parkingLot.id}>
                  <TableCell className="font-medium">{parkingLot.name}</TableCell>
                  <TableCell>{parkingLot.address}</TableCell>
                  <TableCell>{parkingLot.capacity} vagas</TableCell>
                  <TableCell>
                    {parkingLot.openingTime && parkingLot.closingTime
                      ? `${parkingLot.openingTime} - ${parkingLot.closingTime}`
                      : "24 horas"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleEditParkingLot(parkingLot)}>
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Editar</span>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteParkingLot(parkingLot.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                      <span className="sr-only">Excluir</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

