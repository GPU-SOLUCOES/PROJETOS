"use client"

import { useState, useEffect } from "react"
import { ChevronDown } from "lucide-react"
import type { ParkingLot } from "@/types"

interface ParkingLotSelectorProps {
  parkingLots: ParkingLot[]
  selectedParkingLotId: string
  onChange: (parkingLotId: string) => void
}

export default function ParkingLotSelector({ parkingLots, selectedParkingLotId, onChange }: ParkingLotSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedLot, setSelectedLot] = useState<ParkingLot | null>(null)

  useEffect(() => {
    const lot = parkingLots.find((lot) => lot.id === selectedParkingLotId)
    if (lot) {
      setSelectedLot(lot)
    }
  }, [parkingLots, selectedParkingLotId])

  const handleSelect = (parkingLotId: string) => {
    onChange(parkingLotId)
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <button
        type="button"
        className="inline-flex justify-between items-center w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>{selectedLot?.name || "Selecione um estacionamento"}</span>
        <ChevronDown className="ml-2 h-5 w-5 text-gray-400" aria-hidden="true" />
      </button>

      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-full rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
          <div
            className="py-1 max-h-60 overflow-auto"
            role="menu"
            aria-orientation="vertical"
            aria-labelledby="options-menu"
          >
            {parkingLots.map((lot) => (
              <button
                key={lot.id}
                className={`${
                  lot.id === selectedParkingLotId ? "bg-gray-100 text-gray-900" : "text-gray-700"
                } block px-4 py-2 text-sm w-full text-left hover:bg-gray-100`}
                role="menuitem"
                onClick={() => handleSelect(lot.id)}
              >
                {lot.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

