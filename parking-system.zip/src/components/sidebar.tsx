"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useSession } from "next-auth/react"
import { cn } from "@/lib/utils"
import { Car, LayoutDashboard, LogOut, Settings, FileText, Building, CreditCard } from "lucide-react"

export function Sidebar() {
  const pathname = usePathname()
  const { data: session } = useSession()

  const isSuperAdmin = session?.user?.role === "super_admin"
  const isAdmin = session?.user?.role === "admin" || session?.user?.role === "gerente"

  const routes = [
    {
      href: "/dashboard",
      icon: LayoutDashboard,
      title: "Dashboard",
      variant: "default",
    },
    {
      href: "/parking/entry",
      icon: Car,
      title: "Entrada de Veículo",
      variant: "ghost",
    },
  ]

  // Adicionar rotas de admin/gerente
  if (isAdmin || isSuperAdmin) {
    routes.push(
      {
        href: "/admin",
        icon: Settings,
        title: "Administração",
        variant: "ghost",
      },
      {
        href: "/financeiro",
        icon: CreditCard,
        title: "Financeiro",
        variant: "ghost",
      },
    )
  }

  // Adicionar rotas de super admin
  if (isSuperAdmin) {
    routes.unshift(
      {
        href: "/super-admin/dashboard",
        icon: FileText,
        title: "Dashboard Financeiro",
        variant: "ghost",
      },
      {
        href: "/super-admin/clients",
        icon: Building,
        title: "Gerenciar Clientes",
        variant: "ghost",
      },
    )
  }

  return (
    <aside className="fixed top-14 z-30 -ml-2 hidden h-[calc(100vh-3.5rem)] w-full shrink-0 md:sticky md:block">
      <div className="relative h-full w-full p-4">
        <nav className="flex flex-col space-y-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                pathname === route.href ? "bg-accent text-accent-foreground" : "transparent",
              )}
            >
              <route.icon className="mr-2 h-4 w-4" />
              {route.title}
            </Link>
          ))}

          <Link
            href="/api/auth/signout"
            className="flex items-center rounded-md px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Link>
        </nav>
      </div>
    </aside>
  )
}

