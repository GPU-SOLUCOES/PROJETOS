"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"

const clientSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(10, "Telefone inválido").optional(),
  address: z.string().min(5, "Endereço inválido").optional(),
  adminName: z.string().min(3, "Nome do administrador deve ter pelo menos 3 caracteres"),
  adminEmail: z.string().email("Email do administrador inválido"),
  adminPassword: z.string().min(8, "A senha deve ter pelo menos 8 caracteres"),
  termsAccepted: z.literal(true, {
    errorMap: () => ({ message: "Você deve aceitar os termos de serviço" }),
  }),
})

type RegisterFormValues = z.infer<typeof clientSchema>

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const planId = searchParams.get("plan")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [currentStep, setCurrentStep] = useState("client")

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<RegisterFormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      termsAccepted: false,
    },
  })

  const termsAccepted = watch("termsAccepted")

  const onSubmit = async (data: RegisterFormValues) => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          planId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao registrar")
      }

      // Redirecionar para a página de pagamento
      const result = await response.json()
      router.push(`/payment?subscriptionId=${result.subscriptionId}`)
    } catch (error) {
      setError(error.message || "Ocorreu um erro ao registrar. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4 py-12">
      <div className="w-full max-w-3xl">
        <Card className="shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Cadastre sua Empresa</CardTitle>
            <CardDescription className="text-center">
              Preencha os dados abaixo para criar sua conta no sistema de estacionamento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Tabs value={currentStep} onValueChange={setCurrentStep}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="client">Dados da Empresa</TabsTrigger>
                  <TabsTrigger value="admin">Dados do Administrador</TabsTrigger>
                </TabsList>
                <TabsContent value="client" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome da Empresa *</Label>
                    <Input
                      id="name"
                      placeholder="Nome da sua empresa"
                      {...register("name")}
                      className={errors.name ? "border-red-500" : ""}
                    />
                    {errors.name && <p className="text-sm text-red-500">{errors.name.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Corporativo *</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="email@empresa.com"
                      {...register("email")}
                      className={errors.email ? "border-red-500" : ""}
                    />
                    {errors.email && <p className="text-sm text-red-500">{errors.email.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      placeholder="(00) 00000-0000"
                      {...register("phone")}
                      className={errors.phone ? "border-red-500" : ""}
                    />
                    {errors.phone && <p className="text-sm text-red-500">{errors.phone.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Endereço</Label>
                    <Textarea
                      id="address"
                      placeholder="Endereço completo"
                      {...register("address")}
                      className={errors.address ? "border-red-500" : ""}
                    />
                    {errors.address && <p className="text-sm text-red-500">{errors.address.message}</p>}
                  </div>
                  <Button type="button" onClick={() => setCurrentStep("admin")} className="w-full">
                    Próximo
                  </Button>
                </TabsContent>
                <TabsContent value="admin" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="adminName">Nome do Administrador *</Label>
                    <Input
                      id="adminName"
                      placeholder="Nome completo"
                      {...register("adminName")}
                      className={errors.adminName ? "border-red-500" : ""}
                    />
                    {errors.adminName && <p className="text-sm text-red-500">{errors.adminName.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="adminEmail">Email do Administrador *</Label>
                    <Input
                      id="adminEmail"
                      type="email"
                      placeholder="admin@email.com"
                      {...register("adminEmail")}
                      className={errors.adminEmail ? "border-red-500" : ""}
                    />
                    {errors.adminEmail && <p className="text-sm text-red-500">{errors.adminEmail.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="adminPassword">Senha *</Label>
                    <Input
                      id="adminPassword"
                      type="password"
                      placeholder="********"
                      {...register("adminPassword")}
                      className={errors.adminPassword ? "border-red-500" : ""}
                    />
                    {errors.adminPassword && <p className="text-sm text-red-500">{errors.adminPassword.message}</p>}
                  </div>
                  <div className="flex items-center space-x-2 mt-4">
                    <Checkbox
                      id="termsAccepted"
                      {...register("termsAccepted")}
                      checked={termsAccepted}
                      onCheckedChange={(checked) => {
                        // O hook form não atualiza automaticamente com o Checkbox do shadcn
                        // Esta é uma solução alternativa
                      }}
                    />
                    <label
                      htmlFor="termsAccepted"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Eu aceito os{" "}
                      <a href="/terms" className="text-blue-500 hover:text-blue-700">
                        termos de serviço
                      </a>{" "}
                      e a{" "}
                      <a href="/privacy" className="text-blue-500 hover:text-blue-700">
                        política de privacidade
                      </a>
                    </label>
                  </div>
                  {errors.termsAccepted && <p className="text-sm text-red-500">{errors.termsAccepted.message}</p>}
                  <div className="flex space-x-2">
                    <Button type="button" variant="outline" onClick={() => setCurrentStep("client")} className="flex-1">
                      Voltar
                    </Button>
                    <Button type="submit" className="flex-1" disabled={isLoading}>
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Registrando...
                        </>
                      ) : (
                        "Finalizar Cadastro"
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-gray-500">
              Já tem uma conta?{" "}
              <a href="/login" className="text-blue-500 hover:text-blue-700">
                Faça login
              </a>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

