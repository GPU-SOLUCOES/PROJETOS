import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { ParkingLotSelector } from "@/components/dashboard/parking-lot-selector"
import { OccupancyChart } from "@/components/dashboard/occupancy-chart"
import { RevenueChart } from "@/components/dashboard/revenue-chart"
import { ParkedVehiclesTable } from "@/components/dashboard/parked-vehicles-table"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  // Buscar estacionamentos do cliente
  const parkingLots = await prisma.parkingLot.findMany({
    where: {
      clientId: session.user.clientId as string,
    },
    orderBy: {
      name: "asc",
    },
  })

  // Se não houver estacionamentos, redirecionar para página de configuração
  if (parkingLots.length === 0) {
    redirect("/dashboard/setup")
  }

  // Buscar estatísticas do primeiro estacionamento (padrão)
  const defaultParkingLot = parkingLots[0]

  // Contar veículos estacionados
  const parkedVehicles = await prisma.parkingRecord.count({
    where: {
      parkingLotId: defaultParkingLot.id,
      exitDate: null,
    },
  })

  // Calcular vagas disponíveis
  const availableSpots = defaultParkingLot.capacity - parkedVehicles

  // Buscar receita diária
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const dailyRevenue = await prisma.parkingRecord.aggregate({
    where: {
      parkingLotId: defaultParkingLot.id,
      exitDate: {
        gte: today,
      },
    },
    _sum: {
      paidAmount: true,
    },
  })

  // Buscar receita mensal
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)

  const monthlyRevenue = await prisma.parkingRecord.aggregate({
    where: {
      parkingLotId: defaultParkingLot.id,
      exitDate: {
        gte: firstDayOfMonth,
      },
    },
    _sum: {
      paidAmount: true,
    },
  })

  // Buscar veículos estacionados no momento
  const currentlyParkedVehicles = await prisma.parkingRecord.findMany({
    where: {
      parkingLotId: defaultParkingLot.id,
      exitDate: null,
    },
    include: {
      vehicle: true,
      service: true,
    },
    orderBy: {
      entryDate: "desc",
    },
    take: 10,
  })

  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" text="Visão geral do seu estacionamento" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCards
          totalVehicles={parkedVehicles}
          availableSpots={availableSpots}
          dailyRevenue={dailyRevenue._sum.paidAmount?.toNumber() || 0}
          monthlyRevenue={monthlyRevenue._sum.paidAmount?.toNumber() || 0}
        />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <ParkingLotSelector parkingLots={parkingLots} defaultValue={defaultParkingLot.id} className="lg:col-span-7" />
        <OccupancyChart className="lg:col-span-4" />
        <RevenueChart className="lg:col-span-3" />
      </div>
      <div>
        <ParkedVehiclesTable vehicles={currentlyParkedVehicles} />
      </div>
    </DashboardShell>
  )
}

