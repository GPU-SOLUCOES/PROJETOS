import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"
import { prisma } from "@/lib/prisma"

export const metadata = {
  title: "Planos e Preços | Sistema de Estacionamento",
  description: "Conheça nossos planos e escolha o melhor para o seu negócio",
}

export default async function PricingPage() {
  // Buscar planos ativos do banco de dados
  const plans = await prisma.plan.findMany({
    where: {
      active: true,
    },
    orderBy: {
      price: "asc",
    },
  })

  return (
    <div className="container mx-auto py-16 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl mb-4">Planos e Preços</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Escolha o plano ideal para o seu negócio. Todos os planos incluem acesso ao aplicativo móvel e suporte
          técnico.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`flex flex-col ${plan.name === "Profissional" ? "border-primary shadow-lg" : ""}`}
          >
            <CardHeader>
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <div className="mb-6">
                <span className="text-4xl font-bold">R$ {Number(plan.price).toFixed(2)}</span>
                <span className="text-muted-foreground">/mês</span>
              </div>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                  <span>Até {plan.maxUsers} usuários</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                  <span>Até {plan.maxParkingLots} estacionamentos</span>
                </li>
                {plan.features &&
                  Object.entries(plan.features as Record<string, boolean>).map(
                    ([feature, included]) =>
                      included && (
                        <li key={feature} className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ),
                  )}
              </ul>
            </CardContent>
            <CardFooter>
              <Link href={`/register?plan=${plan.id}`} className="w-full">
                <Button variant={plan.name === "Profissional" ? "default" : "outline"} className="w-full">
                  {plan.name === "Profissional" ? "Escolher Plano Recomendado" : "Escolher Plano"}
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Precisa de um plano personalizado?</h2>
        <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
          Se você tem necessidades específicas ou precisa de mais recursos, entre em contato conosco para um plano
          personalizado.
        </p>
        <Link href="/contact">
          <Button variant="outline" size="lg">
            Fale Conosco
          </Button>
        </Link>
      </div>
    </div>
  )
}

