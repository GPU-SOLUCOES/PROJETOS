import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FinancialOverview } from "@/components/super-admin/financial-overview"
import { ClientsOverview } from "@/components/super-admin/clients-overview"
import { SystemStatus } from "@/components/super-admin/system-status"
import { formatCurrency } from "@/lib/utils"

export default async function SuperAdminDashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  // Verificar se o usuário é super admin
  if (session.user.role !== "super_admin") {
    redirect("/dashboard")
  }

  // Buscar estatísticas gerais
  const totalClients = await prisma.client.count()
  const activeClients = await prisma.client.count({
    where: { active: true, blocked: false },
  })
  const totalParkingLots = await prisma.parkingLot.count()
  const totalUsers = await prisma.user.count()

  // Buscar estatísticas financeiras
  const today = new Date()
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)

  const monthlyRevenue = await prisma.payment.aggregate({
    where: {
      date: {
        gte: firstDayOfMonth,
      },
      status: "paid",
    },
    _sum: {
      amount: true,
    },
  })

  const pendingPayments = await prisma.payment.aggregate({
    where: {
      status: "pending",
    },
    _sum: {
      amount: true,
    },
  })

  // Buscar clientes recentes
  const recentClients = await prisma.client.findMany({
    orderBy: {
      registrationDate: "desc",
    },
    take: 5,
    include: {
      _count: {
        select: {
          parkingLots: true,
          users: true,
        },
      },
    },
  })

  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard Financeiro" text="Visão geral do sistema e finanças" />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Ativos</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeClients}</div>
            <p className="text-xs text-muted-foreground">De um total de {totalClients} clientes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estacionamentos</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <rect width="20" height="14" x="2" y="5" rx="2" />
              <path d="M2 10h20" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalParkingLots}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round(totalParkingLots / (activeClients || 1))} por cliente em média
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(monthlyRevenue._sum.amount?.toNumber() || 0)}</div>
            <p className="text-xs text-muted-foreground">+12% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos Pendentes</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(pendingPayments._sum.amount?.toNumber() || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {pendingPayments._sum.amount?.toNumber() ? "Ação necessária" : "Nenhum pagamento pendente"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="clients">Clientes</TabsTrigger>
          <TabsTrigger value="system">Sistema</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <FinancialOverview />
        </TabsContent>
        <TabsContent value="clients" className="space-y-4">
          <ClientsOverview clients={recentClients} />
        </TabsContent>
        <TabsContent value="system" className="space-y-4">
          <SystemStatus />
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

