import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { ClientManagement } from "@/components/super-admin/client-management"

export default async function SuperAdminClientsPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  // Verificar se o usuário é super admin
  if (session.user.role !== "super_admin") {
    redirect("/dashboard")
  }

  // Buscar todos os clientes
  const clients = await prisma.client.findMany({
    orderBy: {
      name: "asc",
    },
    include: {
      _count: {
        select: {
          parkingLots: true,
          users: true,
        },
      },
    },
  })

  return (
    <DashboardShell>
      <DashboardHeader heading="Gerenciamento de Clientes" text="Gerencie os clientes e suas assinaturas" />
      <ClientManagement initialClients={clients} />
    </DashboardShell>
  )
}

