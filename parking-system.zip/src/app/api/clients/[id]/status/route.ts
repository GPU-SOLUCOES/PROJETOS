import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const id = params.id

    // Verificar permissões
    if (session.user.role !== "super_admin" && session.user.clientId !== id) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Buscar status do cliente
    const client = await prisma.client.findUnique({
      where: { id },
      select: {
        active: true,
        blocked: true,
        blockReason: true,
      },
    })

    if (!client) {
      return NextResponse.json({ error: "Cliente não encontrado" }, { status: 404 })
    }

    return NextResponse.json(client, { status: 200 })
  } catch (error) {
    console.error("Erro ao buscar status do cliente:", error)
    return NextResponse.json({ error: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Apenas super_admin pode alterar status de cliente
    if (session.user.role !== "super_admin") {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    const id = params.id
    const body = await request.json()
    const { active, blocked, blockReason } = body

    // Validar dados
    if (active === undefined && blocked === undefined) {
      return NextResponse.json({ error: "Nenhum campo para atualizar" }, { status: 400 })
    }

    // Se estiver bloqueando, exigir motivo
    if (blocked === true && !blockReason) {
      return NextResponse.json({ error: "Motivo do bloqueio é obrigatório" }, { status: 400 })
    }

    // Atualizar status do cliente
    const client = await prisma.client.update({
      where: { id },
      data: {
        active: active !== undefined ? active : undefined,
        blocked: blocked !== undefined ? blocked : undefined,
        blockReason: blocked === true ? blockReason : blocked === false ? null : undefined,
      },
    })

    // Registrar log de atividade
    await prisma.activityLog.create({
      data: {
        userId: session.user.id,
        action: "client_status_updated",
        details: `Status do cliente ${client.name} atualizado: ativo=${client.active}, bloqueado=${client.blocked}`,
        ip: "127.0.0.1", // Em produção, usar o IP real
      },
    })

    return NextResponse.json(client, { status: 200 })
  } catch (error) {
    console.error("Erro ao atualizar status do cliente:", error)
    return NextResponse.json({ error: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

