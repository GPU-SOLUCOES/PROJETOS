import { NextResponse } from "next/server"

export async function GET() {
  // Dados simulados de receita
  const dailyRevenue = [
    { date: "2025-03-20", amount: 980 },
    { date: "2025-03-21", amount: 1150 },
    { date: "2025-03-22", amount: 1320 },
    { date: "2025-03-23", amount: 890 },
    { date: "2025-03-24", amount: 1050 },
    { date: "2025-03-25", amount: 1180 },
    { date: "2025-03-26", amount: 1245 },
  ]

  const monthlyRevenue = [
    { month: "Jan", amount: 28500 },
    { month: "Fev", amount: 25800 },
    { month: "Mar", amount: 30200 },
    { month: "Abr", amount: 0 },
    { month: "Mai", amount: 0 },
    { month: "Jun", amount: 0 },
    { month: "Jul", amount: 0 },
    { month: "Ago", amount: 0 },
    { month: "Set", amount: 0 },
    { month: "Out", amount: 0 },
    { month: "Nov", amount: 0 },
    { month: "Dez", amount: 0 },
  ]

  const serviceDistribution = [
    { service: "Hora", percentage: 65 },
    { service: "Diária", percentage: 20 },
    { service: "Mensalista", percentage: 15 },
  ]

  const paymentMethods = [
    { method: "Dinheiro", percentage: 30 },
    { method: "Cartão de Crédito", percentage: 35 },
    { method: "Cartão de Débito", percentage: 20 },
    { method: "PIX", percentage: 15 },
  ]

  return NextResponse.json({
    dailyRevenue,
    monthlyRevenue,
    serviceDistribution,
    paymentMethods,
  })
}

