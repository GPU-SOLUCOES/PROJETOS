import { NextResponse } from "next/server"

export async function GET() {
  // Dados simulados de veículos estacionados
  const vehicles = [
    {
      id: "1",
      plate: "ABC1234",
      model: "Toyota Corolla",
      color: "Prata",
      entryTime: "2025-03-26T08:30:00Z",
      owner: "João Silva",
      service: "Hora",
      parkingLot: "Estacionamento Principal",
    },
    {
      id: "2",
      plate: "DEF5678",
      model: "Honda Civic",
      color: "Preto",
      entryTime: "2025-03-26T09:15:00Z",
      owner: "Maria Oliveira",
      service: "Diária",
      parkingLot: "Estacionamento Principal",
    },
    {
      id: "3",
      plate: "GHI9012",
      model: "Volkswagen Golf",
      color: "Branco",
      entryTime: "2025-03-26T10:00:00Z",
      owner: "Pedro Santos",
      service: "Hora",
      parkingLot: "Estacionamento Anexo",
    },
    {
      id: "4",
      plate: "JKL3456",
      model: "Fiat Uno",
      color: "Vermelho",
      entryTime: "2025-03-26T10:45:00Z",
      owner: "Ana Souza",
      service: "Mensalista",
      parkingLot: "Estacionamento Principal",
    },
    {
      id: "5",
      plate: "MNO7890",
      model: "Chevrolet Onix",
      color: "Azul",
      entryTime: "2025-03-26T11:30:00Z",
      owner: "Carlos Ferreira",
      service: "Hora",
      parkingLot: "Estacionamento Principal",
    },
  ]

  return NextResponse.json(vehicles)
}

