import { NextResponse } from "next/server"

export async function GET() {
  // Dados simulados de usuários
  const users = [
    {
      id: "1",
      name: "Admin Principal",
      email: "admin@estacionamento.com",
      role: "admin",
      lastAccess: "2025-03-26T09:30:00Z",
      status: "active",
    },
    {
      id: "2",
      name: "Gerente Operacional",
      email: "gerente@estacionamento.com",
      role: "manager",
      lastAccess: "2025-03-26T08:45:00Z",
      status: "active",
    },
    {
      id: "3",
      name: "Atendente 1",
      email: "atendente1@estacionamento.com",
      role: "attendant",
      lastAccess: "2025-03-26T10:15:00Z",
      status: "active",
    },
    {
      id: "4",
      name: "Atendente 2",
      email: "atendente2@estacionamento.com",
      role: "attendant",
      lastAccess: "2025-03-25T17:30:00Z",
      status: "active",
    },
    {
      id: "5",
      name: "Super Admin",
      email: "superadmin@sistema.com",
      role: "super_admin",
      lastAccess: "2025-03-26T11:00:00Z",
      status: "active",
    },
  ]

  return NextResponse.json(users)
}

