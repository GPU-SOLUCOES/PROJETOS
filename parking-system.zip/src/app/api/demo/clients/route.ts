import { NextResponse } from "next/server"

export async function GET() {
  // Dados simulados de clientes (empresas)
  const clients = [
    {
      id: "1",
      name: "Estacionamento Central Ltda",
      document: "12.345.678/0001-90",
      plan: "professional",
      active: true,
      blocked: false,
      createdAt: "2024-01-15T10:00:00Z",
      parkingLots: 2,
      users: 5,
      lastPayment: "2025-03-15T00:00:00Z",
      nextPayment: "2025-04-15T00:00:00Z",
    },
    {
      id: "2",
      name: "Park & Go Serviços de Estacionamento",
      document: "23.456.789/0001-01",
      plan: "enterprise",
      active: true,
      blocked: false,
      createdAt: "2024-02-10T14:30:00Z",
      parkingLots: 5,
      users: 12,
      lastPayment: "2025-03-10T00:00:00Z",
      nextPayment: "2025-04-10T00:00:00Z",
    },
    {
      id: "3",
      name: "Estacione Aqui Comércio e Serviços",
      document: "34.567.890/0001-12",
      plan: "basic",
      active: true,
      blocked: false,
      createdAt: "2024-03-05T09:15:00Z",
      parkingLots: 1,
      users: 2,
      lastPayment: "2025-03-05T00:00:00Z",
      nextPayment: "2025-04-05T00:00:00Z",
    },
    {
      id: "4",
      name: "Vagas Rápidas Estacionamentos",
      document: "45.678.901/0001-23",
      plan: "professional",
      active: false,
      blocked: true,
      blockReason: "Falta de pagamento",
      createdAt: "2024-01-20T11:45:00Z",
      parkingLots: 2,
      users: 4,
      lastPayment: "2025-02-20T00:00:00Z",
      nextPayment: "2025-03-20T00:00:00Z",
    },
    {
      id: "5",
      name: "Estacionamento Seguro S.A.",
      document: "56.789.012/0001-34",
      plan: "enterprise",
      active: true,
      blocked: false,
      createdAt: "2024-02-25T16:00:00Z",
      parkingLots: 8,
      users: 20,
      lastPayment: "2025-03-25T00:00:00Z",
      nextPayment: "2025-04-25T00:00:00Z",
    },
  ]

  return NextResponse.json(clients)
}

