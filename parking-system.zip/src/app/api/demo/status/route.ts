import { NextResponse } from "next/server"

export async function GET() {
  // Simulação de verificação de status dos serviços
  const services = {
    api: { status: "online", latency: 45 },
    database: { status: "online", latency: 78 },
    email: { status: "online", latency: 120 },
    payment: { status: "online", latency: 230 },
  }

  // Simulação de estatísticas do sistema
  const stats = {
    activeUsers: 12,
    parkedVehicles: 45,
    todayTransactions: 87,
    todayRevenue: 1245.0,
    availableSpots: 55,
    occupancyRate: 45,
  }

  // Simulação de informações do ambiente
  const environment = {
    name: "homologation",
    version: "1.0.0",
    lastUpdate: "2025-03-26T10:30:00Z",
    status: "ready",
  }

  return NextResponse.json({
    services,
    stats,
    environment,
    timestamp: new Date().toISOString(),
  })
}

