import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import bcrypt from "bcryptjs"
import { UserRole } from "@/types"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, address, adminName, adminEmail, adminPassword, planId } = body

    // Validar dados
    if (!name || !email || !adminName || !adminEmail || !adminPassword) {
      return NextResponse.json({ error: "Todos os campos obrigatórios devem ser preenchidos" }, { status: 400 })
    }

    // Verificar se o email já está em uso
    const existingUser = await prisma.user.findUnique({
      where: { email: adminEmail },
    })

    if (existingUser) {
      return NextResponse.json({ error: "Este email já está em uso" }, { status: 400 })
    }

    // Verificar se o plano existe
    if (planId) {
      const plan = await prisma.plan.findUnique({
        where: { id: planId },
      })

      if (!plan || !plan.active) {
        return NextResponse.json({ error: "Plano inválido ou inativo" }, { status: 400 })
      }
    }

    // Criar cliente, usuário e assinatura em uma transação
    const result = await prisma.$transaction(async (prisma) => {
      // Criar cliente
      const client = await prisma.client.create({
        data: {
          name,
          email,
          phone,
          address,
          active: true,
          blocked: false,
          registrationDate: new Date(),
        },
      })

      // Hash da senha
      const hashedPassword = await bcrypt.hash(adminPassword, 10)

      // Criar usuário administrador
      await prisma.user.create({
        data: {
          name: adminName,
          email: adminEmail,
          password: hashedPassword,
          role: UserRole.ADMIN,
          clientId: client.id,
        },
      })

      // Se um plano foi selecionado, criar assinatura
      let subscription = null
      if (planId) {
        const plan = await prisma.plan.findUnique({
          where: { id: planId },
        })

        if (plan) {
          const startDate = new Date()
          const endDate = new Date()
          endDate.setMonth(endDate.getMonth() + plan.duration)

          subscription = await prisma.subscription.create({
            data: {
              clientId: client.id,
              planId: plan.id,
              startDate,
              endDate,
              status: "pending",
              autoRenew: true,
              price: plan.price,
            },
          })
        }
      }

      // Registrar log de atividade
      await prisma.activityLog.create({
        data: {
          userId: "system", // ID especial para ações do sistema
          action: "client_registered",
          details: `Cliente ${name} registrado com sucesso`,
          ip: "127.0.0.1", // Em produção, usar o IP real
        },
      })

      return { clientId: client.id, subscriptionId: subscription?.id }
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    console.error("Erro ao registrar:", error)
    return NextResponse.json({ error: "Erro ao processar o registro" }, { status: 500 })
  }
}

