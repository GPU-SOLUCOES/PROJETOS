import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import Stripe from "stripe"

// Inicializar Stripe
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" })
  : null

export async function GET(request: Request) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Obter parâmetros da URL
    const { searchParams } = new URL(request.url)
    const clientId = searchParams.get("clientId") || session.user.clientId

    // Verificar permissões
    if (session.user.role !== "super_admin" && session.user.clientId !== clientId) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Buscar assinaturas
    const subscriptions = await prisma.subscription.findMany({
      where: {
        clientId: clientId as string,
      },
      include: {
        plan: true,
        payments: {
          orderBy: {
            date: "desc",
          },
          take: 5,
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return NextResponse.json(subscriptions, { status: 200 })
  } catch (error) {
    console.error("Erro ao listar assinaturas:", error)
    return NextResponse.json({ error: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const body = await request.json()
    const { planId, clientId, paymentMethod, autoRenew = true } = body

    // Validar dados
    if (!planId || !clientId || !paymentMethod) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Verificar permissões
    if (session.user.role !== "super_admin" && session.user.clientId !== clientId) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Buscar plano
    const plan = await prisma.plan.findUnique({
      where: { id: planId },
    })

    if (!plan || !plan.active) {
      return NextResponse.json({ error: "Plano não encontrado ou inativo" }, { status: 404 })
    }

    // Calcular datas
    const startDate = new Date()
    const endDate = new Date()
    endDate.setMonth(endDate.getMonth() + plan.duration)

    // Processar pagamento com Stripe
    let paymentIntentId = null
    let clientSecret = null

    if (stripe) {
      try {
        // Criar um PaymentIntent no Stripe
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(Number(plan.price) * 100), // Stripe trabalha com centavos
          currency: "brl",
          description: `Assinatura do plano ${plan.name} para cliente ${clientId}`,
          metadata: {
            clientId,
            planId,
            planName: plan.name,
          },
        })

        paymentIntentId = paymentIntent.id
        clientSecret = paymentIntent.client_secret
      } catch (stripeError) {
        console.error("Erro ao processar pagamento com Stripe:", stripeError)
        return NextResponse.json({ error: "Erro ao processar pagamento" }, { status: 400 })
      }
    }

    // Criar assinatura no banco de dados
    const result = await prisma.$transaction(async (prisma) => {
      // Inserir assinatura
      const subscription = await prisma.subscription.create({
        data: {
          clientId,
          planId,
          startDate,
          endDate,
          status: "pending",
          autoRenew,
          price: plan.price,
        },
      })

      // Inserir pagamento
      await prisma.payment.create({
        data: {
          subscriptionId: subscription.id,
          amount: plan.price,
          date: new Date(),
          status: "pending",
          paymentMethod,
          transactionId: paymentIntentId,
        },
      })

      return {
        subscriptionId: subscription.id,
        paymentIntentId,
        clientSecret,
      }
    })

    // Registrar log de atividade
    await prisma.activityLog.create({
      data: {
        userId: session.user.id,
        action: "subscription_created",
        details: `Assinatura criada para o cliente ${clientId}, plano ${plan.name}`,
        ip: "127.0.0.1", // Em produção, usar o IP real
      },
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    console.error("Erro ao criar assinatura:", error)
    return NextResponse.json({ error: "Erro ao processar a solicitação" }, { status: 500 })
  }
}

