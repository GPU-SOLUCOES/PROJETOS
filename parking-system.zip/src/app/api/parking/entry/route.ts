import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const body = await request.json()
    const { plate, model, color, owner, document, parkingLotId, serviceId } = body

    // Validar dados
    if (!plate || !model || !color || !owner || !document || !parkingLotId || !serviceId) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Verificar se o estacionamento existe e pertence ao cliente do usuário
    const parkingLot = await prisma.parkingLot.findUnique({
      where: { id: parkingLotId },
    })

    if (!parkingLot) {
      return NextResponse.json({ error: "Estacionamento não encontrado" }, { status: 404 })
    }

    // Verificar permissões (exceto para super_admin)
    if (session.user.role !== "super_admin" && parkingLot.clientId !== session.user.clientId) {
      return NextResponse.json({ error: "Você não tem permissão para acessar este estacionamento" }, { status: 403 })
    }

    // Verificar se o serviço existe e pertence ao estacionamento
    const service = await prisma.service.findUnique({
      where: {
        id: serviceId,
        parkingLotId: parkingLotId,
      },
    })

    if (!service) {
      return NextResponse.json({ error: "Serviço não encontrado" }, { status: 404 })
    }

    // Verificar capacidade do estacionamento
    const parkedVehiclesCount = await prisma.parkingRecord.count({
      where: {
        parkingLotId: parkingLotId,
        exitDate: null,
      },
    })

    if (parkedVehiclesCount >= parkingLot.capacity) {
      return NextResponse.json({ error: "Estacionamento lotado" }, { status: 400 })
    }

    // Verificar se o veículo já está estacionado
    const existingVehicle = await prisma.vehicle.findFirst({
      where: {
        plate: plate.toUpperCase(),
        parkingRecords: {
          some: {
            parkingLotId: parkingLotId,
            exitDate: null,
          },
        },
      },
    })

    if (existingVehicle) {
      return NextResponse.json({ error: "Veículo já está estacionado" }, { status: 400 })
    }

    // Criar ou buscar veículo
    let vehicle = await prisma.vehicle.findFirst({
      where: {
        plate: plate.toUpperCase(),
      },
    })

    if (!vehicle) {
      vehicle = await prisma.vehicle.create({
        data: {
          plate: plate.toUpperCase(),
          model,
          color,
          owner,
          document,
        },
      })
    } else {
      // Atualizar dados do veículo se necessário
      vehicle = await prisma.vehicle.update({
        where: {
          id: vehicle.id,
        },
        data: {
          model,
          color,
          owner,
          document,
        },
      })
    }

    // Criar registro de entrada
    const parkingRecord = await prisma.parkingRecord.create({
      data: {
        vehicleId: vehicle.id,
        parkingLotId: parkingLotId,
        serviceId: serviceId,
        entryDate: new Date(),
        entryUserId: session.user.id,
      },
      include: {
        vehicle: true,
        service: true,
        parkingLot: true,
      },
    })

    // Registrar log de atividade
    await prisma.activityLog.create({
      data: {
        userId: session.user.id,
        action: "vehicle_entry",
        details: `Entrada do veículo ${vehicle.plate} no estacionamento ${parkingLot.name}`,
        ip: "127.0.0.1", // Em produção, usar o IP real
      },
    })

    return NextResponse.json(parkingRecord, { status: 201 })
  } catch (error) {
    console.error("Erro na entrada de veículo:", error)
    return NextResponse.json({ error: "Erro ao processar entrada de veículo" }, { status: 500 })
  }
}

