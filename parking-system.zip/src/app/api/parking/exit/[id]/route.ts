import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verificar autenticação
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const id = params.id
    const body = await request.json()
    const { paidAmount, paymentMethod } = body

    // Validar dados
    if (paidAmount === undefined || !paymentMethod) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Buscar registro de estacionamento
    const parkingRecord = await prisma.parkingRecord.findUnique({
      where: { id },
      include: {
        parkingLot: true,
        vehicle: true,
        service: true,
      },
    })

    if (!parkingRecord) {
      return NextResponse.json({ error: "Registro não encontrado" }, { status: 404 })
    }

    // Verificar se o veículo já saiu
    if (parkingRecord.exitDate) {
      return NextResponse.json({ error: "Este veículo já saiu do estacionamento" }, { status: 400 })
    }

    // Verificar permissões (exceto para super_admin)
    if (session.user.role !== "super_admin" && parkingRecord.parkingLot.clientId !== session.user.clientId) {
      return NextResponse.json({ error: "Você não tem permissão para acessar este registro" }, { status: 403 })
    }

    // Atualizar registro com dados de saída
    const updatedRecord = await prisma.parkingRecord.update({
      where: { id },
      data: {
        exitDate: new Date(),
        paidAmount,
        paymentMethod,
        exitUserId: session.user.id,
      },
      include: {
        vehicle: true,
        service: true,
        parkingLot: true,
      },
    })

    // Registrar log de atividade
    await prisma.activityLog.create({
      data: {
        userId: session.user.id,
        action: "vehicle_exit",
        details: `Saída do veículo ${parkingRecord.vehicle.plate} do estacionamento ${parkingRecord.parkingLot.name}`,
        ip: "127.0.0.1", // Em produção, usar o IP real
      },
    })

    return NextResponse.json(updatedRecord, { status: 200 })
  } catch (error) {
    console.error("Erro na saída de veículo:", error)
    return NextResponse.json({ error: "Erro ao processar saída de veículo" }, { status: 500 })
  }
}

