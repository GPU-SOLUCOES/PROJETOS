import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function DemoPage() {
  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Sistema de Estacionamento - Demonstração</h1>

      <Tabs defaultValue="login" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="login">Login</TabsTrigger>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="entrada">Entrada de Veículos</TabsTrigger>
          <TabsTrigger value="saida">Saída de Veículos</TabsTrigger>
          <TabsTrigger value="admin">Administração</TabsTrigger>
        </TabsList>

        <TabsContent value="login" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Tela de Login</CardTitle>
              <CardDescription>Acesso seguro ao sistema com autenticação JWT e NextAuth</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=500&width=800"
                  alt="Tela de Login"
                  width={800}
                  height={500}
                  className="w-full"
                />
                <div className="p-4 bg-muted">
                  <h3 className="font-medium mb-2">Recursos da tela de login:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Autenticação segura com JWT</li>
                    <li>Proteção contra ataques de força bruta</li>
                    <li>Recuperação de senha</li>
                    <li>Verificação de status do cliente</li>
                    <li>Redirecionamento baseado em perfil de usuário</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dashboard" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Dashboard Principal</CardTitle>
              <CardDescription>Visão geral do estacionamento com métricas em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=500&width=800"
                  alt="Dashboard"
                  width={800}
                  height={500}
                  className="w-full"
                />
                <div className="p-4 bg-muted">
                  <h3 className="font-medium mb-2">Recursos do dashboard:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Indicadores de ocupação em tempo real</li>
                    <li>Gráficos de receita diária e mensal</li>
                    <li>Lista de veículos atualmente estacionados</li>
                    <li>Seletor de estacionamento para empresas com múltiplas unidades</li>
                    <li>Alertas e notificações importantes</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="entrada" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Entrada de Veículos</CardTitle>
              <CardDescription>Registro rápido e eficiente de novos veículos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=500&width=800"
                  alt="Entrada de Veículos"
                  width={800}
                  height={500}
                  className="w-full"
                />
                <div className="p-4 bg-muted">
                  <h3 className="font-medium mb-2">Recursos da entrada de veículos:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Formulário otimizado para entrada rápida</li>
                    <li>Validação de placa e dados do veículo</li>
                    <li>Seleção de serviço (hora, diária, mensalista)</li>
                    <li>Registro automático de data e hora</li>
                    <li>Identificação do operador responsável</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="saida" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Saída de Veículos</CardTitle>
              <CardDescription>Processamento de pagamento e liberação de veículos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=500&width=800"
                  alt="Saída de Veículos"
                  width={800}
                  height={500}
                  className="w-full"
                />
                <div className="p-4 bg-muted">
                  <h3 className="font-medium mb-2">Recursos da saída de veículos:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Cálculo automático do valor baseado no tempo de permanência</li>
                    <li>Múltiplas formas de pagamento (dinheiro, cartão, PIX)</li>
                    <li>Emissão de recibo para o cliente</li>
                    <li>Registro completo da transação</li>
                    <li>Tratamento especial para mensalistas</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="admin" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Área de Administração</CardTitle>
              <CardDescription>Gerenciamento completo do estacionamento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=500&width=800"
                  alt="Administração"
                  width={800}
                  height={500}
                  className="w-full"
                />
                <div className="p-4 bg-muted">
                  <h3 className="font-medium mb-2">Recursos da área administrativa:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Gerenciamento de usuários e permissões</li>
                    <li>Configuração de serviços e preços</li>
                    <li>Relatórios financeiros detalhados</li>
                    <li>Histórico completo de operações</li>
                    <li>Configurações do sistema</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Status do Sistema</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Serviços</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>API Backend</span>
                  <Badge className="bg-green-500">Online</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Banco de Dados</span>
                  <Badge className="bg-green-500">Online</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Serviço de Email</span>
                  <Badge className="bg-green-500">Online</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Processamento de Pagamentos</span>
                  <Badge className="bg-green-500">Online</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Ambiente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Ambiente</span>
                  <Badge>Homologação</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Versão</span>
                  <span className="text-sm">v1.0.0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Última atualização</span>
                  <span className="text-sm">26/03/2025</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Status</span>
                  <Badge className="bg-green-500">Pronto para testes</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Estatísticas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Usuários ativos</span>
                  <span className="font-medium">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Veículos estacionados</span>
                  <span className="font-medium">45</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Transações hoje</span>
                  <span className="font-medium">87</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Receita do dia</span>
                  <span className="font-medium">R$ 1.245,00</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mt-10 p-4 bg-muted rounded-lg">
        <h2 className="text-xl font-bold mb-2">Informações do Ambiente de Homologação</h2>
        <p className="mb-4">O sistema está rodando com as seguintes configurações:</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="font-medium mb-2">Configurações de Servidor</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Porta: 3000</li>
              <li>Banco de Dados: PostgreSQL</li>
              <li>Cache: Redis</li>
              <li>Autenticação: JWT + NextAuth</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium mb-2">Integrações Ativas</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Processamento de Pagamentos: Stripe (modo teste)</li>
              <li>Envio de Email: Mailtrap (ambiente de teste)</li>
              <li>Frontend: Next.js</li>
              <li>Mobile: React Native</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

