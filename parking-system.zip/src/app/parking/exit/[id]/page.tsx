"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import type { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { PaymentMethod, vehicleExitSchema } from "@/types"
import { formatCurrency, formatDateTime, formatTimeAgo, maskPlate } from "@/lib/utils"
import { Loader2 } from "lucide-react"

interface ParkingRecordDetails {
  id: string
  entryDate: string
  vehicle: {
    plate: string
    model: string
    color: string
    owner: string
  }
  service: {
    type: string
    value: number
  }
  parkingLot: {
    name: string
  }
}

export default function VehicleExitPage() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [isFetching, setIsFetching] = useState(true)
  const [record, setRecord] = useState<ParkingRecordDetails | null>(null)
  const [calculatedAmount, setCalculatedAmount] = useState(0)

  const id = params.id as string

  const form = useForm<z.infer<typeof vehicleExitSchema>>({
    resolver: zodResolver(vehicleExitSchema),
    defaultValues: {
      paymentMethod: PaymentMethod.CASH,
    },
  })

  useEffect(() => {
    async function fetchParkingRecord() {
      try {
        const response = await fetch(`/api/parking/records/${id}`)

        if (!response.ok) {
          throw new Error("Registro não encontrado")
        }

        const data = await response.json()
        setRecord(data)

        // Calcular valor a ser pago
        const entryDate = new Date(data.entryDate)
        const now = new Date()
        const diffInHours = (now.getTime() - entryDate.getTime()) / (1000 * 60 * 60)

        let amount = 0
        if (data.service.type === "hourly") {
          amount = Math.ceil(diffInHours) * data.service.value
        } else if (data.service.type === "daily") {
          const days = Math.ceil(diffInHours / 24)
          amount = days * data.service.value
        } else {
          // Mensalista não paga na saída
          amount = 0
        }

        setCalculatedAmount(amount)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Erro ao carregar registro",
          description: error instanceof Error ? error.message : "Ocorreu um erro ao carregar os dados do veículo",
        })
        router.push("/dashboard")
      } finally {
        setIsFetching(false)
      }
    }

    fetchParkingRecord()
  }, [id, toast, router])

  async function onSubmit(values: z.infer<typeof vehicleExitSchema>) {
    setIsLoading(true)

    try {
      const response = await fetch(`/api/parking/exit/${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...values,
          paidAmount: calculatedAmount,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Erro ao registrar saída")
      }

      toast({
        title: "Saída registrada com sucesso",
        description: "O veículo foi liberado do estacionamento",
      })

      router.push("/dashboard")
      router.refresh()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao registrar saída",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao registrar a saída do veículo",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isFetching) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Registrar Saída" text="Carregando informações do veículo..." />
        <div className="flex items-center justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardShell>
    )
  }

  if (!record) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Registrar Saída" text="Veículo não encontrado" />
        <div className="flex flex-col items-center justify-center py-10">
          <p className="text-muted-foreground">O registro do veículo não foi encontrado ou já foi finalizado.</p>
          <Button className="mt-4" onClick={() => router.push("/dashboard")}>
            Voltar para o Dashboard
          </Button>
        </div>
      </DashboardShell>
    )
  }

  const entryDate = new Date(record.entryDate)
  const now = new Date()
  const isPaidService = record.service.type !== "monthly"

  return (
    <DashboardShell>
      <DashboardHeader heading="Registrar Saída" text="Registre a saída de um veículo do estacionamento" />
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Informações do Veículo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Placa</p>
                <p className="text-lg font-semibold">{maskPlate(record.vehicle.plate)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Modelo</p>
                <p className="text-lg">{record.vehicle.model}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Cor</p>
                <p className="text-lg">{record.vehicle.color}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Proprietário</p>
                <p className="text-lg">{record.vehicle.owner}</p>
              </div>
            </div>
            <Separator />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Estacionamento</p>
                <p className="text-lg">{record.parkingLot.name}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Serviço</p>
                <p className="text-lg">
                  {record.service.type === "hourly"
                    ? `Hora (${formatCurrency(record.service.value)}/h)`
                    : record.service.type === "daily"
                      ? `Diária (${formatCurrency(record.service.value)}/dia)`
                      : "Mensalista"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Entrada</p>
                <p className="text-lg">{formatDateTime(entryDate)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Permanência</p>
                <p className="text-lg">{formatTimeAgo(entryDate)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pagamento</CardTitle>
          </CardHeader>
          <CardContent>
            {isPaidService ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="rounded-lg bg-muted p-4">
                    <p className="text-sm font-medium text-muted-foreground">Valor a pagar</p>
                    <p className="text-3xl font-bold">{formatCurrency(calculatedAmount)}</p>
                  </div>

                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Método de Pagamento</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione o método de pagamento" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={PaymentMethod.CASH}>Dinheiro</SelectItem>
                            <SelectItem value={PaymentMethod.CREDIT_CARD}>Cartão de Crédito</SelectItem>
                            <SelectItem value={PaymentMethod.DEBIT_CARD}>Cartão de Débito</SelectItem>
                            <SelectItem value={PaymentMethod.PIX}>PIX</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => router.push("/dashboard")}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? "Processando..." : "Confirmar Pagamento e Saída"}
                    </Button>
                  </div>
                </form>
              </Form>
            ) : (
              <div className="space-y-6">
                <div className="rounded-lg bg-muted p-4">
                  <p className="text-sm font-medium text-muted-foreground">Mensalista</p>
                  <p className="text-xl font-medium">Não há pagamento a ser realizado</p>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => router.push("/dashboard")}>
                    Cancelar
                  </Button>
                  <Button onClick={() => onSubmit({ paymentMethod: PaymentMethod.MONTHLY })} disabled={isLoading}>
                    {isLoading ? "Processando..." : "Registrar Saída"}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}

