import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserManagement } from "@/components/admin/user-management"
import { ParkingLotManagement } from "@/components/admin/parking-lot-management"
import { ServiceManagement } from "@/components/admin/service-management"
import { SettingsForm } from "@/components/admin/settings-form"

export default async function AdminPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  // Verificar se o usuário tem permissão de admin ou gerente
  if (session.user.role !== "admin" && session.user.role !== "manager" && session.user.role !== "super_admin") {
    redirect("/dashboard")
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Administração" text="Gerencie usuários, estacionamentos e configurações" />
      <Tabs defaultValue="users" className="space-y-4">
        <TabsList>
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="parking-lots">Estacionamentos</TabsTrigger>
          <TabsTrigger value="services">Serviços</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Usuários</CardTitle>
              <CardDescription>Adicione, edite ou remova usuários do sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <UserManagement />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="parking-lots" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Estacionamentos</CardTitle>
              <CardDescription>Gerencie os estacionamentos da sua empresa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <ParkingLotManagement />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="services" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Serviços</CardTitle>
              <CardDescription>Configure os serviços e preços oferecidos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <ServiceManagement />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações</CardTitle>
              <CardDescription>Configure as preferências do sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <SettingsForm />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

