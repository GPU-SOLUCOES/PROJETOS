import { z } from "zod"

// Enums
export enum UserRole {
  ATTENDANT = "attendant",
  MANAGER = "manager",
  ADMIN = "admin",
  SUPER_ADMIN = "super_admin",
}

export enum ServiceType {
  HOURLY = "hourly",
  DAILY = "daily",
  MONTHLY = "monthly",
}

export enum PaymentMethod {
  CASH = "cash",
  CREDIT_CARD = "credit_card",
  DEBIT_CARD = "debit_card",
  PIX = "pix",
  MONTHLY = "monthly",
}

export enum PaymentStatus {
  PENDING = "pending",
  PAID = "paid",
  OVERDUE = "overdue",
  CANCELLED = "cancelled",
}

export enum SubscriptionStatus {
  PENDING = "pending",
  ACTIVE = "active",
  CANCELLED = "cancelled",
  EXPIRED = "expired",
}

export enum NotificationType {
  INFO = "info",
  WARNING = "warning",
  ALERT = "alert",
  BILLING = "billing",
}

// Interfaces
export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  clientId: string | null
  lastAccess?: Date
}

export interface Client {
  id: string
  name: string
  address?: string
  phone?: string
  email?: string
  logo?: string
  active: boolean
  blocked: boolean
  blockReason?: string
  registrationDate: Date
}

export interface Branch {
  id: string
  clientId: string
  name: string
  address: string
  phone?: string
  email?: string
  manager?: string
  active: boolean
}

export interface ParkingLot {
  id: string
  name: string
  address?: string
  capacity: number
  openingTime?: string
  closingTime?: string
  clientId: string
  branchId?: string
}

export interface Vehicle {
  id: string
  plate: string
  model: string
  color: string
  owner: string
  document: string
}

export interface Service {
  id: string
  type: ServiceType
  value: number
  parkingLotId: string
}

export interface ParkingRecord {
  id: string
  vehicleId: string
  parkingLotId: string
  serviceId: string
  entryDate: Date
  exitDate?: Date
  paidAmount: number
  paymentMethod?: PaymentMethod
  entryUserId: string
  exitUserId?: string
  vehicle?: Vehicle
  service?: Service
}

export interface Plan {
  id: string
  name: string
  description?: string
  price: number
  duration: number
  maxUsers: number
  maxParkingLots: number
  features?: any
  active: boolean
}

export interface Subscription {
  id: string
  clientId: string
  planId: string
  startDate: Date
  endDate: Date
  status: SubscriptionStatus
  autoRenew: boolean
  price: number
  plan?: Plan
}

export interface Payment {
  id: string
  subscriptionId: string
  amount: number
  date: Date
  status: PaymentStatus
  paymentMethod: string
  transactionId?: string
}

export interface Notification {
  id: string
  clientId: string
  title: string
  message: string
  type: NotificationType
  read: boolean
  sentDate: Date
  readDate?: Date
}

export interface DashboardStats {
  totalVehicles: number
  availableSpots: number
  dailyRevenue: number
  monthlyRevenue: number
}

// Zod Schemas
export const loginSchema = z.object({
  email: z.string().email({ message: "Email inválido" }),
  password: z.string().min(6, { message: "Senha deve ter pelo menos 6 caracteres" }),
})

export const registerSchema = z
  .object({
    name: z.string().min(3, { message: "Nome deve ter pelo menos 3 caracteres" }),
    email: z.string().email({ message: "Email inválido" }),
    password: z.string().min(6, { message: "Senha deve ter pelo menos 6 caracteres" }),
    confirmPassword: z.string(),
    companyName: z.string().min(3, { message: "Nome da empresa deve ter pelo menos 3 caracteres" }),
    phone: z.string().optional(),
    address: z.string().optional(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Senhas não conferem",
    path: ["confirmPassword"],
  })

export const vehicleEntrySchema = z.object({
  plate: z.string().min(1, { message: "Placa é obrigatória" }),
  model: z.string().min(1, { message: "Modelo é obrigatório" }),
  color: z.string().min(1, { message: "Cor é obrigatória" }),
  owner: z.string().min(1, { message: "Proprietário é obrigatório" }),
  document: z.string().optional(),
  serviceId: z.string().min(1, { message: "Serviço é obrigatório" }),
  parkingLotId: z.string().min(1, { message: "Estacionamento é obrigatório" }),
})

export const vehicleExitSchema = z.object({
  paymentMethod: z.nativeEnum(PaymentMethod, {
    errorMap: () => ({ message: "Método de pagamento inválido" }),
  }),
})

export type LoginFormData = z.infer<typeof loginSchema>
export type RegisterFormData = z.infer<typeof registerSchema>
export type VehicleEntryFormData = z.infer<typeof vehicleEntrySchema>
export type VehicleExitFormData = z.infer<typeof vehicleExitSchema>

