import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  console.log("Iniciando seed...")

  // Criar clientes
  const cliente1 = await prisma.cliente.upsert({
    where: { id: 1 },
    update: {},
    create: {
      nome: "Empresa Demonstração 01",
      endereco: "Av. Principal, 1000",
      telefone: "(11) 99999-9999",
      email: "contato@empresa.com",
      dataCadastro: new Date("2025-03-18 00:37:21"),
    },
  })

  const cliente2 = await prisma.cliente.upsert({
    where: { id: 2 },
    update: {},
    create: {
      nome: "Empresa Demonstração 02",
      endereco: "Av. Principal, 1000",
      telefone: "(11) 99999-9999",
      email: "contato@empresa.com",
      dataCadastro: new Date("2025-03-18 00:49:40"),
    },
  })

  const cliente3 = await prisma.cliente.upsert({
    where: { id: 3 },
    update: {},
    create: {
      nome: "Empresa Demonstração 03",
      endereco: "Av. Principal, 1000",
      telefone: "(11) 99999-9999",
      email: "contato@empresa.com",
      dataCadastro: new Date("2025-03-18 00:47:56"),
    },
  })

  console.log("Clientes criados")

  // Criar configurações
  await prisma.configuracao.upsert({
    where: { clienteId: 1 },
    update: {},
    create: {
      clienteId: 1,
      corPrimaria: "#007bff",
      corSecundaria: "#6c757d",
      corDestaque: "#ffc107",
      logo: "uploads/logos/1_1742270358_Imagem do WhatsApp de 2025-02-09 à(s) 11.12.57_b6424982.jpg",
      mensagemTicket: "Obrigado por utilizar nosso estacionamento!",
      exibirLogoTicket: true,
    },
  })

  console.log("Configurações criadas")

  // Criar status dos clientes
  await prisma.statusCliente.upsert({
    where: { clienteId: 1 },
    update: {},
    create: {
      clienteId: 1,
      ativo: true,
      bloqueado: false,
      diasGraca: 5,
    },
  })

  await prisma.statusCliente.upsert({
    where: { clienteId: 2 },
    update: {},
    create: {
      clienteId: 2,
      ativo: true,
      bloqueado: false,
      diasGraca: 5,
    },
  })

  await prisma.statusCliente.upsert({
    where: { clienteId: 3 },
    update: {},
    create: {
      clienteId: 3,
      ativo: true,
      bloqueado: false,
      diasGraca: 5,
    },
  })

  console.log("Status dos clientes criados")

  // Criar usuários
  const hashedPassword = await bcrypt.hash("senha123", 10)

  const admin = await prisma.usuario.upsert({
    where: { id: 1 },
    update: {},
    create: {
      nome: "Administrador",
      email: "admin@sistema.com",
      senha: hashedPassword,
      tipoAcesso: "admin",
      clienteId: 1,
      dataCriacao: new Date("2025-03-18 00:49:08"),
    },
  })

  const atendente = await prisma.usuario.upsert({
    where: { id: 2 },
    update: {},
    create: {
      nome: "Atendente 01",
      email: "atendente@teste.com",
      senha: hashedPassword,
      tipoAcesso: "atendente",
      clienteId: 1,
      dataCriacao: new Date("2025-03-18 05:01:09"),
    },
  })

  const superAdmin = await prisma.usuario.upsert({
    where: { id: 3 },
    update: {},
    create: {
      nome: "Super Admin",
      email: "superadmin@sistema.com",
      senha: hashedPassword,
      tipoAcesso: "super_admin",
      dataCriacao: new Date("2025-03-18 01:03:17"),
    },
  })

  console.log("Usuários criados")

  // Criar estacionamento
  const estacionamento = await prisma.estacionamento.upsert({
    where: { id: 1 },
    update: {},
    create: {
      nome: "Estacionamento Central",
      endereco: "Rua do Centro, 500",
      capacidade: 100,
      horarioAbertura: new Date("1970-01-01T08:00:00"),
      horarioFechamento: new Date("1970-01-01T20:00:00"),
      clienteId: 1,
    },
  })

  console.log("Estacionamento criado")

  // Criar serviços
  await prisma.servico.upsert({
    where: { id: 1 },
    update: {},
    create: {
      tipo: "hora",
      valor: 10.0,
      estacionamentoId: 1,
    },
  })

  await prisma.servico.upsert({
    where: { id: 2 },
    update: {},
    create: {
      tipo: "diaria",
      valor: 50.0,
      estacionamentoId: 1,
    },
  })

  await prisma.servico.upsert({
    where: { id: 3 },
    update: {},
    create: {
      tipo: "mensalista",
      valor: 0.0,
      estacionamentoId: 1,
    },
  })

  console.log("Serviços criados")

  // Criar veículos
  const veiculo1 = await prisma.veiculo.upsert({
    where: { id: 1 },
    update: {},
    create: {
      placa: "ABC-1234",
      modelo: "Fiat Uno",
      cor: "Vermelha",
      proprietario: "Jose da Silva Sauro",
      documento: "12345678910",
      dataCadastro: new Date("2025-03-18 00:56:00"),
    },
  })

  const veiculo2 = await prisma.veiculo.upsert({
    where: { id: 2 },
    update: {},
    create: {
      placa: "ABC-4321",
      modelo: "Honda CRV",
      cor: "Branca",
      proprietario: "Raquel Linda",
      documento: "12345678910",
      dataCadastro: new Date("2025-03-18 01:22:30"),
    },
  })

  console.log("Veículos criados")

  // Criar registros
  await prisma.registro.upsert({
    where: { id: 1 },
    update: {},
    create: {
      veiculoId: 1,
      estacionamentoId: 1,
      servicoId: 2,
      dataEntrada: new Date("2025-03-18 04:56:00"),
      dataSaida: new Date("2025-03-18 04:56:54"),
      valorPago: 50.0,
      formaPagamento: "pix",
      usuarioEntradaId: 1,
      usuarioSaidaId: 1,
    },
  })

  await prisma.registro.upsert({
    where: { id: 2 },
    update: {},
    create: {
      veiculoId: 2,
      estacionamentoId: 1,
      servicoId: 1,
      dataEntrada: new Date("2025-03-18 05:22:30"),
      dataSaida: new Date("2025-03-18 05:22:51"),
      valorPago: 10.0,
      formaPagamento: "cartao_debito",
      usuarioEntradaId: 1,
      usuarioSaidaId: 1,
    },
  })

  await prisma.registro.upsert({
    where: { id: 3 },
    update: {},
    create: {
      veiculoId: 1,
      estacionamentoId: 1,
      servicoId: 3,
      dataEntrada: new Date("2025-03-19 02:39:52"),
      usuarioEntradaId: 1,
    },
  })

  console.log("Registros criados")

  // Criar pagamento de cliente
  await prisma.pagamentoCliente.upsert({
    where: { id: 1 },
    update: {},
    create: {
      clienteId: 1,
      valor: 199.98,
      dataVencimento: new Date("2025-04-19"),
      status: "pendente",
      observacoes: "",
    },
  })

  console.log("Pagamentos criados")

  console.log("Seed concluído com sucesso!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

