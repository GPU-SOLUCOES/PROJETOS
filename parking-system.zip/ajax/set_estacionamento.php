<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

// Verificar permissões (super_admin pode acessar qualquer estacionamento)
$isSuperAdmin = isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'super_admin';

if (!$isSuperAdmin && $_SESSION['user_type'] != 'gerente' && $_SESSION['user_type'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada.']);
    exit;
}

// Obter ID do estacionamento
$estacionamentoId = isset($_POST['estacionamento_id']) ? intval($_POST['estacionamento_id']) : 0;

// Se for uma requisição GET (para links diretos)
if (empty($estacionamentoId) && isset($_GET['estacionamento_id'])) {
    $estacionamentoId = intval($_GET['estacionamento_id']);
}

if ($estacionamentoId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Estacionamento inválido.']);
    exit;
}

// Verificar se o estacionamento existe
$sql = "SELECT id, cliente_id FROM estacionamentos WHERE id = ?";
$estacionamento = fetchOne($sql, [$estacionamentoId]);

if (!$estacionamento) {
    echo json_encode(['success' => false, 'message' => 'Estacionamento não encontrado.']);
    exit;
}

// Se não for super_admin, verificar se o usuário tem acesso a este estacionamento
if (!$isSuperAdmin) {
    $clienteId = $_SESSION['cliente_id'] ?? 0;
    
    if ($estacionamento['cliente_id'] != $clienteId) {
        echo json_encode(['success' => false, 'message' => 'Você não tem acesso a este estacionamento.']);
        exit;
    }
}

// Salvar na sessão
$_SESSION['estacionamento_id'] = $estacionamentoId;

// Se for super_admin, também salvar o cliente_id temporariamente para facilitar a navegação
if ($isSuperAdmin) {
    $_SESSION['temp_cliente_id'] = $estacionamento['cliente_id'];
}

// Se for uma requisição AJAX, retornar JSON
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    echo json_encode(['success' => true]);
    exit;
}

// Se for um link direto, redirecionar para o dashboard
header('Location: ../index.php?page=dashboard');
exit;

