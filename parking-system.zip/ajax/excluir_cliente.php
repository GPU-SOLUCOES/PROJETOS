<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada.']);
    exit;
}

// Obter ID do cliente
$clienteId = intval($_POST['cliente_id'] ?? 0);

if ($clienteId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Cliente não especificado.']);
    exit;
}

// Iniciar transação
$conn->begin_transaction();

try {
    // Excluir registros relacionados
    // 1. Excluir logs de usuários do cliente
    $sql = "DELETE l FROM logs l 
            JOIN usuarios u ON l.usuario_id = u.id 
            WHERE u.cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 2. Excluir registros de entrada/saída
    $sql = "DELETE r FROM registros r 
            JOIN estacionamentos e ON r.estacionamento_id = e.id 
            WHERE e.cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 3. Excluir serviços
    $sql = "DELETE s FROM servicos s 
            JOIN estacionamentos e ON s.estacionamento_id = e.id 
            WHERE e.cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 4. Excluir estacionamentos
    $sql = "DELETE FROM estacionamentos WHERE cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 5. Excluir usuários
    $sql = "DELETE FROM usuarios WHERE cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 6. Excluir configurações
    $sql = "DELETE FROM configuracoes WHERE cliente_id = ?";
    executeQuery($sql, [$clienteId]);
    
    // 7. Finalmente, excluir o cliente
    $sql = "DELETE FROM clientes WHERE id = ?";
    executeQuery($sql, [$clienteId]);
    
    // Confirmar transação
    $conn->commit();
    
    // Registrar atividade
    logActivity($_SESSION['user_id'], 'excluir_cliente', 'Cliente ID: ' . $clienteId);
    
    // Redirecionar de volta para a página de super admin
    header('Location: ../index.php?page=super_admin&subpage=clientes&success=1');
    exit;
} catch (Exception $e) {
    // Reverter transação em caso de erro
    $conn->rollback();
    
    // Redirecionar com mensagem de erro
    header('Location: ../index.php?page=super_admin&subpage=clientes&error=1&message=' . urlencode($e->getMessage()));
    exit;
}

