<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada.']);
    exit;
}

// Obter dados do formulário
$statusId = intval($_POST['status_id'] ?? 0);
$clienteId = intval($_POST['cliente_id'] ?? 0);
$ativo = isset($_POST['ativo']) ? 1 : 0;
$bloqueado = isset($_POST['bloqueado']) ? 1 : 0;
$motivoBloqueio = sanitizeInput($_POST['motivo_bloqueio'] ?? '');
$diasGraca = intval($_POST['dias_graca'] ?? 5);

if ($clienteId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Cliente não especificado.']);
    exit;
}

// Verificar se o cliente existe
$sql = "SELECT id FROM clientes WHERE id = ?";
$cliente = fetchOne($sql, [$clienteId]);

if (!$cliente) {
    echo json_encode(['success' => false, 'message' => 'Cliente não encontrado.']);
    exit;
}

// Preparar dados para atualização
$dadosStatus = [
    'ativo' => $ativo,
    'bloqueado' => $bloqueado,
    'dias_graca' => $diasGraca
];

// Adicionar motivo de bloqueio se estiver bloqueado
if ($bloqueado) {
    $dadosStatus['motivo_bloqueio'] = $motivoBloqueio;
    $dadosStatus['data_bloqueio'] = date('Y-m-d H:i:s');
    
    // Criar notificação
    $dadosNotificacao = [
        'cliente_id' => $clienteId,
        'titulo' => 'Conta Bloqueada',
        'mensagem' => 'Sua conta foi bloqueada. Motivo: ' . $motivoBloqueio,
        'tipo' => 'alerta'
    ];
    
    insert('notificacoes', $dadosNotificacao);
} else {
    $dadosStatus['motivo_bloqueio'] = null;
    $dadosStatus['data_desbloqueio'] = date('Y-m-d H:i:s');
    
    // Criar notificação se estava bloqueado antes
    $sql = "SELECT bloqueado FROM status_clientes WHERE id = ?";
    $statusAtual = fetchOne($sql, [$statusId]);
    
    if ($statusAtual && $statusAtual['bloqueado']) {
        $dadosNotificacao = [
            'cliente_id' => $clienteId,
            'titulo' => 'Conta Desbloqueada',
            'mensagem' => 'Sua conta foi desbloqueada e está ativa novamente.',
            'tipo' => 'info'
        ];
        
        insert('notificacoes', $dadosNotificacao);
    }
}

// Atualizar status
$resultado = update('status_clientes', $dadosStatus, 'id = ?', [$statusId]);

if ($resultado) {
    // Redirecionar de volta para a página de status
    header('Location: ../index.php?page=super_admin&subpage=status&success=1');
    exit;
} else {
    // Redirecionar com mensagem de erro
    header('Location: ../index.php?page=super_admin&subpage=status&error=1');
    exit;
}

