<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada.']);
    exit;
}

// Obter dados do formulário
$pagamentoId = intval($_POST['pagamento_id'] ?? 0);
$dataPagamento = sanitizeInput($_POST['data_pagamento'] ?? '');
$metodoPagamento = sanitizeInput($_POST['metodo_pagamento'] ?? '');
$observacoes = sanitizeInput($_POST['observacoes'] ?? '');

if ($pagamentoId <= 0 || empty($dataPagamento) || empty($metodoPagamento)) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

// Obter informações do pagamento
$sql = "SELECT cliente_id, valor FROM pagamentos_clientes WHERE id = ?";
$pagamento = fetchOne($sql, [$pagamentoId]);

if (!$pagamento) {
    echo json_encode(['success' => false, 'message' => 'Pagamento não encontrado.']);
    exit;
}

// Atualizar pagamento
$dadosPagamento = [
    'status' => 'pago',
    'data_pagamento' => $dataPagamento,
    'metodo_pagamento' => $metodoPagamento,
    'observacoes' => $observacoes
];

$resultado = update('pagamentos_clientes', $dadosPagamento, 'id = ?', [$pagamentoId]);

if ($resultado) {
    // Verificar se o cliente está bloqueado e desbloquear
    $sql = "SELECT bloqueado FROM status_clientes WHERE cliente_id = ?";
    $statusCliente = fetchOne($sql, [$pagamento['cliente_id']]);
    
    if ($statusCliente && $statusCliente['bloqueado']) {
        $dadosStatus = [
            'bloqueado' => false,
            'motivo_bloqueio' => null,
            'data_desbloqueio' => date('Y-m-d H:i:s')
        ];
        
        update('status_clientes', $dadosStatus, 'cliente_id = ?', [$pagamento['cliente_id']]);
        
        // Criar notificação
        $dadosNotificacao = [
            'cliente_id' => $pagamento['cliente_id'],
            'titulo' => 'Pagamento Recebido',
            'mensagem' => 'Recebemos seu pagamento de R$ ' . number_format($pagamento['valor'], 2, ',', '.') . '. Sua conta foi desbloqueada.',
            'tipo' => 'info'
        ];
        
        insert('notificacoes', $dadosNotificacao);
    }
    
    // Redirecionar de volta para a página de financeiro
    header('Location: ../index.php?page=super_admin&subpage=financeiro&success=1');
    exit;
} else {
    // Redirecionar com mensagem de erro
    header('Location: ../index.php?page=super_admin&subpage=financeiro&error=1');
    exit;
}

