<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada.']);
    exit;
}

// Obter ID do cliente
$clienteId = intval($_GET['cliente_id'] ?? 0);

if ($clienteId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Cliente não especificado.']);
    exit;
}

// Obter motivo do bloqueio
$sql = "SELECT motivo_bloqueio FROM status_clientes WHERE cliente_id = ?";
$status = fetchOne($sql, [$clienteId]);

if ($status) {
    echo json_encode(['success' => true, 'motivo' => $status['motivo_bloqueio']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Status não encontrado.']);
}

