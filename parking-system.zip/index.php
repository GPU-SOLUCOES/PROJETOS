<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Verificar se o usuário está logado
if (!isLoggedIn() && basename($_SERVER['PHP_SELF']) != 'login.php') {
  header('Location: login.php');
  exit;
}

// Verificar se o cliente está bloqueado (exceto para super_admin)
if (isLoggedIn() && $_SESSION['user_type'] != 'super_admin' && isset($_SESSION['cliente_id'])) {
    $sql = "SELECT bloqueado, motivo_bloqueio FROM status_clientes WHERE cliente_id = ?";
    $statusCliente = fetchOne($sql, [$_SESSION['cliente_id']]);
    
    if ($statusCliente && $statusCliente['bloqueado']) {
        // Armazenar informações de bloqueio para exibir
        $_SESSION['bloqueio_info'] = [
            'motivo' => $statusCliente['motivo_bloqueio']
        ];
        
        // Redirecionar para página de bloqueio
        header('Location: blocked.php');
        exit;
    }
}

// Obter o cliente vinculado ao usuário logado
$clienteId = $_SESSION['cliente_id'] ?? null;

// Definir página atual
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Verificar permissões
if (!hasPermission($page)) {
  $page = 'unauthorized';
}

// Incluir cabeçalho
include 'includes/header.php';

// Incluir menu de navegação
include 'includes/navigation.php';

// Carregar conteúdo da página
switch ($page) {
  case 'dashboard':
      include 'pages/dashboard.php';
      break;
  case 'entrada':
      include 'pages/entrada_veiculo.php';
      break;
  case 'saida':
      include 'pages/saida_veiculo.php';
      break;
  case 'admin':
      include 'pages/admin.php';
      break;
  case 'financeiro':
      include 'pages/financeiro.php';
      break;
  case 'suporte':
      include 'pages/suporte.php';
      break;
  case 'super_admin':
      include 'pages/super_admin.php';
      break;
  case 'super_admin_dashboard':
      include 'pages/super_admin_dashboard.php';
      break;
  case 'logout':
      include 'pages/logout.php';
      break;
  case 'unauthorized':
      include 'pages/unauthorized.php';
      break;
  default:
      include 'pages/dashboard.php';
}

// Incluir rodapé
include 'includes/footer.php';
?>

