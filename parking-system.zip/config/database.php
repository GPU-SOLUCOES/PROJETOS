<?php
// Configurações do banco de dados
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'estacionamento_db';

// Criar conexão
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Definir charset
$conn->set_charset("utf8");

// Função para executar consultas SQL
function executeQuery($sql, $params = []) {
    global $conn;
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $types = '';
        $bindParams = [];
        
        foreach ($params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_double($param)) {
                $types .= 'd';
            } elseif (is_string($param)) {
                $types .= 's';
            } else {
                $types .= 'b';
            }
            $bindParams[] = $param;
        }
        
        $bindValues = array_merge([$types], $bindParams);
        $stmt->bind_param(...$bindValues);
    }
    
    $stmt->execute();
    
    return $stmt;
}

// Função para obter resultados de consulta
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    $result = $stmt->get_result();
    $rows = [];
    
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    
    $stmt->close();
    
    return $rows;
}

// Função para obter uma única linha
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $stmt->close();
    
    return $row;
}

// Função para inserir dados
function insert($table, $data) {
    global $conn;
    
    $columns = implode(', ', array_keys($data));
    $placeholders = implode(', ', array_fill(0, count($data), '?'));
    
    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
    
    $stmt = executeQuery($sql, array_values($data));
    $insertId = $conn->insert_id;
    
    $stmt->close();
    
    return $insertId;
}

// Função para atualizar dados
function update($table, $data, $where, $whereParams = []) {
    global $conn;
    
    $setClauses = [];
    foreach (array_keys($data) as $column) {
        $setClauses[] = "$column = ?";
    }
    
    $setClause = implode(', ', $setClauses);
    
    $sql = "UPDATE $table SET $setClause WHERE $where";
    
    $params = array_merge(array_values($data), $whereParams);
    
    $stmt = executeQuery($sql, $params);
    $affectedRows = $stmt->affected_rows;
    
    $stmt->close();
    
    return $affectedRows;
}

// Função para excluir dados
function delete($table, $where, $params = []) {
    global $conn;
    
    $sql = "DELETE FROM $table WHERE $where";
    
    $stmt = executeQuery($sql, $params);
    $affectedRows = $stmt->affected_rows;
    
    $stmt->close();
    
    return $affectedRows;
}
?>

