<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Verificar se o usuário está logado
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Verificar se é super_admin (não deve ser bloqueado)
if ($_SESSION['user_type'] == 'super_admin') {
    header('Location: index.php');
    exit;
}

// Obter informações de bloqueio
$bloqueioInfo = $_SESSION['bloqueio_info'] ?? null;

// Se não houver informações de bloqueio, verificar novamente
if (!$bloqueioInfo && isset($_SESSION['cliente_id'])) {
    $sql = "SELECT bloqueado, motivo_bloqueio FROM status_clientes WHERE cliente_id = ?";
    $statusCliente = fetchOne($sql, [$_SESSION['cliente_id']]);
    
    if ($statusCliente && $statusCliente['bloqueado']) {
        $bloqueioInfo = [
            'motivo' => $statusCliente['motivo_bloqueio']
        ];
        $_SESSION['bloqueio_info'] = $bloqueioInfo;
    } else {
        // Cliente não está bloqueado, redirecionar para o dashboard
        header('Location: index.php');
        exit;
    }
}

// Se ainda não houver informações de bloqueio, algo está errado
if (!$bloqueioInfo) {
    header('Location: logout.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso Bloqueado - Sistema de Gestão de Estacionamentos</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .blocked-container {
            max-width: 600px;
            width: 100%;
            padding: 2rem;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            text-align: center;
        }
        
        .blocked-icon {
            font-size: 5rem;
            color: #dc3545;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="blocked-container">
        <div class="blocked-icon">
            <i class="fas fa-lock"></i>
        </div>
        
        <h2 class="mb-4">Acesso Bloqueado</h2>
        
        <div class="alert alert-danger">
            <p>O acesso da sua empresa ao sistema está temporariamente bloqueado.</p>
            <p><strong>Motivo:</strong> <?php echo htmlspecialchars($bloqueioInfo['motivo']); ?></p>
        </div>
        
        <p class="mb-4">Entre em contato com o suporte para regularizar sua situação.</p>
        
        <div class="d-grid gap-2 d-md-flex justify-content-md-center">
            <a href="logout.php" class="btn btn-secondary">
                <i class="fas fa-sign-out-alt me-2"></i> Sair
            </a>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

