-- Esquema do banco de dados para o sistema de estacionamento

-- Tabela de clientes
CREATE TABLE clients (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  address VARCHAR(200),
  phone VARCHAR(20),
  email VARCHAR(100),
  logo VARCHAR(255),
  active BOOLEAN DEFAULT TRUE,
  blocked BOOLEAN DEFAULT FALSE,
  block_reason TEXT,
  registration_date TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de filiais
CREATE TABLE branches (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(100),
  manager VARCHAR(100),
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de usuários
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('atendente', 'gerente', 'admin', 'super_admin')),
  client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
  last_access TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de estacionamentos
CREATE TABLE parking_lots (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  address VARCHAR(200),
  capacity INTEGER NOT NULL,
  opening_time TIME,
  closing_time TIME,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  branch_id INTEGER REFERENCES branches(id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de veículos
CREATE TABLE vehicles (
  id SERIAL PRIMARY KEY,
  plate VARCHAR(10) NOT NULL,
  model VARCHAR(50) NOT NULL,
  color VARCHAR(30) NOT NULL,
  owner VARCHAR(100) NOT NULL,
  document VARCHAR(20) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de serviços
CREATE TABLE services (
  id SERIAL PRIMARY KEY,
  type VARCHAR(10) NOT NULL CHECK (type IN ('hour', 'day', 'month')),
  value DECIMAL(10, 2) NOT NULL,
  parking_lot_id INTEGER NOT NULL REFERENCES parking_lots(id) ON DELETE CASCADE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de registros de estacionamento
CREATE TABLE parking_records (
  id SERIAL PRIMARY KEY,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
  parking_lot_id INTEGER NOT NULL REFERENCES parking_lots(id) ON DELETE RESTRICT,
  service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  entry_date TIMESTAMP NOT NULL,
  exit_date TIMESTAMP,
  paid_amount DECIMAL(10, 2) DEFAULT 0,
  payment_method VARCHAR(20) CHECK (payment_method IN ('credit_card', 'debit_card', 'cash', 'pix', 'monthly')),
  entry_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  exit_user_id INTEGER REFERENCES users(id) ON DELETE RESTRICT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de logs de atividade
CREATE TABLE activity_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action VARCHAR(50) NOT NULL,
  details TEXT,
  ip VARCHAR(45),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de planos de assinatura
CREATE TABLE plans (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  duration INTEGER NOT NULL, -- em meses
  max_users INTEGER NOT NULL,
  max_parking_lots INTEGER NOT NULL,
  features JSONB,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de assinaturas
CREATE TABLE subscriptions (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE RESTRICT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('pending', 'active', 'cancelled', 'expired')),
  auto_renew BOOLEAN DEFAULT TRUE,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de pagamentos
CREATE TABLE payments (
  id SERIAL PRIMARY KEY,
  subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  date TIMESTAMP NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_method VARCHAR(20) NOT NULL,
  transaction_id VARCHAR(100),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabela de notificações
CREATE TABLE notifications (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  title VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(20) NOT NULL CHECK (type IN ('info', 'warning', 'alert', 'billing')),
  read BOOLEAN DEFAULT FALSE,
  sent_date TIMESTAMP NOT NULL DEFAULT NOW(),
  read_date TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Índices para melhorar performance
CREATE INDEX idx_parking_records_vehicle_id ON parking_records(vehicle_id);
CREATE INDEX idx_parking_records_parking_lot_id ON parking_records(parking_lot_id);
CREATE INDEX idx_parking_records_entry_date ON parking_records(entry_date);
CREATE INDEX idx_parking_records_exit_date ON parking_records(exit_date);
CREATE INDEX idx_vehicles_plate ON vehicles(plate);
CREATE INDEX idx_users_client_id ON users(client_id);
CREATE INDEX idx_parking_lots_client_id ON parking_lots(client_id);
CREATE INDEX idx_subscriptions_client_id ON subscriptions(client_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_payments_subscription_id ON payments(subscription_id);

