<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Verificar se o usuário já está logado
if (isLoggedIn()) {
  header('Location: index.php');
  exit;
}

$error = '';
$bloqueioInfo = null;

// Processar formulário de login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = sanitizeInput($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  
  if (empty($email) || empty($password)) {
      $error = 'Por favor, preencha todos os campos.';
  } else {
      // Tentar autenticar o usuário
      $authResult = authenticateUser($email, $password);
      
      if ($authResult === true) {
          // Verificar se o cliente está bloqueado (exceto para super_admin)
          if ($_SESSION['user_type'] != 'super_admin' && isset($_SESSION['cliente_id'])) {
              $sql = "SELECT sc.bloqueado, sc.motivo_bloqueio, c.nome as cliente_nome 
                      FROM status_clientes sc 
                      JOIN clientes c ON sc.cliente_id = c.id 
                      WHERE sc.cliente_id = ?";
              $statusCliente = fetchOne($sql, [$_SESSION['cliente_id']]);
              
              if ($statusCliente && $statusCliente['bloqueado']) {
                  // Armazenar informações de bloqueio para exibir
                  $bloqueioInfo = [
                      'cliente_nome' => $statusCliente['cliente_nome'],
                      'motivo' => $statusCliente['motivo_bloqueio']
                  ];
                  
                  // Fazer logout
                  session_unset();
                  session_destroy();
                  session_start();
              } else {
                  header('Location: index.php');
                  exit;
              }
          } else {
              header('Location: index.php');
              exit;
          }
      } else {
          $error = 'Email ou senha incorretos.';
      }
  }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Sistema de Gestão de Estacionamentos</title>
  
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <!-- Custom CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  
  <style>
    body {
        background-image: url('assets/images/parking-background.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        height: 100vh;
        margin: 0;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        position: relative;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: linear-gradient(135deg, rgba(0, 0, 0, 0.6) 0%, rgba(0, 0, 0, 0.8) 100%);
        z-index: 1;
    }
    
    .login-container {
        max-width: 450px;
        width: 100%;
        padding: 3rem;
        margin-right: 8%;
        background-color: rgba(255, 255, 255, 0.92);
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        position: relative;
        z-index: 2;
        animation: slideIn 0.5s ease-out;
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(50px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .login-logo {
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .login-logo i {
        color: var(--primary-color);
        filter: drop-shadow(0 0 5px rgba(0, 123, 255, 0.3));
    }
    
    .form-control {
        border-radius: 8px;
        padding: 0.75rem 1rem;
        border: 1px solid #e0e0e0;
        transition: all 0.3s;
        background-color: #f8f9fa;
    }
    
    .form-control:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
        background-color: #fff;
    }
    
    .input-group {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }
    
    .input-group-text {
        background-color: #f8f9fa;
        border-color: #e0e0e0;
    }
    
    .btn-primary {
        padding: 0.75rem 1.5rem;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s;
        background-color: var(--primary-color);
        border: none;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        background-color: #0069d9;
    }
    
    .welcome-text {
        position: absolute;
        left: 8%;
        top: 50%;
        transform: translateY(-50%);
        color: white;
        max-width: 500px;
        z-index: 2;
    }
    
    .welcome-text h1 {
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 1rem;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }
    
    .welcome-text p {
        font-size: 1.2rem;
        margin-bottom: 2rem;
        text-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    }
    
    @media (max-width: 992px) {
        .welcome-text {
            display: none;
        }
        
        .login-container {
            margin: 0 auto;
        }
        
        body {
            justify-content: center;
        }
    }
</style>
</head>
<body>
    <div class="welcome-text">
        <h1>Gestão Inteligente de Estacionamentos</h1>
        <p>Controle total do seu estacionamento com tecnologia avançada e interface intuitiva.</p>
    </div>

    <div class="login-container">
        <div class="login-logo">
            <i class="fas fa-parking fa-4x"></i>
            <h2 class="mt-3">Acesso ao Sistema</h2>
            <p class="text-muted">Entre com suas credenciais para continuar</p>
        </div>
        
        <?php if ($bloqueioInfo): ?>
            <div class="alert alert-danger" role="alert">
                <h5><i class="fas fa-lock me-2"></i> Acesso Bloqueado</h5>
                <p>O acesso da empresa <strong><?php echo $bloqueioInfo['cliente_nome']; ?></strong> está bloqueado.</p>
                <p><strong>Motivo:</strong> <?php echo $bloqueioInfo['motivo']; ?></p>
                <p class="mb-0">Entre em contato com o suporte para mais informações.</p>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-4">
                <label for="email" class="form-label">Email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" class="form-control" id="email" name="email" placeholder="seu@email.com" required>
                </div>
            </div>
            
            <div class="mb-4">
                <label for="password" class="form-label">Senha</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Sua senha" required>
                </div>
            </div>
            
            <div class="d-grid gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt me-2"></i> Entrar
                </button>
            </div>
        </form>
        
        <div class="text-center mt-4">
            <p class="text-muted small">© <?php echo date('Y'); ?> Sistema de Gestão de Estacionamentos</p>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

