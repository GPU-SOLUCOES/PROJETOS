<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\Estacionamento;
use App\Models\Veiculo;
use App\Models\Registro;
use App\Models\Servico;
use App\Models\Log;
use Carbon\Carbon;

class ParkingController extends Controller
{
    /**
     * Construtor
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('check.client.status');
    }
    
    /**
     * Mostrar formulário de entrada de veículo
     */
    public function showEntryForm()
    {
        $user = Auth::user();
        
        // Obter estacionamentos disponíveis para o usuário
        if ($user->tipo_acesso === 'super_admin') {
            $estacionamentos = Estacionamento::with('cliente')->orderBy('nome')->get();
        } else {
            $estacionamentos = Estacionamento::where('cliente_id', $user->cliente_id)
                ->orderBy('nome')
                ->get();
        }
        
        if ($estacionamentos->isEmpty()) {
            return redirect()->route('dashboard')->with('error', 'Nenhum estacionamento disponível.');
        }
        
        return view('parking.entry', compact('estacionamentos'));
    }
    
    /**
     * Processar entrada de veículo
     */
    public function processEntry(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'proprietario' => 'required|string|max:100',
            'documento' => 'required|string|max:20',
            'modelo' => 'required|string|max:50',
            'cor' => 'required|string|max:30',
            'placa' => 'required|string|max:10|regex:/^[A-Z]{3}[-]?\d{4}$|^[A-Z]{3}\d[A-Z]\d{2}$/',
            'estacionamento_id' => 'required|exists:estacionamentos,id',
            'servico_id' => 'required|exists:servicos,id',
        ], [
            'proprietario.required' => 'O nome do proprietário é obrigatório.',
            'documento.required' => 'O documento é obrigatório.',
            'modelo.required' => 'O modelo do veículo é obrigatório.',
            'cor.required' => 'A cor do veículo é obrigatória.',
            'placa.required' => 'A placa é obrigatória.',
            'placa.regex' => 'Formato de placa inválido. Use o formato AAA-1234 ou AAA1A23.',
            'estacionamento_id.required' => 'Selecione um estacionamento.',
            'estacionamento_id.exists' => 'Estacionamento inválido.',
            'servico_id.required' => 'Selecione um tipo de serviço.',
            'servico_id.exists' => 'Serviço inválido.',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        // Verificar se o veículo já está estacionado
        $veiculoEstacionado = Registro::whereHas('veiculo', function($query) use ($request) {
                $query->where('placa', $request->placa);
            })
            ->whereNull('data_saida')
            ->first();
        
        if ($veiculoEstacionado) {
            return redirect()->back()
                ->with('error', 'Este veículo já está estacionado.')
                ->withInput();
        }
        
        // Verificar disponibilidade de vagas
        $estacionamento = Estacionamento::findOrFail($request->estacionamento_id);
        
        $veiculosEstacionados = Registro::where('estacionamento_id', $estacionamento->id)
            ->whereNull('data_saida')
            ->count();
        
        if ($veiculosEstacionados >= $estacionamento->capacidade) {
            return redirect()->back()
                ->with('error', 'Não há vagas disponíveis neste estacionamento.')
                ->withInput();
        }
        
        // Verificar se o veículo já existe
        $veiculo = Veiculo::where('placa', $request->placa)->first();
        
        if (!$veiculo) {
            // Criar novo veículo
            $veiculo = Veiculo::create([
                'placa' => $request->placa,
                'modelo' => $request->modelo,
                'cor' => $request->cor,
                'proprietario' => $request->proprietario,
                'documento' => $request->documento,
            ]);
        } else {
            // Atualizar dados do veículo
            $veiculo->update([
                'modelo' => $request->modelo,
                'cor' => $request->cor,
                'proprietario' => $request->proprietario,
                'documento' => $request->documento,
            ]);
        }
        
        // Registrar entrada
        $registro = Registro::create([
            'veiculo_id' => $veiculo->id,
            'estacionamento_id' => $request->estacionamento_id,
            'servico_id' => $request->servico_id,
            'data_entrada' => now(),
            'usuario_entrada_id' => Auth::id(),
        ]);
        
        // Registrar log
        Log::create([
            'usuario_id' => Auth::id(),
            'acao' => 'entrada_veiculo',
            'detalhes' => "Registro de entrada do veículo {$veiculo->placa}",
            'data_hora' => now(),
            'ip' => $request->ip(),
        ]);
        
        return redirect()->route('dashboard')
            ->with('success', "Entrada do veículo {$veiculo->placa} registrada com sucesso!");
    }
    
    /**
     * Obter serviços do estacionamento
     */
    public function getServices($estacionamentoId)
    {
        $servicos = Servico::where('estacionamento_id', $estacionamentoId)
            ->orderBy('tipo')
            ->get();
        
        return response()->json($servicos);
    }
    
    /**
     * Obter informações do estacionamento
     */
    public function getParkingInfo($estacionamentoId)
    {
        $estacionamento = Estacionamento::findOrFail($estacionamentoId);
        
        $veiculosEstacionados = Registro::where('estacionamento_id', $estacionamento->id)
            ->whereNull('data_saida')
            ->count();
        
        $vagasDisponiveis = $estacionamento->capacidade - $veiculosEstacionados;
        
        return response()->json([
            'capacidade' => $estacionamento->capacidade,
            'veiculosEstacionados' => $veiculosEstacionados,
            'vagasDisponiveis' => $vagasDisponiveis,
        ]);
    }
    
    /**
     * Mostrar formulário de saída de veículo
     */
    public function showExitForm($id)
    {
        $registro = Registro::with(['veiculo', 'servico', 'estacionamento'])
            ->findOrFail($id);
        
        if ($registro->data_saida) {
            return redirect()->route('dashboard')
                ->with('error', 'Este veículo já saiu do estacionamento.');
        }
        
        // Calcular duração e valor a pagar
        $dataEntrada = Carbon::parse($registro->data_entrada);
        $dataSaida = Carbon::now();
        
        $diffHoras = $dataEntrada->diffInHours($dataSaida);
        $diffMinutos = $dataEntrada->diffInMinutes($dataSaida) % 60;
        $totalMinutos = $dataEntrada->diffInMinutes($dataSaida);
        
        $valorPagar = 0;
        
        if ($registro->servico->tipo === 'hora') {
            // Valor por hora, com fração mínima de 1 hora
            $totalHoras = ceil($totalMinutos / 60);
            $valorPagar = $totalHoras * $registro->servico->valor;
        } elseif ($registro->servico->tipo === 'diaria') {
            // Valor fixo por dia
            $valorPagar = $registro->servico->valor;
        } elseif ($registro->servico->tipo === 'mensalista') {
            // Mensalista não paga na saída
            $valorPagar = 0;
        }
        
        return view('parking.exit', compact('registro', 'diffHoras', 'diffMinutos', 'totalMinutos', 'valorPagar'));
    }
    
    /**
     * Processar saída de veículo
     */
    public function processExit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'forma_pagamento' => 'required|in:dinheiro,cartao_credito,cartao_debito,pix,mensalidade',
            'valor_pago' => 'required|numeric|min:0',
        ], [
            'forma_pagamento.required' => 'Selecione uma forma de pagamento.',
            'forma_pagamento.in' => 'Forma de pagamento inválida.',
            'valor_pago.required' => 'O valor pago é obrigatório.',
            'valor_pago.numeric' => 'O valor pago deve ser um número.',
            'valor_pago.min' => 'O valor pago deve ser maior ou igual a zero.',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        $registro = Registro::with('veiculo')->findOrFail($id);
        
        if ($registro->data_saida) {
            return redirect()->route('dashboard')
                ->with('error', 'Este veículo já saiu do estacionamento.');
        }
        
        // Registrar saída
        $registro->update([
            'data_saida' => now(),
            'valor_pago' => $request->valor_pago,
            'forma_pagamento' => $request->forma_pagamento,
            'usuario_saida_id' => Auth::id(),
        ]);
        
        // Registrar log
        Log::create([
            'usuario_id' => Auth::id(),
            'acao' => 'saida_veiculo',
            'detalhes' => "Registro de saída do veículo {$registro->veiculo->placa}",
            'data_hora' => now(),
            'ip' => $request->ip(),
        ]);
        
        return redirect()->route('dashboard')
            ->with('success', "Saída do veículo {$registro->veiculo->placa} registrada com sucesso!");
    }
}

