<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Usuario;
use App\Models\Log;

class AuthController extends Controller
{
    /**
     * Mostrar formulário de login
     */
    public function showLoginForm()
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }
        
        return view('login');
    }
    
    /**
     * Processar tentativa de login
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ], [
            'email.required' => 'O campo e-mail é obrigatório.',
            'email.email' => 'Digite um e-mail válido.',
            'password.required' => 'O campo senha é obrigatório.',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput($request->except('password'));
        }
        
        // Limitar tentativas de login (5 tentativas em 1 minuto)
        $maxAttempts = 5;
        $decayMinutes = 1;
        
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);
            
            return $this->sendLockoutResponse($request);
        }
        
        // Tentar autenticar o usuário
        if (Auth::attempt(['email' => $request->email, 'senha' => $request->password], $request->filled('remember'))) {
            // Autenticação bem-sucedida
            $this->clearLoginAttempts($request);
            
            $user = Auth::user();
            
            // Registrar log de login
            Log::create([
                'usuario_id' => $user->id,
                'acao' => 'login',
                'detalhes' => 'Login no sistema',
                'data_hora' => now(),
                'ip' => $request->ip(),
            ]);
            
            // Atualizar último acesso
            $user->ultimo_acesso = now();
            $user->save();
            
            // Redirecionar com base no tipo de acesso
            if ($user->tipo_acesso === 'super_admin') {
                return redirect()->route('super_admin.dashboard')->with('success', 'Login realizado com sucesso!');
            } else {
                return redirect()->route('dashboard')->with('success', 'Login realizado com sucesso!');
            }
        }
        
        // Autenticação falhou
        $this->incrementLoginAttempts($request);
        
        return redirect()->back()
            ->withInput($request->except('password'))
            ->with('error', 'Credenciais inválidas. Tente novamente.');
    }
    
    /**
     * Logout do usuário
     */
    public function logout(Request $request)
    {
        // Registrar log de logout
        if (Auth::check()) {
            Log::create([
                'usuario_id' => Auth::id(),
                'acao' => 'logout',
                'detalhes' => 'Logout do sistema',
                'data_hora' => now(),
                'ip' => $request->ip(),
            ]);
        }
        
        Auth::logout();
        
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect()->route('login')->with('success', 'Você saiu do sistema com sucesso.');
    }
    
    /**
     * Mostrar página não autorizada
     */
    public function unauthorized()
    {
        return view('unauthorized');
    }
    
    /**
     * Verificar se o usuário tem muitas tentativas de login
     */
    protected function hasTooManyLoginAttempts(Request $request)
    {
        return $this->limiter()->tooManyAttempts(
            $this->throttleKey($request),
            5,
            1
        );
    }
    
    /**
     * Incrementar tentativas de login
     */
    protected function incrementLoginAttempts(Request $request)
    {
        $this->limiter()->hit(
            $this->throttleKey($request),
            60
        );
    }
    
    /**
     * Limpar tentativas de login
     */
    protected function clearLoginAttempts(Request $request)
    {
        $this->limiter()->clear($this->throttleKey($request));
    }
    
    /**
     * Obter chave de limitação
     */
    protected function throttleKey(Request $request)
    {
        return strtolower($request->input('email')) . '|' . $request->ip();
    }
    
    /**
     * Obter limitador
     */
    protected function limiter()
    {
        return app(\Illuminate\Cache\RateLimiter::class);
    }
    
    /**
     * Disparar evento de bloqueio
     */
    protected function fireLockoutEvent(Request $request)
    {
        event(new \Illuminate\Auth\Events\Lockout($request));
    }
    
    /**
     * Enviar resposta de bloqueio
     */
    protected function sendLockoutResponse(Request $request)
    {
        $seconds = $this->limiter()->availableIn(
            $this->throttleKey($request)
        );
        
        return redirect()->back()
            ->withInput($request->except('password'))
            ->with('error', 'Muitas tentativas de login. Por favor, tente novamente em ' . ceil($seconds / 60) . ' minutos.');
    }
}

