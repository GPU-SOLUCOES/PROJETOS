<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Estacionamento;
use App\Models\Registro;
use App\Models\Veiculo;
use App\Models\Servico;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Construtor
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('check.client.status');
    }
    
    /**
     * Mostrar dashboard
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        
        // Obter estacionamentos disponíveis para o usuário
        if ($user->tipo_acesso === 'super_admin') {
            $estacionamentos = Estacionamento::with('cliente')->orderBy('nome')->get();
        } else {
            $estacionamentos = Estacionamento::where('cliente_id', $user->cliente_id)
                ->orderBy('nome')
                ->get();
        }
        
        if ($estacionamentos->isEmpty()) {
            return view('dashboard.empty');
        }
        
        // Selecionar estacionamento atual
        $estacionamentoId = $request->input('estacionamento_id', $estacionamentos->first()->id);
        $estacionamentoAtual = $estacionamentos->firstWhere('id', $estacionamentoId);
        
        // Obter estatísticas do estacionamento
        $hoje = Carbon::today();
        
        // Contar veículos atualmente estacionados
        $veiculosEstacionados = Registro::where('estacionamento_id', $estacionamentoAtual->id)
            ->whereNull('data_saida')
            ->count();
        
        // Obter veículos estacionados
        $veiculosEstacionadosDetalhes = Registro::with(['veiculo', 'servico'])
            ->where('estacionamento_id', $estacionamentoAtual->id)
            ->whereNull('data_saida')
            ->orderBy('data_entrada', 'desc')
            ->get();
        
        // Calcular estatísticas
        $vagasDisponiveis = $estacionamentoAtual->capacidade - $veiculosEstacionados;
        $taxaOcupacao = $estacionamentoAtual->capacidade > 0 
            ? ($veiculosEstacionados / $estacionamentoAtual->capacidade) * 100 
            : 0;
        
        // Contar entradas de hoje
        $entradasHoje = Registro::where('estacionamento_id', $estacionamentoAtual->id)
            ->whereDate('data_entrada', $hoje)
            ->count();
        
        // Calcular faturamento de hoje
        $faturamentoHoje = Registro::where('estacionamento_id', $estacionamentoAtual->id)
            ->whereDate('data_saida', $hoje)
            ->sum('valor_pago');
        
        // Dados para gráficos
        $ultimos7Dias = [];
        for ($i = 6; $i >= 0; $i--) {
            $data = Carbon::today()->subDays($i);
            $ultimos7Dias[] = $data;
        }
        
        $dadosReceita = [];
        foreach ($ultimos7Dias as $data) {
            $receita = Registro::where('estacionamento_id', $estacionamentoAtual->id)
                ->whereDate('data_saida', $data)
                ->sum('valor_pago');
            
            $dadosReceita[] = [
                'data' => $data->format('d/m'),
                'total' => $receita,
            ];
        }
        
        // Dados de ocupação por hora
        $dadosOcupacaoPorHora = DB::table('registros')
            ->select(DB::raw('HOUR(data_entrada) as hora'), DB::raw('COUNT(*) as total'))
            ->where('estacionamento_id', $estacionamentoAtual->id)
            ->whereDate('data_entrada', $hoje)
            ->groupBy(DB::raw('HOUR(data_entrada)'))
            ->orderBy('hora')
            ->get();
        
        $dadosOcupacao = [];
        for ($i = 0; $i < 24; $i++) {
            $hora = $dadosOcupacaoPorHora->firstWhere('hora', $i);
            $total = $hora ? $hora->total : 0;
            $taxaHora = $estacionamentoAtual->capacidade > 0 
                ? ($total / $estacionamentoAtual->capacidade) * 100 
                : 0;
            
            $dadosOcupacao[] = [
                'hora' => $i . 'h',
                'ocupacao' => round($taxaHora, 1),
            ];
        }
        
        return view('dashboard.index', compact(
            'estacionamentos',
            'estacionamentoAtual',
            'vagasDisponiveis',
            'taxaOcupacao',
            'entradasHoje',
            'faturamentoHoje',
            'veiculosEstacionadosDetalhes',
            'dadosReceita',
            'dadosOcupacao'
        ));
    }
}

