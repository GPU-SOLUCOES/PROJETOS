<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Cliente;
use App\Models\StatusCliente;

class CheckClientStatus
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if (Auth::check()) {
            $user = Auth::user();
            
            // Super admin não precisa de verificação de cliente
            if ($user->tipo_acesso === 'super_admin') {
                return $next($request);
            }
            
            // Verificar se o usuário tem um cliente associado
            if ($user->cliente_id) {
                $statusCliente = StatusCliente::where('cliente_id', $user->cliente_id)->first();
                
                if (!$statusCliente) {
                    Auth::logout();
                    return redirect()->route('login')->with('error', 'Cliente não encontrado. Entre em contato com o suporte.');
                }
                
                // Verificar se o cliente está ativo
                if (!$statusCliente->ativo) {
                    Auth::logout();
                    return redirect()->route('login')->with('error', 'Este cliente está inativo. Entre em contato com o suporte.');
                }
                
                // Verificar se o cliente está bloqueado
                if ($statusCliente->bloqueado) {
                    $motivo = $statusCliente->motivo_bloqueio ?: 'Entre em contato com o suporte.';
                    Auth::logout();
                    return redirect()->route('login')->with('error', 'Acesso bloqueado: ' . $motivo);
                }
            }
        }
        
        return $next($request);
    }
}

