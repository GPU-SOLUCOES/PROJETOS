<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;

class Usuario extends Authenticatable
{
    use Notifiable;

    protected $table = 'usuarios';
    
    protected $fillable = [
        'nome', 'email', 'senha', 'tipo_acesso', 'cliente_id', 'ultimo_acesso'
    ];
    
    protected $hidden = [
        'senha', 'remember_token',
    ];
    
    /**
     * Obter o nome da coluna de senha para autenticação.
     *
     * @return string
     */
    public function getAuthPassword()
    {
        return $this->senha;
    }
    
    /**
     * Definir a senha do usuário.
     *
     * @param  string  $value
     * @return void
     */
    public function setSenhaAttribute($value)
    {
        $this->attributes['senha'] = Hash::make($value);
    }
    
    /**
     * Verificar se o usuário tem um determinado papel.
     *
     * @param  string|array  $roles
     * @return bool
     */
    public function hasRole($roles)
    {
        if (is_string($roles)) {
            return $this->tipo_acesso === $roles;
        }
        
        return in_array($this->tipo_acesso, $roles);
    }
    
    /**
     * Verificar se o usuário é super admin.
     *
     * @return bool
     */
    public function isSuperAdmin()
    {
        return $this->tipo_acesso === 'super_admin';
    }
    
    /**
     * Verificar se o usuário é admin.
     *
     * @return bool
     */
    public function isAdmin()
    {
        return $this->tipo_acesso === 'admin';
    }
    
    /**
     * Verificar se o usuário é gerente.
     *
     * @return bool
     */
    public function isGerente()
    {
        return $this->tipo_acesso === 'gerente';
    }
    
    /**
     * Verificar se o usuário é atendente.
     *
     * @return bool
     */
    public function isAtendente()
    {
        return $this->tipo_acesso === 'atendente';
    }
    
    /**
     * Relacionamento com cliente.
     */
    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }
    
    /**
     * Relacionamento com logs.
     */
    public function logs()
    {
        return $this->hasMany(Log::class, 'usuario_id');
    }
}

