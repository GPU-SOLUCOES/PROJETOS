"use client"

import { Sidebar } from "../src/components/sidebar"

export default function SyntheticV0PageForDeployment() {
  return <Sidebar />
}