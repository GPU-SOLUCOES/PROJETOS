// Funções JavaScript para o sistema

// Formatar valores monetários
function formatMoney(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
}

// Formatar data e hora
function formatDateTime(dateTime) {
  const date = new Date(dateTime)
  return date.toLocaleString("pt-BR")
}

// Formatar apenas data
function formatDate(date) {
  const d = new Date(date)
  return d.toLocaleDateString("pt-BR")
}

// Formatar apenas hora
function formatTime(time) {
  const t = new Date(time)
  return t.toLocaleTimeString("pt-BR")
}

// Calcular duração entre duas datas
function calculateDuration(startDate, endDate = null) {
  const start = new Date(startDate)
  const end = endDate ? new Date(endDate) : new Date()

  const diffMs = end - start
  const diffHrs = Math.floor(diffMs / (1000 * 60 * 60))
  const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

  return {
    hours: diffHrs,
    minutes: diffMins,
    totalMinutes: diffHrs * 60 + diffMins,
    formatted: `${diffHrs}h ${diffMins}min`,
  }
}

// Validar placa de veículo
function validateLicensePlate(plate) {
  // Formato antigo: AAA-1234
  // Formato Mercosul: AAA1A23
  const oldFormat = /^[A-Z]{3}-\d{4}$/
  const newFormat = /^[A-Z]{3}\d[A-Z]\d{2}$/

  return oldFormat.test(plate) || newFormat.test(plate)
}

// Validar CPF
function validateCPF(cpf) {
  cpf = cpf.replace(/[^\d]/g, "")

  if (cpf.length !== 11) return false

  // Verificar se todos os dígitos são iguais
  if (/^(\d)\1+$/.test(cpf)) return false

  // Validar dígitos verificadores
  let sum = 0
  let remainder

  for (let i = 1; i <= 9; i++) {
    sum += Number.parseInt(cpf.substring(i - 1, i)) * (11 - i)
  }

  remainder = (sum * 10) % 11

  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cpf.substring(9, 10))) return false

  sum = 0
  for (let i = 1; i <= 10; i++) {
    sum += Number.parseInt(cpf.substring(i - 1, i)) * (12 - i)
  }

  remainder = (sum * 10) % 11

  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cpf.substring(10, 11))) return false

  return true
}

// Função para imprimir recibo
function printReceipt() {
  window.print()
}

// Inicialização quando o documento estiver pronto
document.addEventListener("DOMContentLoaded", () => {
  // Inicializar tooltips do Bootstrap
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))

  // Inicializar popovers do Bootstrap
  const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
  popoverTriggerList.map((popoverTriggerEl) => new bootstrap.Popover(popoverTriggerEl))
})

