"use client"

import type React from "react"
import { createContext, useState, useContext, useEffect } from "react"
import AsyncStorage from "@react-native-async-storage/async-storage"
import axios from "axios"
import { API_URL } from "../config"

interface AuthContextData {
  isAuthenticated: boolean
  user: any
  token: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  loading: boolean
}

const AuthContext = createContext<AuthContextData>({} as AuthContextData)

export const AuthProvider: React.FC = ({ children }) => {
  const [user, setUser] = useState<any>(null)
  const [token, setToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Verificar se há um token salvo
    const loadStorageData = async () => {
      try {
        const storedToken = await AsyncStorage.getItem("@ParkingApp:token")
        const storedUser = await AsyncStorage.getItem("@ParkingApp:user")

        if (storedToken && storedUser) {
          setToken(storedToken)
          setUser(JSON.parse(storedUser))

          // Configurar o token para todas as requisições
          axios.defaults.headers.common["Authorization"] = `Bearer ${storedToken}`
        }
      } catch (error) {
        console.error("Erro ao carregar dados do storage:", error)
      } finally {
        setLoading(false)
      }
    }

    loadStorageData()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/login`, {
        email,
        password,
      })

      const { token: newToken, user: userData } = response.data

      // Salvar no storage
      await AsyncStorage.setItem("@ParkingApp:token", newToken)
      await AsyncStorage.setItem("@ParkingApp:user", JSON.stringify(userData))

      // Atualizar estado
      setToken(newToken)
      setUser(userData)

      // Configurar o token para todas as requisições
      axios.defaults.headers.common["Authorization"] = `Bearer ${newToken}`
    } catch (error) {
      console.error("Erro no login:", error)
      throw new Error(error.response?.data?.error || "Erro ao fazer login")
    }
  }

  const logout = async () => {
    try {
      // Remover do storage
      await AsyncStorage.removeItem("@ParkingApp:token")
      await AsyncStorage.removeItem("@ParkingApp:user")

      // Limpar estado
      setToken(null)
      setUser(null)

      // Remover token das requisições
      delete axios.defaults.headers.common["Authorization"]
    } catch (error) {
      console.error("Erro ao fazer logout:", error)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated: !!token,
        user,
        token,
        login,
        logout,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  return context
}

