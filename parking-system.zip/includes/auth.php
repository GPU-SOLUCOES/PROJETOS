<?php
// Funções de autenticação e controle de acesso

// Verificar se o usuário está logado
function isLoggedIn() {
  return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Autenticar usuário
function authenticateUser($email, $password) {
  $sql = "SELECT u.*, c.id as cliente_id FROM usuarios u 
          LEFT JOIN clientes c ON u.cliente_id = c.id 
          WHERE u.email = ?";
  
  $user = fetchOne($sql, [$email]);
  
  if (!$user) {
      return false;
  }
  
  // Verificar senha
  if (password_verify($password, $user['senha'])) {
      // Armazenar dados do usuário na sessão
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['user_name'] = $user['nome'];
      $_SESSION['user_email'] = $user['email'];
      $_SESSION['user_type'] = $user['tipo_acesso'];
      $_SESSION['cliente_id'] = $user['cliente_id'];
      
      // Verificar se o cliente está ativo (exceto para super_admin)
      if ($user['tipo_acesso'] != 'super_admin' && $user['cliente_id']) {
          $sql = "SELECT ativo FROM status_clientes WHERE cliente_id = ?";
          $statusCliente = fetchOne($sql, [$user['cliente_id']]);
          
          if ($statusCliente && !$statusCliente['ativo']) {
              // Cliente inativo, não permitir login
              session_unset();
              session_destroy();
              return false;
          }
      }
      
      // Registrar login
      try {
          logActivity($user['id'], 'login', 'Login no sistema');
      } catch (Exception $e) {
          // Ignora o erro de log para permitir o login
      }
      
      return true;
  }
  
  return false;
}

// Fazer logout
function logout() {
  // Registrar logout
  if (isset($_SESSION['user_id'])) {
      try {
          logActivity($_SESSION['user_id'], 'logout', 'Logout do sistema');
      } catch (Exception $e) {
          // Ignora o erro de log para permitir o logout
      }
  }
  
  // Destruir sessão
  session_unset();
  session_destroy();
  
  // Redirecionar para login
  header('Location: login.php');
  exit;
}

// Criar novo usuário
function createUser($nome, $email, $senha, $tipoAcesso, $clienteId) {
  // Verificar se o email já existe
  $sql = "SELECT id FROM usuarios WHERE email = ?";
  $existingUser = fetchOne($sql, [$email]);
  
  if ($existingUser) {
      return [
          'success' => false,
          'message' => 'Este email já está em uso.'
      ];
  }
  
  // Hash da senha
  $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
  
  // Inserir novo usuário
  $data = [
      'nome' => $nome,
      'email' => $email,
      'senha' => $senhaHash,
      'tipo_acesso' => $tipoAcesso,
      'cliente_id' => $clienteId,
      'data_criacao' => date('Y-m-d H:i:s')
  ];
  
  $userId = insert('usuarios', $data);
  
  if ($userId) {
      return [
          'success' => true,
          'user_id' => $userId
      ];
  } else {
      return [
          'success' => false,
          'message' => 'Erro ao criar usuário.'
      ];
  }
}

// Atualizar usuário
function updateUser($userId, $data) {
  // Se a senha estiver sendo atualizada, fazer hash
  if (isset($data['senha']) && !empty($data['senha'])) {
      $data['senha'] = password_hash($data['senha'], PASSWORD_DEFAULT);
  } else {
      // Se a senha estiver vazia, remover do array para não atualizar
      unset($data['senha']);
  }
  
  // Atualizar usuário
  $result = update('usuarios', $data, 'id = ?', [$userId]);
  
  return $result > 0;
}

// Excluir usuário
function deleteUser($userId) {
  // Verificar se não é o último administrador
  $sql = "SELECT COUNT(*) as total FROM usuarios WHERE tipo_acesso = 'admin'";
  $result = fetchOne($sql);
  
  if ($result['total'] <= 1) {
      $sql = "SELECT tipo_acesso FROM usuarios WHERE id = ?";
      $user = fetchOne($sql, [$userId]);
      
      if ($user && $user['tipo_acesso'] == 'admin') {
          return [
              'success' => false,
              'message' => 'Não é possível excluir o último administrador do sistema.'
          ];
      }
  }
  
  // Excluir usuário
  $result = delete('usuarios', 'id = ?', [$userId]);
  
  if ($result) {
      return [
          'success' => true
      ];
  } else {
      return [
          'success' => false,
          'message' => 'Erro ao excluir usuário.'
      ];
  }
}

// Obter usuários por cliente
function getUsersByClient($clienteId) {
  $sql = "SELECT id, nome, email, tipo_acesso, data_criacao FROM usuarios WHERE cliente_id = ?";
  return fetchAll($sql, [$clienteId]);
}

// Obter estacionamentos por cliente
function getParkingsByClient($clienteId) {
  $sql = "SELECT * FROM estacionamentos WHERE cliente_id = ?";
  return fetchAll($sql, [$clienteId]);
}
?>

