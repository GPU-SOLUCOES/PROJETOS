<?php
// Funções utilitárias para o sistema

// Verificar permissões de acesso
function hasPermission($page) {
  if (!isset($_SESSION['user_type'])) {
      return false;
  }
  
  $userType = $_SESSION['user_type'];
  
  // Super admin tem acesso a tudo
  if ($userType == 'super_admin') {
      return true;
  }
  
  // Páginas acessíveis por todos os usuários
  $commonPages = ['dashboard', 'entrada', 'saida'];
  
  if (in_array($page, $commonPages)) {
      return true;
  }
  
  // Páginas acessíveis apenas por gerentes e administradores
  $managerPages = ['admin', 'financeiro'];
  
  if (in_array($page, $managerPages) && ($userType == 'gerente' || $userType == 'admin')) {
      return true;
  }
  
  // Páginas acessíveis apenas por administradores
  $adminPages = ['suporte'];
  
  if (in_array($page, $adminPages) && $userType == 'admin') {
      return true;
  }
  
  // Páginas acessíveis apenas por super administradores
  $superAdminPages = ['super_admin', 'super_admin_dashboard'];
  
  if (in_array($page, $superAdminPages) && $userType == 'super_admin') {
      return true;
  }
  
  return false;
}

// Formatar data e hora
function formatDateTime($dateTime) {
    $date = new DateTime($dateTime);
    return $date->format('d/m/Y H:i:s');
}

// Calcular tempo de permanência
function calculateDuration($entryTime, $exitTime = null) {
    $entry = new DateTime($entryTime);
    $exit = $exitTime ? new DateTime($exitTime) : new DateTime();
    
    $diff = $entry->diff($exit);
    
    $hours = $diff->h + ($diff->days * 24);
    $minutes = $diff->i;
    
    return [
        'hours' => $hours,
        'minutes' => $minutes,
        'total_minutes' => ($hours * 60) + $minutes
    ];
}

// Calcular valor a pagar
function calculatePayment($entryTime, $exitTime, $serviceType, $estacionamentoId) {
    $duration = calculateDuration($entryTime, $exitTime);
    
    // Obter valores do serviço
    $sql = "SELECT * FROM servicos WHERE tipo = ? AND estacionamento_id = ?";
    $service = fetchOne($sql, [$serviceType, $estacionamentoId]);
    
    if (!$service) {
        return 0;
    }
    
    $totalValue = 0;
    
    switch ($serviceType) {
        case 'hora':
            // Valor por hora, com fração mínima de 1 hora
            $totalHours = ceil($duration['total_minutes'] / 60);
            $totalValue = $totalHours * $service['valor'];
            break;
            
        case 'diaria':
            // Valor fixo por dia
            $totalValue = $service['valor'];
            break;
            
        case 'mensalista':
            // Mensalista não paga na saída
            $totalValue = 0;
            break;
    }
    
    return $totalValue;
}

// Gerar relatório financeiro
function generateFinancialReport($estacionamentoId, $startDate, $endDate) {
    $sql = "SELECT 
                r.*, 
                v.modelo, 
                v.placa, 
                s.tipo AS servico_tipo 
            FROM 
                registros r
            JOIN 
                veiculos v ON r.veiculo_id = v.id
            JOIN 
                servicos s ON r.servico_id = s.id
            WHERE 
                r.estacionamento_id = ? AND 
                r.data_saida BETWEEN ? AND ?";
    
    return fetchAll($sql, [$estacionamentoId, $startDate, $endDate]);
}

// Verificar disponibilidade de vagas
function checkAvailableSpots($estacionamentoId) {
    // Obter capacidade total
    $sql = "SELECT capacidade FROM estacionamentos WHERE id = ?";
    $estacionamento = fetchOne($sql, [$estacionamentoId]);
    
    if (!$estacionamento) {
        return 0;
    }
    
    $capacidadeTotal = $estacionamento['capacidade'];
    
    // Contar veículos atualmente estacionados
    $sql = "SELECT COUNT(*) as total FROM registros WHERE estacionamento_id = ? AND data_saida IS NULL";
    $result = fetchOne($sql, [$estacionamentoId]);
    
    $vagasOcupadas = $result['total'];
    
    return $capacidadeTotal - $vagasOcupadas;
}

// Sanitizar entrada de dados
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Validar placa de veículo (formato brasileiro)
function validateLicensePlate($plate) {
    // Formato antigo: AAA-1234
    // Formato Mercosul: AAA1A23
    $oldFormat = '/^[A-Z]{3}\-\d{4}$/';
    $newFormat = '/^[A-Z]{3}\d[A-Z]\d{2}$/';
    
    return preg_match($oldFormat, $plate) || preg_match($newFormat, $plate);
}

// Validar CPF
function validateCPF($cpf) {
    // Remove caracteres especiais
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    // Verifica se o CPF tem 11 dígitos
    if (strlen($cpf) != 11) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }
    
    // Calcula o primeiro dígito verificador
    $soma = 0;
    for ($i = 0; $i < 9; $i++) {
        $soma += $cpf[$i] * (10 - $i);
    }
    $resto = $soma % 11;
    $dv1 = ($resto < 2) ? 0 : 11 - $resto;
    
    // Calcula o segundo dígito verificador
    $soma = 0;
    for ($i = 0; $i < 9; $i++) {
        $soma += $cpf[$i] * (11 - $i);
    }
    $soma += $dv1 * 2;
    $resto = $soma % 11;
    $dv2 = ($resto < 2) ? 0 : 11 - $resto;
    
    // Verifica se os dígitos verificadores estão corretos
    return ($cpf[9] == $dv1 && $cpf[10] == $dv2);
}

// Gerar log de atividade
function logActivity($userId, $action, $details = '') {
    $data = [
        'usuario_id' => $userId,
        'acao' => $action,
        'detalhes' => $details,
        'data_hora' => date('Y-m-d H:i:s'),
        'ip' => $_SERVER['REMOTE_ADDR']
    ];
    
    insert('logs', $data);
}
?>

