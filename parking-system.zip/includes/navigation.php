<?php if (isLoggedIn()): ?>
<!-- Menu de navegação lateral -->
<div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
  <div class="position-sticky pt-3">
      <ul class="nav flex-column">
          <?php if ($_SESSION['user_type'] == 'super_admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo $page == 'super_admin_dashboard' ? 'active' : ''; ?>" href="?page=super_admin_dashboard">
                      <i class="fas fa-chart-line me-2"></i> Dashboard Financeiro
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo $page == 'super_admin' ? 'active' : ''; ?>" href="?page=super_admin">
                      <i class="fas fa-users-cog me-2"></i> Gerenciar Clientes
                  </a>
              </li>
              <li class="nav-item">
                  <hr>
              </li>
          <?php endif; ?>
          
          <li class="nav-item">
              <a class="nav-link <?php echo $page == 'dashboard' ? 'active' : ''; ?>" href="?page=dashboard">
                  <i class="fas fa-tachometer-alt me-2"></i> Início
              </a>
          </li>
          
          <li class="nav-item">
              <a class="nav-link <?php echo $page == 'entrada' ? 'active' : ''; ?>" href="?page=entrada">
                  <i class="fas fa-car me-2"></i> Entrada de Veículo
              </a>
          </li>
          
          <?php if ($_SESSION['user_type'] == 'gerente' || $_SESSION['user_type'] == 'admin' || $_SESSION['user_type'] == 'super_admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo $page == 'admin' ? 'active' : ''; ?>" href="?page=admin">
                      <i class="fas fa-cogs me-2"></i> Administração
                  </a>
              </li>
              
              <li class="nav-item">
                  <a class="nav-link <?php echo $page == 'financeiro' ? 'active' : ''; ?>" href="?page=financeiro">
                      <i class="fas fa-chart-line me-2"></i> Financeiro
                  </a>
              </li>
          <?php endif; ?>
          
          <?php if ($_SESSION['user_type'] == 'admin' || $_SESSION['user_type'] == 'super_admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo $page == 'suporte' ? 'active' : ''; ?>" href="?page=suporte">
                      <i class="fas fa-palette me-2"></i> Suporte
                  </a>
              </li>
          <?php endif; ?>
      </ul>
      
      <?php 
      // Verificar se é super admin ou gerente/admin
      $showEstacionamentoSelector = false;
      
      if ($_SESSION['user_type'] == 'super_admin') {
          $showEstacionamentoSelector = true;
          $estacionamentos = [];
          
          // Se tiver um estacionamento selecionado, buscar todos os estacionamentos do mesmo cliente
          if (isset($_SESSION['estacionamento_id']) && isset($_SESSION['temp_cliente_id'])) {
              $sql = "SELECT * FROM estacionamentos WHERE cliente_id = ? ORDER BY nome";
              $estacionamentos = fetchAll($sql, [$_SESSION['temp_cliente_id']]);
          }
      } elseif ($_SESSION['user_type'] == 'gerente' || $_SESSION['user_type'] == 'admin') {
          $showEstacionamentoSelector = true;
          $clienteId = $_SESSION['cliente_id'] ?? null;
          
          if ($clienteId) {
              $estacionamentos = getParkingsByClient($clienteId);
          }
      }
      
      if ($showEstacionamentoSelector && !empty($estacionamentos)):
      ?>
          <!-- Seletor de estacionamento -->
          <div class="mt-4 px-3">
              <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                  <span>Estacionamento</span>
                  <?php if ($_SESSION['user_type'] == 'super_admin'): ?>
                      <a href="?page=dashboard" class="text-decoration-none" title="Ver todos">
                          <i class="fas fa-list"></i>
                      </a>
                  <?php endif; ?>
              </h6>
              
              <select class="form-select form-select-sm" id="estacionamentoSelector">
                  <?php foreach ($estacionamentos as $estacionamento): ?>
                      <?php
                      $selected = '';
                      
                      if (isset($_SESSION['estacionamento_id']) && $_SESSION['estacionamento_id'] == $estacionamento['id']) {
                          $selected = 'selected';
                      }
                      ?>
                      <option value="<?php echo $estacionamento['id']; ?>" <?php echo $selected; ?>>
                          <?php echo $estacionamento['nome']; ?>
                      </option>
                  <?php endforeach; ?>
              </select>
          </div>
      <?php endif; ?>
  </div>
</div>

<!-- Conteúdo principal -->
<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
<?php endif; ?>

