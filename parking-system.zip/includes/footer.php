<?php if (isLoggedIn()): ?>
        </div>
    </div>
<?php endif; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
    
    <?php if (isLoggedIn() && isset($_SESSION['user_type']) && ($_SESSION['user_type'] == 'gerente' || $_SESSION['user_type'] == 'admin')): ?>
        <script>
            // Seletor de estacionamento
            $(document).ready(function() {
                $('#estacionamentoSelector').change(function() {
                    const estacionamentoId = $(this).val();
                    
                    // Salvar seleção na sessão via AJAX
                    $.ajax({
                        url: 'ajax/set_estacionamento.php',
                        type: 'POST',
                        data: { estacionamento_id: estacionamentoId },
                        success: function(response) {
                            // Recarregar a página
                            location.reload();
                        }
                    });
                });
            });
        </script>
    <?php endif; ?>
</body>
</html>

