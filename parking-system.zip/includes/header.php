<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão de Estacionamentos</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <?php
    // Carregar configurações de estilo personalizadas
    if (isLoggedIn()) {
        $clienteId = $_SESSION['cliente_id'] ?? null;
        
        if ($clienteId) {
            $sql = "SELECT * FROM configuracoes WHERE cliente_id = ?";
            $config = fetchOne($sql, [$clienteId]);
            
            if ($config) {
                echo '<style>';
                echo ':root {';
                echo '--primary-color: ' . ($config['cor_primaria'] ?? '#007bff') . ';';
                echo '--secondary-color: ' . ($config['cor_secundaria'] ?? '#6c757d') . ';';
                echo '--accent-color: ' . ($config['cor_destaque'] ?? '#ffc107') . ';';
                echo '}';
                echo '</style>';
            }
        }
    }
    ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <?php if (isLoggedIn()): ?>
                <!-- Cabeçalho do sistema -->
                <header class="bg-primary text-white p-3 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <?php
                        // Exibir logo do cliente
                        if (isset($_SESSION['cliente_id'])) {
                            $sql = "SELECT logo FROM clientes WHERE id = ?";
                            $cliente = fetchOne($sql, [$_SESSION['cliente_id']]);
                            
                            if ($cliente && !empty($cliente['logo'])) {
                                echo '<img src="' . $cliente['logo'] . '" alt="Logo" class="me-3" style="height: 40px;">';
                            } else {
                                echo '<i class="fas fa-parking fa-2x me-3"></i>';
                            }
                        } else {
                            echo '<i class="fas fa-parking fa-2x me-3"></i>';
                        }
                        ?>
                        <h1 class="h4 mb-0">Sistema de Gestão de Estacionamentos</h1>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="me-3">Olá, <?php echo $_SESSION['user_name']; ?></span>
                        <a href="logout.php" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-sign-out-alt me-1"></i> Sair
                        </a>
                    </div>
                </header>
            <?php endif; ?>

