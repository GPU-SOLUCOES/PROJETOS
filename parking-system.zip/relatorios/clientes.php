<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso negado']);
    exit;
}

// Definir tipo de saída
$formato = $_GET['formato'] ?? 'csv';

// Construir consulta SQL
$sql = "SELECT 
            c.id, 
            c.nome, 
            c.endereco, 
            c.telefone, 
            c.email, 
            c.data_cadastro,
            sc.ativo,
            sc.bloqueado,
            sc.motivo_bloqueio,
            sc.data_bloqueio,
            sc.data_desbloqueio,
            sc.dias_graca,
            (SELECT COUNT(*) FROM estacionamentos e WHERE e.cliente_id = c.id) as total_estacionamentos,
            (SELECT COUNT(*) FROM filiais f WHERE f.cliente_id = c.id) as total_filiais,
            (SELECT COUNT(*) FROM usuarios u WHERE u.cliente_id = c.id) as total_usuarios,
            (SELECT SUM(valor) FROM pagamentos_clientes pc WHERE pc.cliente_id = c.id AND pc.status = 'pago') as total_pago,
            (SELECT SUM(valor) FROM pagamentos_clientes pc WHERE pc.cliente_id = c.id AND pc.status = 'pendente') as total_pendente,
            (SELECT SUM(valor) FROM pagamentos_clientes pc WHERE pc.cliente_id = c.id AND pc.status = 'atrasado') as total_atrasado
        FROM 
            clientes c
        LEFT JOIN 
            status_clientes sc ON c.id = sc.cliente_id
        ORDER BY 
            c.nome";

$clientes = fetchAll($sql);

// Gerar nome do arquivo
$nomeArquivo = 'relatorio_clientes_' . date('Y-m-d_H-i-s');

// Gerar relatório no formato solicitado
if ($formato == 'json') {
    // Formato JSON
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.json"');
    echo json_encode($clientes);
    exit;
} else {
    // Formato CSV (padrão)
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.csv"');
    
    // Criar arquivo CSV
    $output = fopen('php://output', 'w');
    
    // Adicionar BOM para UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Cabeçalho
    fputcsv($output, [
        'ID', 
        'Nome', 
        'Endereço', 
        'Telefone', 
        'Email', 
        'Data de Cadastro',
        'Ativo',
        'Bloqueado',
        'Motivo do Bloqueio',
        'Data do Bloqueio',
        'Data do Desbloqueio',
        'Dias de Graça',
        'Total de Estacionamentos',
        'Total de Filiais',
        'Total de Usuários',
        'Total Pago (R$)',
        'Total Pendente (R$)',
        'Total Atrasado (R$)'
    ]);
    
    // Dados
    foreach ($clientes as $cliente) {
        // Formatar valores
        $cliente['data_cadastro'] = date('d/m/Y', strtotime($cliente['data_cadastro']));
        $cliente['ativo'] = $cliente['ativo'] ? 'Sim' : 'Não';
        $cliente['bloqueado'] = $cliente['bloqueado'] ? 'Sim' : 'Não';
        $cliente['data_bloqueio'] = $cliente['data_bloqueio'] ? date('d/m/Y H:i', strtotime($cliente['data_bloqueio'])) : 'N/A';
        $cliente['data_desbloqueio'] = $cliente['data_desbloqueio'] ? date('d/m/Y H:i', strtotime($cliente['data_desbloqueio'])) : 'N/A';
        $cliente['total_pago'] = $cliente['total_pago'] ? number_format($cliente['total_pago'], 2, ',', '.') : '0,00';
        $cliente['total_pendente'] = $cliente['total_pendente'] ? number_format($cliente['total_pendente'], 2, ',', '.') : '0,00';
        $cliente['total_atrasado'] = $cliente['total_atrasado'] ? number_format($cliente['total_atrasado'], 2, ',', '.') : '0,00';
        
        fputcsv($output, [
            $cliente['id'],
            $cliente['nome'],
            $cliente['endereco'],
            $cliente['telefone'],
            $cliente['email'],
            $cliente['data_cadastro'],
            $cliente['ativo'],
            $cliente['bloqueado'],
            $cliente['motivo_bloqueio'] ?? 'N/A',
            $cliente['data_bloqueio'],
            $cliente['data_desbloqueio'],
            $cliente['dias_graca'],
            $cliente['total_estacionamentos'],
            $cliente['total_filiais'],
            $cliente['total_usuarios'],
            $cliente['total_pago'],
            $cliente['total_pendente'],
            $cliente['total_atrasado']
        ]);
    }
    
    fclose($output);
    exit;
}

