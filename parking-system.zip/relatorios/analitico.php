<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso negado']);
    exit;
}

// Obter parâmetros
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-30 days'));
$dataFim = $_GET['data_fim'] ?? date('Y-m-d');
$clienteId = isset($_GET['cliente_id']) && !empty($_GET['cliente_id']) ? intval($_GET['cliente_id']) : null;

// Definir tipo de saída
$formato = $_GET['formato'] ?? 'csv';

// Construir filtro de cliente
$filtroCliente = isset($clienteId) ? "AND pc.cliente_id = $clienteId" : "";

// Obter dados por mês
$sql = "SELECT 
            DATE_FORMAT(pc.data_vencimento, '%Y-%m') as mes,
            SUM(CASE WHEN pc.status = 'pago' THEN pc.valor ELSE 0 END) as valor_pago,
            SUM(CASE WHEN pc.status = 'pendente' THEN pc.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN pc.status = 'atrasado' THEN pc.valor ELSE 0 END) as valor_atrasado,
            COUNT(CASE WHEN pc.status = 'pago' THEN 1 ELSE NULL END) as qtd_pagos,
            COUNT(CASE WHEN pc.status = 'pendente' THEN 1 ELSE NULL END) as qtd_pendentes,
            COUNT(CASE WHEN pc.status = 'atrasado' THEN 1 ELSE NULL END) as qtd_atrasados
        FROM 
            pagamentos_clientes pc
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente
        GROUP BY 
            DATE_FORMAT(pc.data_vencimento, '%Y-%m')
        ORDER BY 
            mes ASC";

$dadosPorMes = fetchAll($sql, [$dataInicio, $dataFim]);

// Obter dados por cliente
$sql = "SELECT 
            c.nome as cliente,
            SUM(CASE WHEN pc.status = 'pago' THEN pc.valor ELSE 0 END) as valor_pago,
            SUM(CASE WHEN pc.status = 'pendente' THEN pc.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN pc.status = 'atrasado' THEN pc.valor ELSE 0 END) as valor_atrasado,
            COUNT(CASE WHEN pc.status = 'pago' THEN 1 ELSE NULL END) as qtd_pagos,
            COUNT(CASE WHEN pc.status = 'pendente' THEN 1 ELSE NULL END) as qtd_pendentes,
            COUNT(CASE WHEN pc.status = 'atrasado' THEN 1 ELSE NULL END) as qtd_atrasados
        FROM 
            pagamentos_clientes pc
        JOIN 
            clientes c ON pc.cliente_id = c.id
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente
        GROUP BY 
            pc.cliente_id
        ORDER BY 
            valor_pago DESC";

$dadosPorCliente = fetchAll($sql, [$dataInicio, $dataFim]);

// Obter dados por método de pagamento
$sql = "SELECT 
            COALESCE(pc.metodo_pagamento, 'Não informado') as metodo,
            COUNT(*) as quantidade,
            SUM(pc.valor) as valor_total
        FROM 
            pagamentos_clientes pc
        WHERE 
            pc.status = 'pago' 
            AND pc.data_pagamento BETWEEN ? AND ? $filtroCliente
        GROUP BY 
            pc.metodo_pagamento
        ORDER BY 
            valor_total DESC";

$dadosPorMetodo = fetchAll($sql, [$dataInicio, $dataFim]);

// Preparar dados para o relatório
$relatorio = [
    'periodo' => [
        'data_inicio' => $dataInicio,
        'data_fim' => $dataFim
    ],
    'por_mes' => $dadosPorMes,
    'por_cliente' => $dadosPorCliente,
    'por_metodo' => $dadosPorMetodo
];

// Gerar nome do arquivo
$nomeArquivo = 'relatorio_analitico_' . date('Y-m-d_H-i-s');

// Gerar relatório no formato solicitado
if ($formato == 'json') {
    // Formato JSON
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.json"');
    echo json_encode($relatorio);
    exit;
} else {
    // Formato CSV (padrão)
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.csv"');
    
    // Criar arquivo CSV
    $output = fopen('php://output', 'w');
    
    // Adicionar BOM para UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Informações do período
    fputcsv($output, ['Relatório Analítico']);
    fputcsv($output, ['Período:', 'De ' . date('d/m/Y', strtotime($dataInicio)) . ' a ' . date('d/m/Y', strtotime($dataFim))]);
    fputcsv($output, []);
    
    // Dados por mês
    fputcsv($output, ['ANÁLISE POR MÊS']);
    fputcsv($output, ['Mês', 'Valor Pago (R$)', 'Valor Pendente (R$)', 'Valor Atrasado (R$)', 'Qtd. Pagos', 'Qtd. Pendentes', 'Qtd. Atrasados']);
    
    foreach ($dadosPorMes as $dado) {
        fputcsv($output, [
            date('m/Y', strtotime($dado['mes'] . '-01')),
            number_format($dado['valor_pago'], 2, ',', '.'),
            number_format($dado['valor_pendente'], 2, ',', '.'),
            number_format($dado['valor_atrasado'], 2, ',', '.'),
            $dado['qtd_pagos'],
            $dado['qtd_pendentes'],
            $dado['qtd_atrasados']
        ]);
    }
    
    fputcsv($output, []);
    
    // Dados por cliente
    fputcsv($output, ['ANÁLISE POR CLIENTE']);
    fputcsv($output, ['Cliente', 'Valor Pago (R$)', 'Valor Pendente (R$)', 'Valor Atrasado (R$)', 'Qtd. Pagos', 'Qtd. Pendentes', 'Qtd. Atrasados']);
    
    foreach ($dadosPorCliente as $dado) {
        fputcsv($output, [
            $dado['cliente'],
            number_format($dado['valor_pago'], 2, ',', '.'),
            number_format($dado['valor_pendente'], 2, ',', '.'),
            number_format($dado['valor_atrasado'], 2, ',', '.'),
            $dado['qtd_pagos'],
            $dado['qtd_pendentes'],
            $dado['qtd_atrasados']
        ]);
    }
    
    fputcsv($output, []);
    
    // Dados por método de pagamento
    fputcsv($output, ['ANÁLISE POR MÉTODO DE PAGAMENTO']);
    fputcsv($output, ['Método', 'Quantidade', 'Valor Total (R$)']);
    
    foreach ($dadosPorMetodo as $dado) {
        fputcsv($output, [
            $dado['metodo'],
            $dado['quantidade'],
            number_format($dado['valor_total'], 2, ',', '.')
        ]);
    }
    
    fclose($output);
    exit;
}

