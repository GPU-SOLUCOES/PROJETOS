<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

// Verificar se o usuário está logado e é super_admin
if (!isLoggedIn() || $_SESSION['user_type'] != 'super_admin') {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso negado']);
    exit;
}

// Obter parâmetros
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-30 days'));
$dataFim = $_GET['data_fim'] ?? date('Y-m-d');
$clienteId = isset($_GET['cliente_id']) && !empty($_GET['cliente_id']) ? intval($_GET['cliente_id']) : null;

// Definir tipo de saída
$formato = $_GET['formato'] ?? 'csv';

// Construir consulta SQL
$filtroCliente = isset($clienteId) ? "AND pc.cliente_id = $clienteId" : "";

$sql = "SELECT 
            pc.id, 
            c.nome as cliente, 
            pc.valor, 
            pc.data_vencimento, 
            pc.status, 
            pc.data_pagamento, 
            pc.metodo_pagamento, 
            pc.observacoes,
            pc.created_at
        FROM 
            pagamentos_clientes pc
        JOIN 
            clientes c ON pc.cliente_id = c.id
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente
        ORDER BY 
            pc.data_vencimento DESC";

$pagamentos = fetchAll($sql, [$dataInicio, $dataFim]);

// Gerar nome do arquivo
$nomeArquivo = 'relatorio_financeiro_' . date('Y-m-d_H-i-s');

// Gerar relatório no formato solicitado
if ($formato == 'json') {
    // Formato JSON
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.json"');
    echo json_encode($pagamentos);
    exit;
} else {
    // Formato CSV (padrão)
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '.csv"');
    
    // Criar arquivo CSV
    $output = fopen('php://output', 'w');
    
    // Adicionar BOM para UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Cabeçalho
    fputcsv($output, [
        'ID', 
        'Cliente', 
        'Valor (R$)', 
        'Data de Vencimento', 
        'Status', 
        'Data de Pagamento', 
        'Método de Pagamento', 
        'Observações',
        'Data de Registro'
    ]);
    
    // Dados
    foreach ($pagamentos as $pagamento) {
        // Formatar valores
        $pagamento['valor'] = number_format($pagamento['valor'], 2, ',', '.');
        $pagamento['data_vencimento'] = date('d/m/Y', strtotime($pagamento['data_vencimento']));
        $pagamento['data_pagamento'] = $pagamento['data_pagamento'] ? date('d/m/Y', strtotime($pagamento['data_pagamento'])) : 'N/A';
        $pagamento['created_at'] = date('d/m/Y H:i', strtotime($pagamento['created_at']));
        
        // Traduzir status
        switch ($pagamento['status']) {
            case 'pendente':
                $pagamento['status'] = 'Pendente';
                break;
            case 'pago':
                $pagamento['status'] = 'Pago';
                break;
            case 'atrasado':
                $pagamento['status'] = 'Atrasado';
                break;
            case 'cancelado':
                $pagamento['status'] = 'Cancelado';
                break;
        }
        
        fputcsv($output, [
            $pagamento['id'],
            $pagamento['cliente'],
            $pagamento['valor'],
            $pagamento['data_vencimento'],
            $pagamento['status'],
            $pagamento['data_pagamento'],
            $pagamento['metodo_pagamento'] ?? 'N/A',
            $pagamento['observacoes'] ?? '',
            $pagamento['created_at']
        ]);
    }
    
    fclose($output);
    exit;
}

