<?php
// Chamar a função de logout
logout();
// A função logout() já contém o redirecionamento para a página de login
?>

