<?php
// Verificar permissões - apenas super_admin pode acessar
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'super_admin') {
  echo '<div class="alert alert-danger">Você não tem permissão para acessar esta página.</div>';
  exit;
}

// Definir subpágina
$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'clientes';

// Processar ações
$mensagem = '';
$tipoMensagem = '';

// Processar criação/edição de cliente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'clientes') {
  $clienteId = intval($_POST['cliente_id'] ?? 0);
  $nome = sanitizeInput($_POST['nome'] ?? '');
  $endereco = sanitizeInput($_POST['endereco'] ?? '');
  $telefone = sanitizeInput($_POST['telefone'] ?? '');
  $email = sanitizeInput($_POST['email'] ?? '');
  
  if (empty($nome)) {
      $mensagem = 'O nome do cliente é obrigatório.';
      $tipoMensagem = 'danger';
  } else {
      $dadosCliente = [
          'nome' => $nome,
          'endereco' => $endereco,
          'telefone' => $telefone,
          'email' => $email
      ];
      
      // Upload de logo, se fornecido
      if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
          $uploadDir = 'uploads/logos/';
          
          // Criar diretório se não existir
          if (!file_exists($uploadDir)) {
              mkdir($uploadDir, 0777, true);
          }
          
          $fileName = time() . '_' . basename($_FILES['logo']['name']);
          $uploadFile = $uploadDir . $fileName;
          
          // Verificar tipo de arquivo
          $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
          $fileType = $_FILES['logo']['type'];
          
          if (in_array($fileType, $allowedTypes)) {
              if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                  $dadosCliente['logo'] = $uploadFile;
              }
          }
      }
      
      if ($clienteId > 0) {
          // Editar cliente existente
          $resultado = update('clientes', $dadosCliente, 'id = ?', [$clienteId]);
          
          if ($resultado) {
              $mensagem = 'Cliente atualizado com sucesso!';
              $tipoMensagem = 'success';
          } else {
              $mensagem = 'Erro ao atualizar cliente.';
              $tipoMensagem = 'danger';
          }
      } else {
          // Criar novo cliente
          $dadosCliente['data_cadastro'] = date('Y-m-d H:i:s');
          $clienteId = insert('clientes', $dadosCliente);
          
          if ($clienteId) {
              $mensagem = 'Cliente criado com sucesso!';
              $tipoMensagem = 'success';
              
              // Criar configurações padrão para o cliente
              $dadosConfig = [
                  'cliente_id' => $clienteId,
                  'cor_primaria' => '#007bff',
                  'cor_secundaria' => '#6c757d',
                  'cor_destaque' => '#ffc107',
                  'mensagem_ticket' => 'Obrigado por utilizar nosso estacionamento!',
                  'exibir_logo_ticket' => 1
              ];
              
              insert('configuracoes', $dadosConfig);
              
              // Criar status do cliente
              $dadosStatus = [
                  'cliente_id' => $clienteId,
                  'ativo' => true,
                  'bloqueado' => false,
                  'dias_graca' => 5
              ];
              
              insert('status_clientes', $dadosStatus);
          } else {
              $mensagem = 'Erro ao criar cliente.';
              $tipoMensagem = 'danger';
          }
      }
  }
}

// Processar criação de usuário administrador para cliente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'criar_admin') {
  $clienteId = intval($_POST['cliente_id'] ?? 0);
  $nome = sanitizeInput($_POST['nome'] ?? '');
  $email = sanitizeInput($_POST['email'] ?? '');
  $senha = $_POST['senha'] ?? '';
  
  if (empty($nome) || empty($email) || empty($senha) || $clienteId <= 0) {
      $mensagem = 'Todos os campos são obrigatórios.';
      $tipoMensagem = 'danger';
  } else {
      // Verificar se o cliente existe
      $sql = "SELECT id FROM clientes WHERE id = ?";
      $cliente = fetchOne($sql, [$clienteId]);
      
      if (!$cliente) {
          $mensagem = 'Cliente não encontrado.';
          $tipoMensagem = 'danger';
      } else {
          // Verificar se já existe um usuário com este email
          $sql = "SELECT id FROM usuarios WHERE email = ?";
          $usuarioExistente = fetchOne($sql, [$email]);
          
          if ($usuarioExistente) {
              $mensagem = 'Este email já está em uso.';
              $tipoMensagem = 'danger';
          } else {
              // Criar usuário administrador
              $resultado = createUser($nome, $email, $senha, 'admin', $clienteId);
              
              if ($resultado['success']) {
                  $mensagem = 'Administrador criado com sucesso para o cliente!';
                  $tipoMensagem = 'success';
              } else {
                  $mensagem = $resultado['message'];
                  $tipoMensagem = 'danger';
              }
          }
      }
  }
}

// Processar alteração de status do cliente
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'status') {
    $clienteId = intval($_POST['cliente_id'] ?? 0);
    $acao = sanitizeInput($_POST['acao'] ?? '');
    $motivo = sanitizeInput($_POST['motivo'] ?? '');
    
    if ($clienteId <= 0) {
        $mensagem = 'Cliente não especificado.';
        $tipoMensagem = 'danger';
    } else {
        // Verificar se o cliente existe
        $sql = "SELECT id, nome FROM clientes WHERE id = ?";
        $cliente = fetchOne($sql, [$clienteId]);
        
        if (!$cliente) {
            $mensagem = 'Cliente não encontrado.';
            $tipoMensagem = 'danger';
        } else {
            $dadosStatus = [];
            
            if ($acao == 'bloquear') {
                $dadosStatus = [
                    'bloqueado' => true,
                    'motivo_bloqueio' => $motivo,
                    'data_bloqueio' => date('Y-m-d H:i:s')
                ];
                
                // Criar notificação
                $dadosNotificacao = [
                    'cliente_id' => $clienteId,
                    'titulo' => 'Conta Bloqueada',
                    'mensagem' => 'Sua conta foi bloqueada. Motivo: ' . $motivo,
                    'tipo' => 'alerta'
                ];
                
                insert('notificacoes', $dadosNotificacao);
                
                $mensagemAcao = 'bloqueado';
            } elseif ($acao == 'desbloquear') {
                $dadosStatus = [
                    'bloqueado' => false,
                    'motivo_bloqueio' => null,
                    'data_desbloqueio' => date('Y-m-d H:i:s')
                ];
                
                // Criar notificação
                $dadosNotificacao = [
                    'cliente_id' => $clienteId,
                    'titulo' => 'Conta Desbloqueada',
                    'mensagem' => 'Sua conta foi desbloqueada e está ativa novamente.',
                    'tipo' => 'info'
                ];
                
                insert('notificacoes', $dadosNotificacao);
                
                $mensagemAcao = 'desbloqueado';
            } elseif ($acao == 'desativar') {
                $dadosStatus = [
                    'ativo' => false
                ];
                
                $mensagemAcao = 'desativado';
            } elseif ($acao == 'ativar') {
                $dadosStatus = [
                    'ativo' => true
                ];
                
                $mensagemAcao = 'ativado';
            }
            
            if (!empty($dadosStatus)) {
                // Verificar se já existe um registro de status para este cliente
                $sql = "SELECT id FROM status_clientes WHERE cliente_id = ?";
                $statusExistente = fetchOne($sql, [$clienteId]);
                
                if ($statusExistente) {
                    $resultado = update('status_clientes', $dadosStatus, 'cliente_id = ?', [$clienteId]);
                } else {
                    $dadosStatus['cliente_id'] = $clienteId;
                    $resultado = insert('status_clientes', $dadosStatus);
                }
                
                if ($resultado) {
                    $mensagem = 'Cliente ' . $cliente['nome'] . ' foi ' . $mensagemAcao . ' com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = 'Erro ao alterar status do cliente.';
                    $tipoMensagem = 'danger';
                }
            }
        }
    }
}

// Processar registro de pagamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'financeiro') {
    $clienteId = intval($_POST['cliente_id'] ?? 0);
    $valor = floatval(str_replace(',', '.', $_POST['valor'] ?? 0));
    $dataVencimento = sanitizeInput($_POST['data_vencimento'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? '');
    $dataPagamento = sanitizeInput($_POST['data_pagamento'] ?? '');
    $metodoPagamento = sanitizeInput($_POST['metodo_pagamento'] ?? '');
    $observacoes = sanitizeInput($_POST['observacoes'] ?? '');
    
    if ($clienteId <= 0 || $valor <= 0 || empty($dataVencimento) || empty($status)) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'danger';
    } else {
        $dadosPagamento = [
            'cliente_id' => $clienteId,
            'valor' => $valor,
            'data_vencimento' => $dataVencimento,
            'status' => $status,
            'observacoes' => $observacoes
        ];
        
        if (!empty($dataPagamento) && $status == 'pago') {
            $dadosPagamento['data_pagamento'] = $dataPagamento;
            $dadosPagamento['metodo_pagamento'] = $metodoPagamento;
        }
        
        $pagamentoId = insert('pagamentos_clientes', $dadosPagamento);
        
        if ($pagamentoId) {
            $mensagem = 'Pagamento registrado com sucesso!';
            $tipoMensagem = 'success';
            
            // Se o pagamento foi registrado como pago, desbloquear o cliente se estiver bloqueado
            if ($status == 'pago') {
                $sql = "SELECT bloqueado FROM status_clientes WHERE cliente_id = ?";
                $statusCliente = fetchOne($sql, [$clienteId]);
                
                if ($statusCliente && $statusCliente['bloqueado']) {
                    $dadosStatus = [
                        'bloqueado' => false,
                        'data_desbloqueio' => date('Y-m-d H:i:s')
                    ];
                    
                    update('status_clientes', $dadosStatus, 'cliente_id = ?', [$clienteId]);
                    
                    // Criar notificação
                    $dadosNotificacao = [
                        'cliente_id' => $clienteId,
                        'titulo' => 'Pagamento Recebido',
                        'mensagem' => 'Recebemos seu pagamento de R$ ' . number_format($valor, 2, ',', '.') . '. Sua conta foi desbloqueada.',
                        'tipo' => 'info'
                    ];
                    
                    insert('notificacoes', $dadosNotificacao);
                }
            } elseif ($status == 'atrasado') {
                // Criar notificação de cobrança
                $dadosNotificacao = [
                    'cliente_id' => $clienteId,
                    'titulo' => 'Pagamento Atrasado',
                    'mensagem' => 'Você possui um pagamento atrasado no valor de R$ ' . number_format($valor, 2, ',', '.') . ' com vencimento em ' . date('d/m/Y', strtotime($dataVencimento)) . '. Por favor, regularize sua situação para evitar o bloqueio do sistema.',
                    'tipo' => 'cobranca'
                ];
                
                insert('notificacoes', $dadosNotificacao);
            }
        } else {
            $mensagem = 'Erro ao registrar pagamento.';
            $tipoMensagem = 'danger';
        }
    }
}

// Processar criação/edição de filial
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'filiais') {
    $filialId = intval($_POST['filial_id'] ?? 0);
    $clienteId = intval($_POST['cliente_id'] ?? 0);
    $nome = sanitizeInput($_POST['nome'] ?? '');
    $endereco = sanitizeInput($_POST['endereco'] ?? '');
    $telefone = sanitizeInput($_POST['telefone'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $responsavel = sanitizeInput($_POST['responsavel'] ?? '');
    $ativa = isset($_POST['ativa']) ? 1 : 0;
    
    if (empty($nome) || empty($endereco) || $clienteId <= 0) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'danger';
    } else {
        $dadosFilial = [
            'cliente_id' => $clienteId,
            'nome' => $nome,
            'endereco' => $endereco,
            'telefone' => $telefone,
            'email' => $email,
            'responsavel' => $responsavel,
            'ativa' => $ativa
        ];
        
        if ($filialId > 0) {
            // Editar filial existente
            $resultado = update('filiais', $dadosFilial, 'id = ?', [$filialId]);
            
            if ($resultado) {
                $mensagem = 'Filial atualizada com sucesso!';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao atualizar filial.';
                $tipoMensagem = 'danger';
            }
        } else {
            // Criar nova filial
            $filialId = insert('filiais', $dadosFilial);
            
            if ($filialId) {
                $mensagem = 'Filial criada com sucesso!';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao criar filial.';
                $tipoMensagem = 'danger';
            }
        }
    }
}

// Obter lista de clientes
$sql = "SELECT c.*, sc.ativo, sc.bloqueado, sc.motivo_bloqueio, sc.data_bloqueio 
        FROM clientes c 
        LEFT JOIN status_clientes sc ON c.id = sc.cliente_id 
        ORDER BY c.nome";
$clientes = fetchAll($sql);
?>

<div class="container-fluid py-4">
  <div class="row mb-4">
      <div class="col-12">
          <h2>Gerenciamento de Clientes/Empresas</h2>
          <p class="text-muted">Área de super administrador para gerenciar clientes do sistema.</p>
      </div>
  </div>
  
  <?php if (!empty($mensagem)): ?>
      <div class="alert alert-<?php echo $tipoMensagem; ?>" role="alert">
          <?php echo $mensagem; ?>
      </div>
  <?php endif; ?>
  
  <div class="row mb-4">
      <div class="col-12">
          <ul class="nav nav-tabs">
              <li class="nav-item">
                  <a class="nav-link <?php echo $subpage == 'clientes' ? 'active' : ''; ?>" href="?page=super_admin&subpage=clientes">
                      <i class="fas fa-building me-2"></i> Clientes/Empresas
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo $subpage == 'criar_admin' ? 'active' : ''; ?>" href="?page=super_admin&subpage=criar_admin">
                      <i class="fas fa-user-shield me-2"></i> Criar Administrador
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo $subpage == 'financeiro' ? 'active' : ''; ?>" href="?page=super_admin&subpage=financeiro">
                      <i class="fas fa-file-invoice-dollar me-2"></i> Financeiro
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo $subpage == 'filiais' ? 'active' : ''; ?>" href="?page=super_admin&subpage=filiais">
                      <i class="fas fa-code-branch me-2"></i> Filiais
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo $subpage == 'status' ? 'active' : ''; ?>" href="?page=super_admin&subpage=status">
                      <i class="fas fa-toggle-on me-2"></i> Status de Clientes
                  </a>
              </li>
          </ul>
      </div>
  </div>
  
  <div class="row">
      <div class="col-12">
          <?php if ($subpage == 'clientes'): ?>
              <!-- Gerenciamento de Clientes/Empresas -->
              <div class="card">
                  <div class="card-header bg-light d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Clientes/Empresas</h5>
                      <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalCliente">
                          <i class="fas fa-plus me-1"></i> Novo Cliente
                      </button>
                  </div>
                  <div class="card-body">
                      <div class="table-responsive">
                          <table class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>ID</th>
                                      <th>Nome</th>
                                      <th>Endereço</th>
                                      <th>Telefone</th>
                                      <th>Email</th>
                                      <th>Status</th>
                                      <th>Data de Cadastro</th>
                                      <th>Ações</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php foreach ($clientes as $cliente): ?>
                                      <tr>
                                          <td><?php echo $cliente['id']; ?></td>
                                          <td><?php echo $cliente['nome']; ?></td>
                                          <td><?php echo $cliente['endereco']; ?></td>
                                          <td><?php echo $cliente['telefone']; ?></td>
                                          <td><?php echo $cliente['email']; ?></td>
                                          <td>
                                              <?php
                                              if (isset($cliente['bloqueado']) && $cliente['bloqueado']) {
                                                  echo '<span class="badge bg-danger">Bloqueado</span>';
                                              } elseif (isset($cliente['ativo']) && !$cliente['ativo']) {
                                                  echo '<span class="badge bg-warning text-dark">Inativo</span>';
                                              } else {
                                                  echo '<span class="badge bg-success">Ativo</span>';
                                              }
                                              ?>
                                          </td>
                                          <td><?php echo formatDateTime($cliente['data_cadastro']); ?></td>
                                          <td>
                                              <div class="btn-group">
                                                  <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-cliente" 
                                                          data-id="<?php echo $cliente['id']; ?>"
                                                          data-nome="<?php echo $cliente['nome']; ?>"
                                                          data-endereco="<?php echo $cliente['endereco']; ?>"
                                                          data-telefone="<?php echo $cliente['telefone']; ?>"
                                                          data-email="<?php echo $cliente['email']; ?>"
                                                          data-logo="<?php echo $cliente['logo']; ?>">
                                                      <i class="fas fa-edit"></i>
                                                  </button>
                                                  <button type="button" class="btn btn-sm btn-outline-danger btn-excluir-cliente" 
                                                          data-id="<?php echo $cliente['id']; ?>"
                                                          data-nome="<?php echo $cliente['nome']; ?>">
                                                      <i class="fas fa-trash"></i>
                                                  </button>
                                                  <a href="?page=super_admin&subpage=criar_admin&cliente_id=<?php echo $cliente['id']; ?>" class="btn btn-sm btn-outline-success">
                                                      <i class="fas fa-user-plus"></i>
                                                  </a>
                                                  <button type="button" class="btn btn-sm btn-outline-info dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                      <i class="fas fa-cog"></i>
                                                  </button>
                                                  <ul class="dropdown-menu">
                                                      <li><a class="dropdown-item" href="?page=super_admin&subpage=financeiro&cliente_id=<?php echo $cliente['id']; ?>">
                                                          <i class="fas fa-file-invoice-dollar me-2"></i> Financeiro
                                                      </a></li>
                                                      <li><a class="dropdown-item" href="?page=super_admin&subpage=filiais&cliente_id=<?php echo $cliente['id']; ?>">
                                                          <i class="fas fa-code-branch me-2"></i> Filiais
                                                      </a></li>
                                                      <li><hr class="dropdown-divider"></li>
                                                      <?php if (isset($cliente['bloqueado']) && $cliente['bloqueado']): ?>
                                                          <li><a class="dropdown-item text-success btn-desbloquear-cliente" href="#" data-id="<?php echo $cliente['id']; ?>" data-nome="<?php echo $cliente['nome']; ?>">
                                                              <i class="fas fa-unlock me-2"></i> Desbloquear
                                                          </a></li>
                                                      <?php else: ?>
                                                          <li><a class="dropdown-item text-danger btn-bloquear-cliente" href="#" data-id="<?php echo $cliente['id']; ?>" data-nome="<?php echo $cliente['nome']; ?>">
                                                              <i class="fas fa-lock me-2"></i> Bloquear
                                                          </a></li>
                                                      <?php endif; ?>
                                                      
                                                      <?php if (isset($cliente['ativo']) && !$cliente['ativo']): ?>
                                                          <li><a class="dropdown-item text-primary btn-ativar-cliente" href="#" data-id="<?php echo $cliente['id']; ?>" data-nome="<?php echo $cliente['nome']; ?>">
                                                              <i class="fas fa-toggle-on me-2"></i> Ativar
                                                          </a></li>
                                                      <?php else: ?>
                                                          <li><a class="dropdown-item text-warning btn-desativar-cliente" href="#" data-id="<?php echo $cliente['id']; ?>" data-nome="<?php echo $cliente['nome']; ?>">
                                                              <i class="fas fa-toggle-off me-2"></i> Desativar
                                                          </a></li>
                                                      <?php endif; ?>
                                                  </ul>
                                              </div>
                                          </td>
                                      </tr>
                                  <?php endforeach; ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Cliente -->
              <div class="modal fade" id="modalCliente" tabindex="-1" aria-labelledby="modalClienteLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalClienteLabel">Novo Cliente</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="" enctype="multipart/form-data">
                              <div class="modal-body">
                                  <input type="hidden" id="cliente_id" name="cliente_id" value="0">
                                  
                                  <div class="mb-3">
                                      <label for="nome" class="form-label">Nome</label>
                                      <input type="text" class="form-control" id="nome" name="nome" required>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="endereco" class="form-label">Endereço</label>
                                      <input type="text" class="form-control" id="endereco" name="endereco">
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="telefone" class="form-label">Telefone</label>
                                      <input type="text" class="form-control" id="telefone" name="telefone">
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="email" class="form-label">Email</label>
                                      <input type="email" class="form-control" id="email" name="email">
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="logo" class="form-label">Logo</label>
                                      <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                                      <small class="form-text text-muted">Formatos aceitos: JPG, PNG, GIF. Tamanho máximo: 2MB.</small>
                                  </div>
                                  
                                  <div id="logoPreview" class="text-center mt-3" style="display: none;">
                                      <p>Logo atual:</p>
                                      <img src="/placeholder.svg" alt="Logo" class="img-thumbnail" style="max-height: 100px;">
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary">Salvar</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Exclusão de Cliente -->
              <div class="modal fade" id="modalExcluirCliente" tabindex="-1" aria-labelledby="modalExcluirClienteLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalExcluirClienteLabel">Confirmar Exclusão</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <div class="modal-body">
                              <p>Tem certeza que deseja excluir o cliente <strong id="nomeClienteExcluir"></strong>?</p>
                              <p class="text-danger">Esta ação não pode ser desfeita e excluirá todos os dados relacionados a este cliente, incluindo usuários, estacionamentos e registros.</p>
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                              <form method="POST" action="ajax/excluir_cliente.php" id="formExcluirCliente">
                                  <input type="hidden" id="excluir_cliente_id" name="cliente_id" value="0">
                                  <button type="submit" class="btn btn-danger">Excluir</button>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Bloqueio de Cliente -->
              <div class="modal fade" id="modalBloquearCliente" tabindex="-1" aria-labelledby="modalBloquearClienteLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalBloquearClienteLabel">Bloquear Cliente</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                  <input type="hidden" name="cliente_id" id="bloquear_cliente_id" value="0">
                                  <input type="hidden" name="acao" value="bloquear">
                                  
                                  <p>Você está prestes a bloquear o cliente <strong id="nomeClienteBloquear"></strong>.</p>
                                  <p>Isso impedirá o acesso ao sistema para todos os usuários deste cliente.</p>
                                  
                                  <div class="mb-3">
                                      <label for="motivo" class="form-label">Motivo do Bloqueio</label>
                                      <textarea class="form-control" id="motivo" name="motivo" rows="3" required></textarea>
                                      <small class="form-text text-muted">Este motivo será exibido para o cliente quando tentar acessar o sistema.</small>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-danger">Bloquear</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Desbloqueio de Cliente -->
              <div class="modal fade" id="modalDesbloquearCliente" tabindex="-1" aria-labelledby="modalDesbloquearClienteLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalDesbloquearClienteLabel">Desbloquear Cliente</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                  <input type="hidden" name="cliente_id" id="desbloquear_cliente_id" value="0">
                                  <input type="hidden" name="acao" value="desbloquear">
                                  
                                  <p>Você está prestes a desbloquear o cliente <strong id="nomeClienteDesbloquear"></strong>.</p>
                                  <p>Isso permitirá o acesso ao sistema para todos os usuários deste cliente novamente.</p>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-success">Desbloquear</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Ativação/Desativação de Cliente -->
              <div class="modal fade" id="modalStatusCliente" tabindex="-1" aria-labelledby="modalStatusClienteLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalStatusClienteLabel">Alterar Status do Cliente</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                  <input type="hidden" name="cliente_id" id="status_cliente_id" value="0">
                                  <input type="hidden" name="acao" id="status_acao" value="">
                                  
                                  <p id="status_mensagem"></p>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary" id="status_botao">Confirmar</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <script>
                  // Editar cliente
                  document.querySelectorAll('.btn-editar-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function() {
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          const endereco = this.getAttribute('data-endereco');
                          const telefone = this.getAttribute('data-telefone');
                          const email = this.getAttribute('data-email');
                          const logo = this.getAttribute('data-logo');
                          
                          document.getElementById('modalClienteLabel').textContent = 'Editar Cliente';
                          document.getElementById('cliente_id').value = id;
                          document.getElementById('nome').value = nome;
                          document.getElementById('endereco').value = endereco;
                          document.getElementById('telefone').value = telefone;
                          document.getElementById('email').value = email;
                          
                          // Exibir logo atual, se existir
                          const logoPreview = document.getElementById('logoPreview');
                          if (logo && logo !== 'null') {
                              logoPreview.style.display = 'block';
                              logoPreview.querySelector('img').src = logo;
                          } else {
                              logoPreview.style.display = 'none';
                          }
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalCliente'));
                          modal.show();
                      });
                  });
                  
                  // Novo cliente
                  document.querySelector('[data-bs-target="#modalCliente"]').addEventListener('click', function() {
                      document.getElementById('modalClienteLabel').textContent = 'Novo Cliente';
                      document.getElementById('cliente_id').value = '0';
                      document.getElementById('nome').value = '';
                      document.getElementById('endereco').value = '';
                      document.getElementById('telefone').value = '';
                      document.getElementById('email').value = '';
                      document.getElementById('logoPreview').style.display = 'none';
                  });
                  
                  // Excluir cliente
                  document.querySelectorAll('.btn-excluir-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function() {
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          
                          document.getElementById('nomeClienteExcluir').textContent = nome;
                          document.getElementById('excluir_cliente_id').value = id;
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalExcluirCliente'));
                          modal.show();
                      });
                  });
                  
                  // Bloquear cliente
                  document.querySelectorAll('.btn-bloquear-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function(e) {
                          e.preventDefault();
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          
                          document.getElementById('nomeClienteBloquear').textContent = nome;
                          document.getElementById('bloquear_cliente_id').value = id;
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalBloquearCliente'));
                          modal.show();
                      });
                  });
                  
                  // Desbloquear cliente
                  document.querySelectorAll('.btn-desbloquear-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function(e) {
                          e.preventDefault();
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          
                          document.getElementById('nomeClienteDesbloquear').textContent = nome;
                          document.getElementById('desbloquear_cliente_id').value = id;
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalDesbloquearCliente'));
                          modal.show();
                      });
                  });
                  
                  // Ativar cliente
                  document.querySelectorAll('.btn-ativar-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function(e) {
                          e.preventDefault();
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          
                          document.getElementById('status_cliente_id').value = id;
                          document.getElementById('status_acao').value = 'ativar';
                          document.getElementById('status_mensagem').textContent = `Você está prestes a ativar o cliente ${nome}. Isso permitirá que o cliente utilize o sistema normalmente.`;
                          document.getElementById('status_botao').className = 'btn btn-success';
                          document.getElementById('status_botao').textContent = 'Ativar';
                          document.getElementById('modalStatusClienteLabel').textContent = 'Ativar Cliente';
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalStatusCliente'));
                          modal.show();
                      });
                  });
                  
                  // Desativar cliente
                  document.querySelectorAll('.btn-desativar-cliente').forEach(function(btn) {
                      btn.addEventListener('click', function(e) {
                          e.preventDefault();
                          const id = this.getAttribute('data-id');
                          const nome = this.getAttribute('data-nome');
                          
                          document.getElementById('status_cliente_id').value = id;
                          document.getElementById('status_acao').value = 'desativar';
                          document.getElementById('status_mensagem').textContent = `Você está prestes a desativar o cliente ${nome}. Isso impedirá que o cliente utilize o sistema até que seja ativado novamente.`;
                          document.getElementById('status_botao').className = 'btn btn-warning';
                          document.getElementById('status_botao').textContent = 'Desativar';
                          document.getElementById('modalStatusClienteLabel').textContent = 'Desativar Cliente';
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalStatusCliente'));
                          modal.show();
                      });
                  });
              </script>
          <?php elseif ($subpage == 'criar_admin'): ?>
              <!-- Criar Administrador para Cliente -->
              <div class="card">
                  <div class="card-header bg-light">
                      <h5 class="mb-0">Criar Administrador para Cliente</h5>
                  </div>
                  <div class="card-body">
                      <form method="POST" action="">
                          <div class="mb-3">
                              <label for="cliente_id" class="form-label">Cliente</label>
                              <select class="form-select" id="cliente_id" name="cliente_id" required>
                                  <option value="">Selecione um cliente...</option>
                                  <?php foreach ($clientes as $cliente): ?>
                                      <option value="<?php echo $cliente['id']; ?>" <?php echo (isset($_GET['cliente_id']) && $_GET['cliente_id'] == $cliente['id']) ? 'selected' : ''; ?>>
                                          <?php echo $cliente['nome']; ?>
                                      </option>
                                  <?php endforeach; ?>
                              </select>
                          </div>
                          
                          <div class="mb-3">
                              <label for="nome" class="form-label">Nome do Administrador</label>
                              <input type="text" class="form-control" id="nome" name="nome" required>
                          </div>
                          
                          <div class="mb-3">
                              <label for="email" class="form-label">Email</label>
                              <input type="email" class="form-control" id="email" name="email" required>
                          </div>
                          
                          <div class="mb-3">
                              <label for="senha" class="form-label">Senha</label>
                              <input type="password" class="form-control" id="senha" name="senha" required>
                          </div>
                          
                          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                              <button type="submit" class="btn btn-primary">
                                  <i class="fas fa-user-plus me-2"></i> Criar Administrador
                              </button>
                          </div>
                      </form>
                  </div>
              </div>
              
              <!-- Lista de Administradores Existentes -->
              <div class="card mt-4">
                  <div class="card-header bg-light">
                      <h5 class="mb-0">Administradores Existentes</h5>
                  </div>
                  <div class="card-body">
                      <div class="table-responsive">
                          <table class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>Nome</th>
                                      <th>Email</th>
                                      <th>Cliente</th>
                                      <th>Data de Criação</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php
                                  $sql = "SELECT u.id, u.nome, u.email, u.data_criacao, c.nome as cliente_nome 
                                          FROM usuarios u 
                                          JOIN clientes c ON u.cliente_id = c.id 
                                          WHERE u.tipo_acesso = 'admin' 
                                          ORDER BY c.nome, u.nome";
                                  $admins = fetchAll($sql);
                                  
                                  foreach ($admins as $admin):
                                  ?>
                                      <tr>
                                          <td><?php echo $admin['nome']; ?></td>
                                          <td><?php echo $admin['email']; ?></td>
                                          <td><?php echo $admin['cliente_nome']; ?></td>
                                          <td><?php echo formatDateTime($admin['data_criacao']); ?></td>
                                      </tr>
                                  <?php endforeach; ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          <?php elseif ($subpage == 'financeiro'): ?>
              <!-- Gerenciamento Financeiro -->
              <div class="card">
                  <div class="card-header bg-light d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Gerenciamento Financeiro</h5>
                      <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalPagamento">
                          <i class="fas fa-plus me-1"></i> Novo Pagamento
                      </button>
                  </div>
                  <div class="card-body">
                      <?php
                      // Filtrar por cliente específico se fornecido
                      $clienteIdFiltro = isset($_GET['cliente_id']) ? intval($_GET['cliente_id']) : 0;
                      $filtroCliente = $clienteIdFiltro > 0 ? "WHERE p.cliente_id = $clienteIdFiltro" : "";
                      
                      // Obter pagamentos
                      $sql = "SELECT p.*, c.nome as cliente_nome 
                              FROM pagamentos_clientes p 
                              JOIN clientes c ON p.cliente_id = c.id 
                              $filtroCliente
                              ORDER BY p.data_vencimento DESC";
                      $pagamentos = fetchAll($sql);
                      
                      if ($clienteIdFiltro > 0) {
                          $clienteNome = '';
                          foreach ($clientes as $cliente) {
                              if ($cliente['id'] == $clienteIdFiltro) {
                                  $clienteNome = $cliente['nome'];
                                  break;
                              }
                          }
                          echo "<div class='alert alert-info'>Exibindo pagamentos do cliente: <strong>$clienteNome</strong> <a href='?page=super_admin&subpage=financeiro' class='btn btn-sm btn-outline-dark ms-2'>Limpar filtro</a></div>";
                      }
                      ?>
                      
                      <div class="table-responsive">
                          <table class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>Cliente</th>
                                      <th>Valor</th>
                                      <th>Vencimento</th>
                                      <th>Status</th>
                                      <th>Data Pagamento</th>
                                      <th>Método</th>
                                      <th>Observações</th>
                                      <th>Ações</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php if (empty($pagamentos)): ?>
                                      <tr>
                                          <td colspan="8" class="text-center">Nenhum pagamento registrado.</td>
                                      </tr>
                                  <?php else: ?>
                                      <?php foreach ($pagamentos as $pagamento): ?>
                                          <tr>
                                              <td><?php echo $pagamento['cliente_nome']; ?></td>
                                              <td>R$ <?php echo number_format($pagamento['valor'], 2, ',', '.'); ?></td>
                                              <td><?php echo date('d/m/Y', strtotime($pagamento['data_vencimento'])); ?></td>
                                              <td>
                                                  <?php
                                                  $statusClass = 'bg-secondary';
                                                  $statusText = 'Desconhecido';
                                                  
                                                  switch ($pagamento['status']) {
                                                      case 'pendente':
                                                          $statusClass = 'bg-warning text-dark';
                                                          $statusText = 'Pendente';
                                                          break;
                                                      case 'pago':
                                                          $statusClass = 'bg-success';
                                                          $statusText = 'Pago';
                                                          break;
                                                      case 'atrasado':
                                                          $statusClass = 'bg-danger';
                                                          $statusText = 'Atrasado';
                                                          break;
                                                      case 'cancelado':
                                                          $statusClass = 'bg-secondary';
                                                          $statusText = 'Cancelado';
                                                          break;
                                                  }
                                                  ?>
                                                  <span class="badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                                              </td>
                                              <td><?php echo $pagamento['data_pagamento'] ? date('d/m/Y', strtotime($pagamento['data_pagamento'])) : '-'; ?></td>
                                              <td><?php echo $pagamento['metodo_pagamento'] ?? '-'; ?></td>
                                              <td><?php echo $pagamento['observacoes'] ? '<i class="fas fa-info-circle" title="' . htmlspecialchars($pagamento['observacoes']) . '"></i>' : '-'; ?></td>
                                              <td>
                                                  <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-pagamento" 
                                                          data-id="<?php echo $pagamento['id']; ?>"
                                                          data-cliente="<?php echo $pagamento['cliente_id']; ?>"
                                                          data-valor="<?php echo $pagamento['valor']; ?>"
                                                          data-vencimento="<?php echo $pagamento['data_vencimento']; ?>"
                                                          data-status="<?php echo $pagamento['status']; ?>"
                                                          data-pagamento="<?php echo $pagamento['data_pagamento'] ?? ''; ?>"
                                                          data-metodo="<?php echo $pagamento['metodo_pagamento'] ?? ''; ?>"
                                                          data-obs="<?php echo htmlspecialchars($pagamento['observacoes'] ?? ''); ?>">
                                                      <i class="fas fa-edit"></i>
                                                  </button>
                                                  <?php if ($pagamento['status'] == 'pendente' || $pagamento['status'] == 'atrasado'): ?>
                                                      <button type="button" class="btn btn-sm btn-outline-success me-1 btn-registrar-pagamento" 
                                                              data-id="<?php echo $pagamento['id']; ?>"
                                                              data-cliente="<?php echo $pagamento['cliente_nome']; ?>"
                                                              data-valor="<?php echo $pagamento['valor']; ?>">
                                                          <i class="fas fa-check"></i>
                                                      </button>
                                                  <?php endif; ?>
                                              </td>
                                          </tr>
                                      <?php endforeach; ?>
                                  <?php endif; ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Pagamento -->
              <div class="modal fade" id="modalPagamento" tabindex="-1" aria-labelledby="modalPagamentoLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalPagamentoLabel">Novo Pagamento</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                  <input type="hidden" id="pagamento_id" name="pagamento_id" value="0">
                                  
                                  <div class="mb-3">
                                      <label for="cliente_id_pagamento" class="form-label">Cliente</label>
                                      <select class="form-select" id="cliente_id_pagamento" name="cliente_id" required>
                                          <option value="">Selecione um cliente...</option>
                                          <?php foreach ($clientes as $cliente): ?>
                                              <option value="<?php echo $cliente['id']; ?>" <?php echo (isset($_GET['cliente_id']) && $_GET['cliente_id'] == $cliente['id']) ? 'selected' : ''; ?>>
                                                  <?php echo $cliente['nome']; ?>
                                              </option>
                                          <?php endforeach; ?>
                                      </select>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="valor" class="form-label">Valor</label>
                                      <div class="input-group">
                                          <span class="input-group-text">R$</span>
                                          <input type="text" class="form-control" id="valor" name="valor" placeholder="0,00" required>
                                      </div>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="data_vencimento" class="form-label">Data de Vencimento</label>
                                      <input type="date" class="form-control" id="data_vencimento" name="data_vencimento" required>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="status" class="form-label">Status</label>
                                      <select class="form-select" id="status" name="status" required>
                                          <option value="pendente">Pendente</option>
                                          <option value="pago">Pago</option>
                                          <option value="atrasado">Atrasado</option>
                                          <option value="cancelado">Cancelado</option>
                                      </select>
                                  </div>
                                  
                                  <div id="divPagamento" style="display: none;">
                                      <div class="mb-3">
                                          <label for="data_pagamento" class="form-label">Data de Pagamento</label>
                                          <input type="date" class="form-control" id="data_pagamento" name="data_pagamento">
                                      </div>
                                      
                                      <div class="mb-3">
                                          <label for="metodo_pagamento" class="form-label">Método de Pagamento</label>
                                          <select class="form-select" id="metodo_pagamento" name="metodo_pagamento">
                                              <option value="">Selecione...</option>
                                              <option value="boleto">Boleto</option>
                                              <option value="pix">PIX</option>
                                              <option value="cartao">Cartão de Crédito</option>
                                              <option value="transferencia">Transferência Bancária</option>
                                              <option value="dinheiro">Dinheiro</option>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="observacoes" class="form-label">Observações</label>
                                      <textarea class="form-control" id="observacoes" name="observacoes" rows="3"></textarea>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary">Salvar</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Registro de Pagamento -->
              <div class="modal fade" id="modalRegistrarPagamento" tabindex="-1" aria-labelledby="modalRegistrarPagamentoLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalRegistrarPagamentoLabel">Registrar Pagamento</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="ajax/registrar_pagamento.php">
                              <div class="modal-body">
                                  <input type="hidden" id="registrar_pagamento_id" name="pagamento_id" value="0">
                                  
                                  <p>  value="0">
                                  
                                  <p>Você está registrando o pagamento para o cliente <strong id="registrar_cliente_nome"></strong>.</p>
                                  <p>Valor: <strong id="registrar_valor"></strong></p>
                                  
                                  <div class="mb-3">
                                      <label for="registrar_data_pagamento" class="form-label">Data de Pagamento</label>
                                      <input type="date" class="form-control" id="registrar_data_pagamento" name="data_pagamento" value="<?php echo date('Y-m-d'); ?>" required>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="registrar_metodo_pagamento" class="form-label">Método de Pagamento</label>
                                      <select class="form-select" id="registrar_metodo_pagamento" name="metodo_pagamento" required>
                                          <option value="">Selecione...</option>
                                          <option value="boleto">Boleto</option>
                                          <option value="pix">PIX</option>
                                          <option value="cartao">Cartão de Crédito</option>
                                          <option value="transferencia">Transferência Bancária</option>
                                          <option value="dinheiro">Dinheiro</option>
                                      </select>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="registrar_observacoes" class="form-label">Observações</label>
                                      <textarea class="form-control" id="registrar_observacoes" name="observacoes" rows="2"></textarea>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-success">Confirmar Pagamento</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <script>
                  // Formatar valor
                  document.getElementById('valor').addEventListener('blur', function(e) {
                      const valor = parseFloat(e.target.value.replace('.', '').replace(',', '.'));
                      
                      if (!isNaN(valor)) {
                          e.target.value = valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                      }
                  });
                  
                  // Controlar exibição dos campos de pagamento
                  document.getElementById('status').addEventListener('change', function() {
                      const status = this.value;
                      const divPagamento = document.getElementById('divPagamento');
                      
                      if (status === 'pago') {
                          divPagamento.style.display = 'block';
                          document.getElementById('data_pagamento').required = true;
                          document.getElementById('metodo_pagamento').required = true;
                      } else {
                          divPagamento.style.display = 'none';
                          document.getElementById('data_pagamento').required = false;
                          document.getElementById('metodo_pagamento').required = false;
                      }
                  });
                  
                  // Novo pagamento
                  document.querySelector('[data-bs-target="#modalPagamento"]').addEventListener('click', function() {
                      document.getElementById('modalPagamentoLabel').textContent = 'Novo Pagamento';
                      document.getElementById('pagamento_id').value = '0';
                      document.getElementById('cliente_id_pagamento').value = '<?php echo $clienteIdFiltro; ?>';
                      document.getElementById('valor').value = '';
                      document.getElementById('data_vencimento').value = '';
                      document.getElementById('status').value = 'pendente';
                      document.getElementById('data_pagamento').value = '';
                      document.getElementById('metodo_pagamento').value = '';
                      document.getElementById('observacoes').value = '';
                      document.getElementById('divPagamento').style.display = 'none';
                  });
                  
                  // Registrar pagamento
                  document.querySelectorAll('.btn-registrar-pagamento').forEach(function(btn) {
                      btn.addEventListener('click', function() {
                          const id = this.getAttribute('data-id');
                          const cliente = this.getAttribute('data-cliente');
                          const valor = parseFloat(this.getAttribute('data-valor')).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                          
                          document.getElementById('registrar_pagamento_id').value = id;
                          document.getElementById('registrar_cliente_nome').textContent = cliente;
                          document.getElementById('registrar_valor').textContent = valor;
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalRegistrarPagamento'));
                          modal.show();
                      });
                  });
              </script>
          <?php elseif ($subpage == 'filiais'): ?>
              <!-- Gerenciamento de Filiais -->
              <div class="card">
                  <div class="card-header bg-light d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Gerenciamento de Filiais</h5>
                      <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalFilial">
                          <i class="fas fa-plus me-1"></i> Nova Filial
                      </button>
                  </div>
                  <div class="card-body">
                      <?php
                      // Filtrar por cliente específico se fornecido
                      $clienteIdFiltro = isset($_GET['cliente_id']) ? intval($_GET['cliente_id']) : 0;
                      $filtroCliente = $clienteIdFiltro > 0 ? "WHERE f.cliente_id = $clienteIdFiltro" : "";
                      
                      // Obter filiais
                      $sql = "SELECT f.*, c.nome as cliente_nome, 
                                    (SELECT COUNT(*) FROM estacionamentos e WHERE e.filial_id = f.id) as total_estacionamentos
                              FROM filiais f 
                              JOIN clientes c ON f.cliente_id = c.id 
                              $filtroCliente
                              ORDER BY c.nome, f.nome";
                      $filiais = fetchAll($sql);
                      
                      if ($clienteIdFiltro > 0) {
                          $clienteNome = '';
                          foreach ($clientes as $cliente) {
                              if ($cliente['id'] == $clienteIdFiltro) {
                                  $clienteNome = $cliente['nome'];
                                  break;
                              }
                          }
                          echo "<div class='alert alert-info'>Exibindo filiais do cliente: <strong>$clienteNome</strong> <a href='?page=super_admin&subpage=filiais' class='btn btn-sm btn-outline-dark ms-2'>Limpar filtro</a></div>";
                      }
                      ?>
                      
                      <div class="table-responsive">
                          <table class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>Cliente</th>
                                      <th>Nome da Filial</th>
                                      <th>Endereço</th>
                                      <th>Responsável</th>
                                      <th>Contato</th>
                                      <th>Estacionamentos</th>
                                      <th>Status</th>
                                      <th>Ações</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php if (empty($filiais)): ?>
                                      <tr>
                                          <td colspan="8" class="text-center">Nenhuma filial cadastrada.</td>
                                      </tr>
                                  <?php else: ?>
                                      <?php foreach ($filiais as $filial): ?>
                                          <tr>
                                              <td><?php echo $filial['cliente_nome']; ?></td>
                                              <td><?php echo $filial['nome']; ?></td>
                                              <td><?php echo $filial['endereco']; ?></td>
                                              <td><?php echo $filial['responsavel'] ?? '-'; ?></td>
                                              <td>
                                                  <?php if (!empty($filial['telefone']) || !empty($filial['email'])): ?>
                                                      <?php echo $filial['telefone'] ?? ''; ?>
                                                      <?php if (!empty($filial['telefone']) && !empty($filial['email'])): ?>
                                                          <br>
                                                      <?php endif; ?>
                                                      <?php echo $filial['email'] ?? ''; ?>
                                                  <?php else: ?>
                                                      -
                                                  <?php endif; ?>
                                              </td>
                                              <td>
                                                  <span class="badge bg-info"><?php echo $filial['total_estacionamentos']; ?></span>
                                                  <?php if ($filial['total_estacionamentos'] > 0): ?>
                                                      <a href="?page=super_admin&subpage=estacionamentos&filial_id=<?php echo $filial['id']; ?>" class="btn btn-sm btn-link p-0 ms-1">
                                                          <i class="fas fa-eye"></i>
                                                      </a>
                                                  <?php endif; ?>
                                              </td>
                                              <td>
                                                  <?php if ($filial['ativa']): ?>
                                                      <span class="badge bg-success">Ativa</span>
                                                  <?php else: ?>
                                                      <span class="badge bg-danger">Inativa</span>
                                                  <?php endif; ?>
                                              </td>
                                              <td>
                                                  <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-filial" 
                                                          data-id="<?php echo $filial['id']; ?>"
                                                          data-cliente="<?php echo $filial['cliente_id']; ?>"
                                                          data-nome="<?php echo $filial['nome']; ?>"
                                                          data-endereco="<?php echo $filial['endereco']; ?>"
                                                          data-telefone="<?php echo $filial['telefone'] ?? ''; ?>"
                                                          data-email="<?php echo $filial['email'] ?? ''; ?>"
                                                          data-responsavel="<?php echo $filial['responsavel'] ?? ''; ?>"
                                                          data-ativa="<?php echo $filial['ativa']; ?>">
                                                      <i class="fas fa-edit"></i>
                                                  </button>
                                              </td>
                                          </tr>
                                      <?php endforeach; ?>
                                  <?php endif; ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Filial -->
              <div class="modal fade" id="modalFilial" tabindex="-1" aria-labelledby="modalFilialLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalFilialLabel">Nova Filial</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                  <input type="hidden" id="filial_id" name="filial_id" value="0">
                                  
                                  <div class="mb-3">
                                      <label for="cliente_id_filial" class="form-label">Cliente</label>
                                      <select class="form-select" id="cliente_id_filial" name="cliente_id" required>
                                          <option value="">Selecione um cliente...</option>
                                          <?php foreach ($clientes as $cliente): ?>
                                              <option value="<?php echo $cliente['id']; ?>" <?php echo (isset($_GET['cliente_id']) && $_GET['cliente_id'] == $cliente['id']) ? 'selected' : ''; ?>>
                                                  <?php echo $cliente['nome']; ?>
                                              </option>
                                          <?php endforeach; ?>
                                      </select>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="nome_filial" class="form-label">Nome da Filial</label>
                                      <input type="text" class="form-control" id="nome_filial" name="nome" required>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="endereco_filial" class="form-label">Endereço</label>
                                      <input type="text" class="form-control" id="endereco_filial" name="endereco" required>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="telefone_filial" class="form-label">Telefone</label>
                                      <input type="text" class="form-control" id="telefone_filial" name="telefone">
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="email_filial" class="form-label">Email</label>
                                      <input type="email" class="form-control" id="email_filial" name="email">
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="responsavel_filial" class="form-label">Responsável</label>
                                      <input type="text" class="form-control" id="responsavel_filial" name="responsavel">
                                  </div>
                                  
                                  <div class="form-check mb-3">
                                      <input class="form-check-input" type="checkbox" id="ativa_filial" name="ativa" checked>
                                      <label class="form-check-label" for="ativa_filial">
                                          Filial ativa
                                      </label>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary">Salvar</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <script>
                  // Novo filial
                  document.querySelector('[data-bs-target="#modalFilial"]').addEventListener('click', function() {
                      document.getElementById('modalFilialLabel').textContent = 'Nova Filial';
                      document.getElementById('filial_id').value = '0';
                      document.getElementById('cliente_id_filial').value = '<?php echo $clienteIdFiltro; ?>';
                      document.getElementById('nome_filial').value = '';
                      document.getElementById('endereco_filial').value = '';
                      document.getElementById('telefone_filial').value = '';
                      document.getElementById('email_filial').value = '';
                      document.getElementById('responsavel_filial').value = '';
                      document.getElementById('ativa_filial').checked = true;
                  });
                  
                  // Editar filial
                  document.querySelectorAll('.btn-editar-filial').forEach(function(btn) {
                      btn.addEventListener('click', function() {
                          const id = this.getAttribute('data-id');
                          const cliente = this.getAttribute('data-cliente');
                          const nome = this.getAttribute('data-nome');
                          const endereco = this.getAttribute('data-endereco');
                          const telefone = this.getAttribute('data-telefone');
                          const email = this.getAttribute('data-email');
                          const responsavel = this.getAttribute('data-responsavel');
                          const ativa = this.getAttribute('data-ativa') === '1';
                          
                          document.getElementById('modalFilialLabel').textContent = 'Editar Filial';
                          document.getElementById('filial_id').value = id;
                          document.getElementById('cliente_id_filial').value = cliente;
                          document.getElementById('nome_filial').value = nome;
                          document.getElementById('endereco_filial').value = endereco;
                          document.getElementById('telefone_filial').value = telefone;
                          document.getElementById('email_filial').value = email;
                          document.getElementById('responsavel_filial').value = responsavel;
                          document.getElementById('ativa_filial').checked = ativa;
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalFilial'));
                          modal.show();
                      });
                  });
              </script>
          <?php elseif ($subpage == 'status'): ?>
              <!-- Status de Clientes -->
              <div class="card">
                  <div class="card-header bg-light">
                      <h5 class="mb-0">Status de Clientes</h5>
                  </div>
                  <div class="card-body">
                      <div class="table-responsive">
                          <table class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>Cliente</th>
                                      <th>Status</th>
                                      <th>Bloqueado</th>
                                      <th>Motivo do Bloqueio</th>
                                      <th>Data do Bloqueio</th>
                                      <th>Data do Desbloqueio</th>
                                      <th>Dias de Graça</th>
                                      <th>Ações</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php
                                  $sql = "SELECT sc.*, c.nome as cliente_nome 
                                          FROM status_clientes sc 
                                          JOIN clientes c ON sc.cliente_id = c.id 
                                          ORDER BY c.nome";
                                  $statusClientes = fetchAll($sql);
                                  
                                  if (empty($statusClientes)):
                                  ?>
                                      <tr>
                                          <td colspan="8" class="text-center">Nenhum status de cliente cadastrado.</td>
                                      </tr>
                                  <?php else: ?>
                                      <?php foreach ($statusClientes as $status): ?>
                                          <tr>
                                              <td><?php echo $status['cliente_nome']; ?></td>
                                              <td>
                                                  <?php if ($status['ativo']): ?>
                                                      <span class="badge bg-success">Ativo</span>
                                                  <?php else: ?>
                                                      <span class="badge bg-danger">Inativo</span>
                                                  <?php endif; ?>
                                              </td>
                                              <td>
                                                  <?php if ($status['bloqueado']): ?>
                                                      <span class="badge bg-danger">Sim</span>
                                                  <?php else: ?>
                                                      <span class="badge bg-success">Não</span>
                                                  <?php endif; ?>
                                              </td>
                                              <td><?php echo $status['motivo_bloqueio'] ?? '-'; ?></td>
                                              <td><?php echo $status['data_bloqueio'] ? date('d/m/Y H:i', strtotime($status['data_bloqueio'])) : '-'; ?></td>
                                              <td><?php echo $status['data_desbloqueio'] ? date('d/m/Y H:i', strtotime($status['data_desbloqueio'])) : '-'; ?></td>
                                              <td><?php echo $status['dias_graca']; ?></td>
                                              <td>
                                                  <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-status" 
                                                          data-id="<?php echo $status['id']; ?>"
                                                          data-cliente="<?php echo $status['cliente_id']; ?>"
                                                          data-cliente-nome="<?php echo $status['cliente_nome']; ?>"
                                                          data-ativo="<?php echo $status['ativo']; ?>"
                                                          data-bloqueado="<?php echo $status['bloqueado']; ?>"
                                                          data-dias-graca="<?php echo $status['dias_graca']; ?>">
                                                      <i class="fas fa-edit"></i>
                                                  </button>
                                              </td>
                                          </tr>
                                      <?php endforeach; ?>
                                  <?php endif; ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
              
              <!-- Modal de Edição de Status -->
              <div class="modal fade" id="modalEditarStatus" tabindex="-1" aria-labelledby="modalEditarStatusLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="modalEditarStatusLabel">Editar Status do Cliente</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                          </div>
                          <form method="POST" action="ajax/editar_status_cliente.php">
                              <div class="modal-body">
                                  <input type="hidden" id="status_id" name="status_id" value="0">
                                  <input type="hidden" id="status_cliente_id_edit" name="cliente_id" value="0">
                                  
                                  <p>Editando status do cliente: <strong id="status_cliente_nome"></strong></p>
                                  
                                  <div class="form-check mb-3">
                                      <input class="form-check-input" type="checkbox" id="status_ativo" name="ativo">
                                      <label class="form-check-label" for="status_ativo">
                                          Cliente ativo
                                      </label>
                                  </div>
                                  
                                  <div class="form-check mb-3">
                                      <input class="form-check-input" type="checkbox" id="status_bloqueado" name="bloqueado">
                                      <label class="form-check-label" for="status_bloqueado">
                                          Cliente bloqueado
                                      </label>
                                  </div>
                                  
                                  <div class="mb-3" id="div_motivo_bloqueio" style="display: none;">
                                      <label for="status_motivo_bloqueio" class="form-label">Motivo do Bloqueio</label>
                                      <textarea class="form-control" id="status_motivo_bloqueio" name="motivo_bloqueio" rows="3"></textarea>
                                  </div>
                                  
                                  <div class="mb-3">
                                      <label for="status_dias_graca" class="form-label">Dias de Graça</label>
                                      <input type="number" class="form-control" id="status_dias_graca" name="dias_graca" min="0" value="5" required>
                                      <small class="form-text text-muted">Número de dias após o vencimento antes de bloquear o acesso.</small>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary">Salvar</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
              
              <script>
                  // Controlar exibição do campo de motivo de bloqueio
                  document.getElementById('status_bloqueado').addEventListener('change', function() {
                      const divMotivoBloqueio = document.getElementById('div_motivo_bloqueio');
                      
                      if (this.checked) {
                          divMotivoBloqueio.style.display = 'block';
                          document.getElementById('status_motivo_bloqueio').required = true;
                      } else {
                          divMotivoBloqueio.style.display = 'none';
                          document.getElementById('status_motivo_bloqueio').required = false;
                      }
                  });
                  
                  // Editar status
                  document.querySelectorAll('.btn-editar-status').forEach(function(btn) {
                      btn.addEventListener('click', function() {
                          const id = this.getAttribute('data-id');
                          const cliente = this.getAttribute('data-cliente');
                          const clienteNome = this.getAttribute('data-cliente-nome');
                          const ativo = this.getAttribute('data-ativo') === '1';
                          const bloqueado = this.getAttribute('data-bloqueado') === '1';
                          const diasGraca = this.getAttribute('data-dias-graca');
                          
                          document.getElementById('status_id').value = id;
                          document.getElementById('status_cliente_id_edit').value = cliente;
                          document.getElementById('status_cliente_nome').textContent = clienteNome;
                          document.getElementById('status_ativo').checked = ativo;
                          document.getElementById('status_bloqueado').checked = bloqueado;
                          document.getElementById('status_dias_graca').value = diasGraca;
                          
                          // Controlar exibição do campo de motivo de bloqueio
                          const divMotivoBloqueio = document.getElementById('div_motivo_bloqueio');
                          if (bloqueado) {
                              divMotivoBloqueio.style.display = 'block';
                              // Carregar o motivo do bloqueio via AJAX
                              fetch('ajax/get_motivo_bloqueio.php?cliente_id=' + cliente)
                                  .then(response => response.json())
                                  .then(data => {
                                      document.getElementById('status_motivo_bloqueio').value = data.motivo || '';
                                  });
                          } else {
                              divMotivoBloqueio.style.display = 'none';
                          }
                          
                          const modal = new bootstrap.Modal(document.getElementById('modalEditarStatus'));
                          modal.show();
                      });
                  });
              </script>
          <?php endif; ?>
      </div>
  </div>
</div>

