<?php
// Obter ID do registro
$registroId = intval($_GET['id'] ?? 0);

if ($registroId <= 0) {
    echo '<div class="alert alert-danger">Registro não encontrado.</div>';
    exit;
}

// Obter dados do registro
$sql = "SELECT 
            r.*, 
            v.modelo, 
            v.cor, 
            v.placa, 
            v.proprietario, 
            v.documento,
            s.tipo AS servico_tipo,
            s.valor AS servico_valor,
            e.nome AS estacionamento_nome
        FROM 
            registros r
        JOIN 
            veiculos v ON r.veiculo_id = v.id
        JOIN 
            servicos s ON r.servico_id = s.id
        JOIN
            estacionamentos e ON r.estacionamento_id = e.id
        WHERE 
            r.id = ?";

$registro = fetchOne($sql, [$registroId]);

if (!$registro) {
    echo '<div class="alert alert-danger">Registro não encontrado.</div>';
    exit;
}

// Verificar se o veículo já saiu
if ($registro['data_saida'] !== null) {
    echo '<div class="alert alert-warning">Este veículo já saiu do estacionamento.</div>';
    echo '<p><a href="?page=dashboard" class="btn btn-primary">Voltar ao Dashboard</a></p>';
    exit;
}

// Calcular tempo de permanência
$duracao = calculateDuration($registro['data_entrada']);
$duracaoFormatada = $duracao['hours'] . 'h ' . $duracao['minutes'] . 'min';

// Calcular valor a pagar
$valorPagar = 0;
$dataSaida = date('Y-m-d H:i:s');

if ($registro['servico_tipo'] != 'mensalista') {
    $valorPagar = calculatePayment(
        $registro['data_entrada'], 
        $dataSaida, 
        $registro['servico_tipo'], 
        $registro['estacionamento_id']
    );
}

// Processar pagamento
$mensagem = '';
$tipoMensagem = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $formaPagamento = sanitizeInput($_POST['forma_pagamento'] ?? '');
    $valorPago = floatval(str_replace(',', '.', $_POST['valor_pago'] ?? 0));
    
    if (empty($formaPagamento)) {
        $mensagem = 'Selecione uma forma de pagamento.';
        $tipoMensagem = 'danger';
    } elseif ($valorPago < $valorPagar && $registro['servico_tipo'] != 'mensalista') {
        $mensagem = 'O valor pago não pode ser menor que o valor a pagar.';
        $tipoMensagem = 'danger';
    } else {
        // Registrar saída
        $dadosSaida = [
            'data_saida' => $dataSaida,
            'valor_pago' => $valorPagar,
            'forma_pagamento' => $formaPagamento,
            'usuario_saida_id' => $_SESSION['user_id']
        ];
        
        $resultado = update('registros', $dadosSaida, 'id = ?', [$registroId]);
        
        if ($resultado) {
            // Registrar atividade
            logActivity($_SESSION['user_id'], 'saida_veiculo', 'Registro de saída do veículo ' . $registro['placa']);
            
            $mensagem = 'Saída registrada com sucesso!';
            $tipoMensagem = 'success';
            
            // Redirecionar para o dashboard após 2 segundos
            echo '<meta http-equiv="refresh" content="2;url=?page=dashboard">';
        } else {
            $mensagem = 'Erro ao registrar saída do veículo.';
            $tipoMensagem = 'danger';
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Saída de Veículo</h2>
            <p class="text-muted">Registre a saída do veículo e efetue o pagamento.</p>
        </div>
    </div>
    
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>" role="alert">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Dados do Veículo</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Proprietário:</strong> <?php echo $registro['proprietario']; ?></p>
                            <p><strong>Documento:</strong> <?php echo $registro['documento']; ?></p>
                            <p><strong>Veículo:</strong> <?php echo $registro['modelo'] . ' / ' . $registro['cor']; ?></p>
                            <p><strong>Placa:</strong> <?php echo $registro['placa']; ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Estacionamento:</strong> <?php echo $registro['estacionamento_nome']; ?></p>
                            <p><strong>Entrada:</strong> <?php echo formatDateTime($registro['data_entrada']); ?></p>
                            <p><strong>Permanência:</strong> <?php echo $duracaoFormatada; ?></p>
                            <p>
                                <strong>Tipo de Serviço:</strong> 
                                <?php
                                $tipoServico = $registro['servico_tipo'];
                                $badgeClass = 'bg-secondary';
                                
                                if ($tipoServico == 'hora') {
                                    $badgeClass = 'bg-info';
                                } elseif ($tipoServico == 'diaria') {
                                    $badgeClass = 'bg-primary';
                                } elseif ($tipoServico == 'mensalista') {
                                    $badgeClass = 'bg-success';
                                }
                                ?>
                                <span class="badge <?php echo $badgeClass; ?>">
                                    <?php echo ucfirst($tipoServico); ?>
                                </span>
                            </p>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <form method="POST" action="">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="valor_pagar" class="form-label">Valor a Pagar</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="valor_pagar" name="valor_pagar" value="<?php echo number_format($valorPagar, 2, ',', '.'); ?>" readonly>
                                </div>
                                <?php if ($registro['servico_tipo'] == 'mensalista'): ?>
                                    <small class="text-muted">Cliente mensalista - não há cobrança.</small>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="forma_pagamento" class="form-label">Forma de Pagamento</label>
                                <select class="form-select" id="forma_pagamento" name="forma_pagamento" required>
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                    <option value="pix">PIX</option>
                                    <?php if ($registro['servico_tipo'] == 'mensalista'): ?>
                                        <option value="mensalidade">Mensalidade</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="valor_pago" class="form-label">Valor Pago</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="valor_pago" name="valor_pago" value="<?php echo number_format($valorPagar, 2, ',', '.'); ?>" <?php echo $registro['servico_tipo'] == 'mensalista' ? 'readonly' : ''; ?>>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="troco" class="form-label">Troco</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="troco" name="troco" readonly>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="?page=dashboard" class="btn btn-secondary me-md-2">Cancelar</a>
                            <button type="submit" class="btn btn-primary">Confirmar Saída</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h5 class="card-title">Resumo</h5>
                    
                    <div class="alert alert-info">
                        <h6 class="alert-heading">Detalhes do Pagamento</h6>
                        <p class="mb-0">
                            <strong>Tempo de Permanência:</strong> <?php echo $duracaoFormatada; ?><br>
                            <?php if ($registro['servico_tipo'] == 'hora'): ?>
                                <strong>Valor por Hora:</strong> R$ <?php echo number_format($registro['servico_valor'], 2, ',', '.'); ?><br>
                                <strong>Horas Cobradas:</strong> <?php echo ceil($duracao['total_minutes'] / 60); ?><br>
                            <?php elseif ($registro['servico_tipo'] == 'diaria'): ?>
                                <strong>Valor da Diária:</strong> R$ <?php echo number_format($registro['servico_valor'], 2, ',', '.'); ?><br>
                            <?php endif; ?>
                            <strong>Total a Pagar:</strong> R$ <?php echo number_format($valorPagar, 2, ',', '.'); ?>
                        </p>
                    </div>
                    
                    <hr>
                    
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-primary" id="btnImprimir">
                            <i class="fas fa-print me-2"></i> Imprimir Recibo
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Calcular troco automaticamente
    document.getElementById('valor_pago').addEventListener('input', function(e) {
        const valorPago = parseFloat(e.target.value.replace('.', '').replace(',', '.'));
        const valorPagar = parseFloat(document.getElementById('valor_pagar').value.replace('.', '').replace(',', '.'));
        
        let troco = 0;
        
        if (!isNaN(valorPago) && !isNaN(valorPagar) && valorPago >= valorPagar) {
            troco = valorPago - valorPagar;
        }
        
        document.getElementById('troco').value = troco.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
    
    // Formatar valor pago
    document.getElementById('valor_pago').addEventListener('blur', function(e) {
        const valor = parseFloat(e.target.value.replace('.', '').replace(',', '.'));
        
        if (!isNaN(valor)) {
            e.target.value = valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
    });
    
    // Imprimir recibo
    document.getElementById('btnImprimir').addEventListener('click', function() {
        window.print();
    });
</script>

