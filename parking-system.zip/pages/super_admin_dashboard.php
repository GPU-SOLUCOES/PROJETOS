<?php
// Verificar permissões - apenas super_admin pode acessar
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'super_admin') {
    echo '<div class="alert alert-danger">Você não tem permissão para acessar esta página.</div>';
    exit;
}

// Definir período padrão (último mês)
$dataFim = date('Y-m-d');
$dataInicio = date('Y-m-d', strtotime('-30 days'));

// Processar filtros
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['filtrar'])) {
    $dataInicio = $_GET['data_inicio'] ?? $dataInicio;
    $dataFim = $_GET['data_fim'] ?? $dataFim;
    $clienteId = isset($_GET['cliente_id']) && !empty($_GET['cliente_id']) ? intval($_GET['cliente_id']) : null;
}

// Obter lista de clientes para o filtro
$sql = "SELECT id, nome FROM clientes ORDER BY nome";
$clientes = fetchAll($sql);

// Obter estatísticas gerais
$sql = "SELECT 
            COUNT(DISTINCT c.id) as total_clientes,
            COUNT(DISTINCT e.id) as total_estacionamentos,
            (SELECT COUNT(*) FROM filiais) as total_filiais,
            (SELECT COUNT(*) FROM status_clientes WHERE bloqueado = 1) as clientes_bloqueados
        FROM 
            clientes c
        LEFT JOIN 
            estacionamentos e ON c.id = e.cliente_id";
$estatisticasGerais = fetchOne($sql);

// Obter dados financeiros
$filtroCliente = isset($clienteId) ? "AND pc.cliente_id = $clienteId" : "";

$sql = "SELECT 
            SUM(CASE WHEN pc.status = 'pago' THEN pc.valor ELSE 0 END) as total_recebido,
            SUM(CASE WHEN pc.status = 'pendente' THEN pc.valor ELSE 0 END) as total_pendente,
            SUM(CASE WHEN pc.status = 'atrasado' THEN pc.valor ELSE 0 END) as total_atrasado,
            COUNT(CASE WHEN pc.status = 'pago' THEN 1 ELSE NULL END) as qtd_pagos,
            COUNT(CASE WHEN pc.status = 'pendente' THEN 1 ELSE NULL END) as qtd_pendentes,
            COUNT(CASE WHEN pc.status = 'atrasado' THEN 1 ELSE NULL END) as qtd_atrasados
        FROM 
            pagamentos_clientes pc
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente";
$dadosFinanceiros = fetchOne($sql, [$dataInicio, $dataFim]);

// Obter dados para gráfico de pagamentos por mês
$sql = "SELECT 
            DATE_FORMAT(pc.data_vencimento, '%Y-%m') as mes,
            SUM(CASE WHEN pc.status = 'pago' THEN pc.valor ELSE 0 END) as valor_pago,
            SUM(CASE WHEN pc.status = 'pendente' THEN pc.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN pc.status = 'atrasado' THEN pc.valor ELSE 0 END) as valor_atrasado
        FROM 
            pagamentos_clientes pc
        WHERE 
            pc.data_vencimento BETWEEN DATE_SUB(?, INTERVAL 6 MONTH) AND ? $filtroCliente
        GROUP BY 
            DATE_FORMAT(pc.data_vencimento, '%Y-%m')
        ORDER BY 
            mes ASC";
$dadosPorMes = fetchAll($sql, [$dataFim, $dataFim]);

// Obter dados para gráfico de pagamentos por cliente
$sql = "SELECT 
            c.nome as cliente,
            SUM(CASE WHEN pc.status = 'pago' THEN pc.valor ELSE 0 END) as valor_pago,
            SUM(CASE WHEN pc.status = 'pendente' THEN pc.valor ELSE 0 END) as valor_pendente,
            SUM(CASE WHEN pc.status = 'atrasado' THEN pc.valor ELSE 0 END) as valor_atrasado
        FROM 
            pagamentos_clientes pc
        JOIN 
            clientes c ON pc.cliente_id = c.id
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente
        GROUP BY 
            pc.cliente_id
        ORDER BY 
            valor_pago DESC
        LIMIT 10";
$dadosPorCliente = fetchAll($sql, [$dataInicio, $dataFim]);

// Obter dados para gráfico de métodos de pagamento
$sql = "SELECT 
            COALESCE(pc.metodo_pagamento, 'Não informado') as metodo,
            COUNT(*) as quantidade,
            SUM(pc.valor) as valor_total
        FROM 
            pagamentos_clientes pc
        WHERE 
            pc.status = 'pago' 
            AND pc.data_pagamento BETWEEN ? AND ? $filtroCliente
        GROUP BY 
            pc.metodo_pagamento
        ORDER BY 
            valor_total DESC";
$dadosPorMetodo = fetchAll($sql, [$dataInicio, $dataFim]);

// Obter dados para tabela de pagamentos recentes
$sql = "SELECT 
            pc.id, 
            pc.valor, 
            pc.data_vencimento, 
            pc.status, 
            pc.data_pagamento, 
            pc.metodo_pagamento,
            c.nome as cliente_nome
        FROM 
            pagamentos_clientes pc
        JOIN 
            clientes c ON pc.cliente_id = c.id
        WHERE 
            pc.data_vencimento BETWEEN ? AND ? $filtroCliente
        ORDER BY 
            pc.data_vencimento DESC
        LIMIT 10";
$pagamentosRecentes = fetchAll($sql, [$dataInicio, $dataFim]);

// Obter dados para gráfico de status dos clientes
$sql = "SELECT 
            COUNT(CASE WHEN sc.ativo = 1 AND sc.bloqueado = 0 THEN 1 ELSE NULL END) as ativos,
            COUNT(CASE WHEN sc.ativo = 0 THEN 1 ELSE NULL END) as inativos,
            COUNT(CASE WHEN sc.bloqueado = 1 THEN 1 ELSE NULL END) as bloqueados
        FROM 
            status_clientes sc";
$statusClientes = fetchOne($sql);

// Preparar dados para os gráficos em formato JSON
$mesesLabels = [];
$valoresPagos = [];
$valoresPendentes = [];
$valoresAtrasados = [];

foreach ($dadosPorMes as $dado) {
    $mesesLabels[] = date('M/Y', strtotime($dado['mes'] . '-01'));
    $valoresPagos[] = floatval($dado['valor_pago']);
    $valoresPendentes[] = floatval($dado['valor_pendente']);
    $valoresAtrasados[] = floatval($dado['valor_atrasado']);
}

$clientesLabels = [];
$clientesValoresPagos = [];
$clientesValoresPendentes = [];
$clientesValoresAtrasados = [];

foreach ($dadosPorCliente as $dado) {
    $clientesLabels[] = $dado['cliente'];
    $clientesValoresPagos[] = floatval($dado['valor_pago']);
    $clientesValoresPendentes[] = floatval($dado['valor_pendente']);
    $clientesValoresAtrasados[] = floatval($dado['valor_atrasado']);
}

$metodosLabels = [];
$metodosValores = [];

foreach ($dadosPorMetodo as $dado) {
    $metodosLabels[] = $dado['metodo'];
    $metodosValores[] = floatval($dado['valor_total']);
}

$statusLabels = ['Ativos', 'Inativos', 'Bloqueados'];
$statusValores = [
    intval($statusClientes['ativos'] ?? 0),
    intval($statusClientes['inativos'] ?? 0),
    intval($statusClientes['bloqueados'] ?? 0)
];
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Dashboard Financeiro</h2>
            <p class="text-muted">Visão geral das finanças e estatísticas do sistema</p>
        </div>
    </div>
    
    <!-- Filtros -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3 align-items-end">
                <input type="hidden" name="page" value="super_admin_dashboard">
                <input type="hidden" name="filtrar" value="1">
                
                <div class="col-md-3">
                    <label for="data_inicio" class="form-label">Data Inicial</label>
                    <input type="date" class="form-control" id="data_inicio" name="data_inicio" value="<?php echo $dataInicio; ?>">
                </div>
                
                <div class="col-md-3">
                    <label for="data_fim" class="form-label">Data Final</label>
                    <input type="date" class="form-control" id="data_fim" name="data_fim" value="<?php echo $dataFim; ?>">
                </div>
                
                <div class="col-md-4">
                    <label for="cliente_id" class="form-label">Cliente</label>
                    <select class="form-select" id="cliente_id" name="cliente_id">
                        <option value="">Todos os clientes</option>
                        <?php foreach ($clientes as $cliente): ?>
                            <option value="<?php echo $cliente['id']; ?>" <?php echo (isset($clienteId) && $clienteId == $cliente['id']) ? 'selected' : ''; ?>>
                                <?php echo $cliente['nome']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i> Filtrar
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Cards de estatísticas -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="card-title text-white-50">Total Recebido</h6>
                            <h3 class="mb-0">R$ <?php echo number_format($dadosFinanceiros['total_recebido'] ?? 0, 2, ',', '.'); ?></h3>
                            <small><?php echo $dadosFinanceiros['qtd_pagos'] ?? 0; ?> pagamentos</small>
                        </div>
                        <div class="bg-white bg-opacity-25 rounded-circle p-3">
                            <i class="fas fa-money-bill-wave fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card bg-warning text-dark h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="card-title text-dark text-opacity-75">Pendente</h6>
                            <h3 class="mb-0">R$ <?php echo number_format($dadosFinanceiros['total_pendente'] ?? 0, 2, ',', '.'); ?></h3>
                            <small><?php echo $dadosFinanceiros['qtd_pendentes'] ?? 0; ?> pagamentos</small>
                        </div>
                        <div class="bg-white bg-opacity-25 rounded-circle p-3">
                            <i class="fas fa-clock fa-2x text-dark"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card bg-danger text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="card-title text-white-50">Atrasado</h6>
                            <h3 class="mb-0">R$ <?php echo number_format($dadosFinanceiros['total_atrasado'] ?? 0, 2, ',', '.'); ?></h3>
                            <small><?php echo $dadosFinanceiros['qtd_atrasados'] ?? 0; ?> pagamentos</small>
                        </div>
                        <div class="bg-white bg-opacity-25 rounded-circle p-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card bg-info text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="card-title text-white-50">Clientes</h6>
                            <h3 class="mb-0"><?php echo $estatisticasGerais['total_clientes'] ?? 0; ?></h3>
                            <small><?php echo $estatisticasGerais['clientes_bloqueados'] ?? 0; ?> bloqueados</small>
                        </div>
                        <div class="bg-white bg-opacity-25 rounded-circle p-3">
                            <i class="fas fa-users fa-2x text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Estatísticas adicionais -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Status dos Clientes</h5>
                </div>
                <div class="card-body">
                    <canvas id="graficoStatusClientes" height="250"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card h-100">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Pagamentos por Mês</h5>
                </div>
                <div class="card-body">
                    <canvas id="graficoPagamentosMes" height="250"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Gráficos de análise -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card h-100">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Top 10 Clientes por Faturamento</h5>
                </div>
                <div class="card-body">
                    <canvas id="graficoClientesFaturamento" height="250"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Métodos de Pagamento</h5>
                </div>
                <div class="card-body">
                    <canvas id="graficoMetodosPagamento" height="250"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tabela de pagamentos recentes -->
    <div class="card mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Pagamentos Recentes</h5>
            <a href="?page=super_admin&subpage=financeiro" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-list me-1"></i> Ver Todos
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>Valor</th>
                            <th>Vencimento</th>
                            <th>Status</th>
                            <th>Data Pagamento</th>
                            <th>Método</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pagamentosRecentes)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Nenhum pagamento encontrado no período selecionado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($pagamentosRecentes as $pagamento): ?>
                                <tr>
                                    <td><?php echo $pagamento['cliente_nome']; ?></td>
                                    <td>R$ <?php echo number_format($pagamento['valor'], 2, ',', '.'); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($pagamento['data_vencimento'])); ?></td>
                                    <td>
                                        <?php
                                        $statusClass = 'bg-secondary';
                                        $statusText = 'Desconhecido';
                                        
                                        switch ($pagamento['status']) {
                                            case 'pendente':
                                                $statusClass = 'bg-warning text-dark';
                                                $statusText = 'Pendente';
                                                break;
                                            case 'pago':
                                                $statusClass = 'bg-success';
                                                $statusText = 'Pago';
                                                break;
                                            case 'atrasado':
                                                $statusClass = 'bg-danger';
                                                $statusText = 'Atrasado';
                                                break;
                                            case 'cancelado':
                                                $statusClass = 'bg-secondary';
                                                $statusText = 'Cancelado';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                                    </td>
                                    <td><?php echo $pagamento['data_pagamento'] ? date('d/m/Y', strtotime($pagamento['data_pagamento'])) : '-'; ?></td>
                                    <td><?php echo $pagamento['metodo_pagamento'] ?? '-'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Relatórios disponíveis -->
    <div class="card">
        <div class="card-header bg-light">
            <h5 class="mb-0">Relatórios Disponíveis</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card h-100 border-primary">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-file-invoice-dollar me-2 text-primary"></i> Relatório Financeiro</h5>
                            <p class="card-text">Relatório detalhado de todos os pagamentos no período selecionado.</p>
                            <a href="relatorios/financeiro.php?data_inicio=<?php echo $dataInicio; ?>&data_fim=<?php echo $dataFim; ?>&cliente_id=<?php echo $clienteId ?? ''; ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                <i class="fas fa-download me-1"></i> Exportar
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card h-100 border-success">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-users me-2 text-success"></i> Relatório de Clientes</h5>
                            <p class="card-text">Relatório com informações detalhadas de todos os clientes e seus status.</p>
                            <a href="relatorios/clientes.php?data_inicio=<?php echo $dataInicio; ?>&data_fim=<?php echo $dataFim; ?>" class="btn btn-sm btn-outline-success" target="_blank">
                                <i class="fas fa-download me-1"></i> Exportar
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card h-100 border-info">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-chart-pie me-2 text-info"></i> Relatório Analítico</h5>
                            <p class="card-text">Análise detalhada de tendências e comparativos financeiros.</p>
                            <a href="relatorios/analitico.php?data_inicio=<?php echo $dataInicio; ?>&data_fim=<?php echo $dataFim; ?>&cliente_id=<?php echo $clienteId ?? ''; ?>" class="btn btn-sm btn-outline-info" target="_blank">
                                <i class="fas fa-download me-1"></i> Exportar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Gráfico de Status dos Clientes
    const ctxStatusClientes = document.getElementById('graficoStatusClientes').getContext('2d');
    const graficoStatusClientes = new Chart(ctxStatusClientes, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($statusLabels); ?>,
            datasets: [{
                data: <?php echo json_encode($statusValores); ?>,
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',
                    'rgba(108, 117, 125, 0.7)',
                    'rgba(220, 53, 69, 0.7)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Gráfico de Pagamentos por Mês
    const ctxPagamentosMes = document.getElementById('graficoPagamentosMes').getContext('2d');
    const graficoPagamentosMes = new Chart(ctxPagamentosMes, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($mesesLabels); ?>,
            datasets: [
                {
                    label: 'Pago',
                    data: <?php echo json_encode($valoresPagos); ?>,
                    backgroundColor: 'rgba(40, 167, 69, 0.7)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Pendente',
                    data: <?php echo json_encode($valoresPendentes); ?>,
                    backgroundColor: 'rgba(255, 193, 7, 0.7)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Atrasado',
                    data: <?php echo json_encode($valoresAtrasados); ?>,
                    backgroundColor: 'rgba(220, 53, 69, 0.7)',
                    borderColor: 'rgba(220, 53, 69, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    stacked: false
                },
                y: {
                    stacked: false,
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                        }
                    }
                }
            }
        }
    });
    
    // Gráfico de Clientes por Faturamento
    const ctxClientesFaturamento = document.getElementById('graficoClientesFaturamento').getContext('2d');
    const graficoClientesFaturamento = new Chart(ctxClientesFaturamento, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($clientesLabels); ?>,
            datasets: [
                {
                    label: 'Pago',
                    data: <?php echo json_encode($clientesValoresPagos); ?>,
                    backgroundColor: 'rgba(40, 167, 69, 0.7)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Pendente',
                    data: <?php echo json_encode($clientesValoresPendentes); ?>,
                    backgroundColor: 'rgba(255, 193, 7, 0.7)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Atrasado',
                    data: <?php echo json_encode($clientesValoresAtrasados); ?>,
                    backgroundColor: 'rgba(220, 53, 69, 0.7)',
                    borderColor: 'rgba(220, 53, 69, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    stacked: true,
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                },
                y: {
                    stacked: true
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                        }
                    }
                }
            }
        }
    });
    
    // Gráfico de Métodos de Pagamento
    const ctxMetodosPagamento = document.getElementById('graficoMetodosPagamento').getContext('2d');
    const graficoMetodosPagamento = new Chart(ctxMetodosPagamento, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($metodosLabels); ?>,
            datasets: [{
                data: <?php echo json_encode($metodosValores); ?>,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(255, 205, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
</script>

