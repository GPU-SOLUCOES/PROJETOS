<?php
// Obter o estacionamento atual
$estacionamentoId = $_SESSION['estacionamento_id'] ?? null;

if (!$estacionamentoId) {
    echo '<div class="alert alert-danger">Nenhum estacionamento selecionado ou disponível.</div>';
    exit;
}

// Verificar disponibilidade de vagas
$vagasDisponiveis = checkAvailableSpots($estacionamentoId);

if ($vagasDisponiveis <= 0) {
    echo '<div class="alert alert-danger">Não há vagas disponíveis no momento.</div>';
    exit;
}

// Obter tipos de serviço disponíveis
$sql = "SELECT * FROM servicos WHERE estacionamento_id = ?";
$servicos = fetchAll($sql, [$estacionamentoId]);

// Processar formulário de entrada
$mensagem = '';
$tipoMensagem = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validar dados
    $proprietario = sanitizeInput($_POST['proprietario'] ?? '');
    $documento = sanitizeInput($_POST['documento'] ?? '');
    $modelo = sanitizeInput($_POST['modelo'] ?? '');
    $cor = sanitizeInput($_POST['cor'] ?? '');
    $placa = strtoupper(sanitizeInput($_POST['placa'] ?? ''));
    $servicoId = intval($_POST['servico_id'] ?? 0);
    
    $erros = [];
    
    if (empty($proprietario)) {
        $erros[] = 'O nome do proprietário é obrigatório.';
    }
    
    if (empty($documento)) {
        $erros[] = 'O documento do proprietário é obrigatório.';
    }
    
    if (empty($modelo)) {
        $erros[] = 'O modelo do veículo é obrigatório.';
    }
    
    if (empty($cor)) {
        $erros[] = 'A cor do veículo é obrigatória.';
    }
    
    if (empty($placa)) {
        $erros[] = 'A placa do veículo é obrigatória.';
    } elseif (!validateLicensePlate($placa)) {
        $erros[] = 'Formato de placa inválido. Use o formato AAA-1234 ou AAA1A23.';
    }
    
    if ($servicoId <= 0) {
        $erros[] = 'Selecione um tipo de serviço.';
    }
    
    // Verificar se o veículo já está estacionado
    $sql = "SELECT r.id 
            FROM registros r 
            JOIN veiculos v ON r.veiculo_id = v.id 
            WHERE v.placa = ? AND r.data_saida IS NULL";
    
    $veiculoEstacionado = fetchOne($sql, [$placa]);
    
    if ($veiculoEstacionado) {
        $erros[] = 'Este veículo já está estacionado.';
    }
    
    if (empty($erros)) {
        // Verificar se o veículo já existe no banco
        $sql = "SELECT id FROM veiculos WHERE placa = ?";
        $veiculo = fetchOne($sql, [$placa]);
        
        $veiculoId = 0;
        
        if ($veiculo) {
            // Atualizar dados do veículo
            $veiculoId = $veiculo['id'];
            
            $dadosVeiculo = [
                'modelo' => $modelo,
                'cor' => $cor,
                'proprietario' => $proprietario,
                'documento' => $documento
            ];
            
            update('veiculos', $dadosVeiculo, 'id = ?', [$veiculoId]);
        } else {
            // Inserir novo veículo
            $dadosVeiculo = [
                'placa' => $placa,
                'modelo' => $modelo,
                'cor' => $cor,
                'proprietario' => $proprietario,
                'documento' => $documento
            ];
            
            $veiculoId = insert('veiculos', $dadosVeiculo);
        }
        
        // Registrar entrada
        $dadosRegistro = [
            'veiculo_id' => $veiculoId,
            'estacionamento_id' => $estacionamentoId,
            'servico_id' => $servicoId,
            'data_entrada' => date('Y-m-d H:i:s'),
            'usuario_entrada_id' => $_SESSION['user_id']
        ];
        
        $registroId = insert('registros', $dadosRegistro);
        
        if ($registroId) {
            // Registrar atividade
            logActivity($_SESSION['user_id'], 'entrada_veiculo', 'Registro de entrada do veículo ' . $placa);
            
            $mensagem = 'Veículo registrado com sucesso!';
            $tipoMensagem = 'success';
            
            // Redirecionar para o dashboard após 2 segundos
            echo '<meta http-equiv="refresh" content="2;url=?page=dashboard">';
        } else {
            $mensagem = 'Erro ao registrar entrada do veículo.';
            $tipoMensagem = 'danger';
        }
    } else {
        $mensagem = implode('<br>', $erros);
        $tipoMensagem = 'danger';
    }
}
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Entrada de Veículo</h2>
            <p class="text-muted">Preencha os dados abaixo para registrar a entrada de um veículo.</p>
        </div>
    </div>
    
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>" role="alert">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="proprietario" class="form-label">Nome do Proprietário</label>
                                <input type="text" class="form-control" id="proprietario" name="proprietario" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="documento" class="form-label">Documento (CPF/RG)</label>
                                <input type="text" class="form-control" id="documento" name="documento" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="modelo" class="form-label">Modelo do Veículo</label>
                                <input type="text" class="form-control" id="modelo" name="modelo" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="cor" class="form-label">Cor</label>
                                <input type="text" class="form-control" id="cor" name="cor" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="placa" class="form-label">Placa</label>
                                <input type="text" class="form-control" id="placa" name="placa" required placeholder="AAA-1234 ou AAA1A23">
                            </div>
                            
                            <div class="col-md-6">
                                <label for="servico_id" class="form-label">Tipo de Serviço</label>
                                <select class="form-select" id="servico_id" name="servico_id" required>
                                    <option value="">Selecione...</option>
                                    <?php foreach ($servicos as $servico): ?>
                                        <option value="<?php echo $servico['id']; ?>">
                                            <?php 
                                            echo ucfirst($servico['tipo']);
                                            if ($servico['tipo'] == 'hora') {
                                                echo ' - R$ ' . number_format($servico['valor'], 2, ',', '.') . '/hora';
                                            } elseif ($servico['tipo'] == 'diaria') {
                                                echo ' - R$ ' . number_format($servico['valor'], 2, ',', '.') . '/dia';
                                            } elseif ($servico['tipo'] == 'mensalista') {
                                                echo ' - Mensalista';
                                            }
                                            ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="?page=dashboard" class="btn btn-secondary me-md-2">Cancelar</a>
                            <button type="submit" class="btn btn-primary">Registrar Entrada</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h5 class="card-title">Informações</h5>
                    <p class="card-text">Vagas disponíveis: <strong><?php echo $vagasDisponiveis; ?></strong></p>
                    
                    <hr>
                    
                    <h6>Tipos de Serviço</h6>
                    <ul class="list-group">
                        <?php foreach ($servicos as $servico): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo ucfirst($servico['tipo']); ?>
                                <?php if ($servico['tipo'] == 'hora'): ?>
                                    <span class="badge bg-primary rounded-pill">
                                        R$ <?php echo number_format($servico['valor'], 2, ',', '.'); ?>/hora
                                    </span>
                                <?php elseif ($servico['tipo'] == 'diaria'): ?>
                                    <span class="badge bg-info rounded-pill">
                                        R$ <?php echo number_format($servico['valor'], 2, ',', '.'); ?>/dia
                                    </span>
                                <?php elseif ($servico['tipo'] == 'mensalista'): ?>
                                    <span class="badge bg-success rounded-pill">Mensalista</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <hr>
                    
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-info-circle me-2"></i> Preencha todos os campos corretamente para registrar a entrada do veículo.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Formatar placa automaticamente
    document.getElementById('placa').addEventListener('input', function(e) {
        let value = e.target.value.toUpperCase();
        
        // Remover caracteres não alfanuméricos
        value = value.replace(/[^A-Z0-9]/g, '');
        
        // Aplicar máscara conforme o formato
        if (value.length <= 7) {
            // Formato antigo: AAA-1234
            if (value.length > 3) {
                value = value.substring(0, 3) + '-' + value.substring(3);
            }
        }
        
        e.target.value = value;
    });
</script>

