<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12 text-center">
            <div class="alert alert-danger">
                <h3><i class="fas fa-exclamation-triangle me-3"></i> Acesso Negado</h3>
                <p class="mb-0">Você não tem permissão para acessar esta página.</p>
            </div>
            
            <a href="?page=dashboard" class="btn btn-primary mt-3">
                <i class="fas fa-home me-2"></i> Voltar ao Dashboard
            </a>
        </div>
    </div>
</div>

