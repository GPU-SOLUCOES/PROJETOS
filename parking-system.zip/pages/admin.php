<?php
// Verificar permissões
if ($_SESSION['user_type'] != 'gerente' && $_SESSION['user_type'] != 'admin') {
    echo '<div class="alert alert-danger">Você não tem permissão para acessar esta página.</div>';
    exit;
}

// Obter o cliente atual
$clienteId = $_SESSION['cliente_id'] ?? null;

if (!$clienteId) {
    echo '<div class="alert alert-danger">Cliente não identificado.</div>';
    exit;
}

// Obter estacionamento atual
$estacionamentoId = $_SESSION['estacionamento_id'] ?? null;

// Definir subpágina
$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'usuarios';

// Processar ações
$mensagem = '';
$tipoMensagem = '';

// Processar criação/edição de usuário
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'usuarios') {
    $userId = intval($_POST['user_id'] ?? 0);
    $nome = sanitizeInput($_POST['nome'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $tipoAcesso = sanitizeInput($_POST['tipo_acesso'] ?? '');
    
    if (empty($nome) || empty($email) || empty($tipoAcesso)) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'danger';
    } else {
        if ($userId > 0) {
            // Editar usuário existente
            $dadosUsuario = [
                'nome' => $nome,
                'email' => $email,
                'tipo_acesso' => $tipoAcesso
            ];
            
            // Adicionar senha apenas se foi fornecida
            if (!empty($senha)) {
                $dadosUsuario['senha'] = password_hash($senha, PASSWORD_DEFAULT);
            }
            
            $resultado = update('usuarios', $dadosUsuario, 'id = ?', [$userId]);
            
            if ($resultado) {
                $mensagem = 'Usuário atualizado com sucesso!';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao atualizar usuário.';
                $tipoMensagem = 'danger';
            }
        } else {
            // Criar novo usuário
            if (empty($senha)) {
                $mensagem = 'A senha é obrigatória para novos usuários.';
                $tipoMensagem = 'danger';
            } else {
                $resultado = createUser($nome, $email, $senha, $tipoAcesso, $clienteId);
                
                if ($resultado['success']) {
                    $mensagem = 'Usuário criado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = $resultado['message'];
                    $tipoMensagem = 'danger';
                }
            }
        }
    }
}

// Processar criação/edição de estacionamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'estacionamentos') {
    $parkingId = intval($_POST['parking_id'] ?? 0);
    $nome = sanitizeInput($_POST['nome'] ?? '');
    $endereco = sanitizeInput($_POST['endereco'] ?? '');
    $capacidade = intval($_POST['capacidade'] ?? 0);
    $horarioAbertura = sanitizeInput($_POST['horario_abertura'] ?? '');
    $horarioFechamento = sanitizeInput($_POST['horario_fechamento'] ?? '');
    
    if (empty($nome) || empty($endereco) || $capacidade <= 0) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'danger';
    } else {
        $dadosEstacionamento = [
            'nome' => $nome,
            'endereco' => $endereco,
            'capacidade' => $capacidade,
            'horario_abertura' => $horarioAbertura,
            'horario_fechamento' => $horarioFechamento,
            'cliente_id' => $clienteId
        ];
        
        if ($parkingId > 0) {
            // Editar estacionamento existente
            $resultado = update('estacionamentos', $dadosEstacionamento, 'id = ?', [$parkingId]);
            
            if ($resultado) {
                $mensagem = 'Estacionamento atualizado com sucesso!';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao atualizar estacionamento.';
                $tipoMensagem = 'danger';
            }
        } else {
            // Criar novo estacionamento
            $parkingId = insert('estacionamentos', $dadosEstacionamento);
            
            if ($parkingId) {
                $mensagem = 'Estacionamento criado com sucesso!';
                $tipoMensagem = 'success';
            } else {
                $mensagem = 'Erro ao criar estacionamento.';
                $tipoMensagem = 'danger';
            }
        }
    }
}

// Processar criação/edição de serviço
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $subpage == 'servicos') {
    $servicoId = intval($_POST['servico_id'] ?? 0);
    $tipo = sanitizeInput($_POST['tipo'] ?? '');
    $valor = floatval(str_replace(',', '.', $_POST['valor'] ?? 0));
    $estacionamentoId = intval($_POST['estacionamento_id'] ?? 0);
    
    if (empty($tipo) || $estacionamentoId <= 0) {
        $mensagem = 'Preencha todos os campos obrigatórios.';
        $tipoMensagem = 'danger';
    } else {
        $dadosServico = [
            'tipo' => $tipo,
            'valor' => $valor,
            'estacionamento_id' => $estacionamentoId
        ];
        
        // Verificar se já existe um serviço do mesmo tipo para este estacionamento
        $sql = "SELECT id FROM servicos WHERE tipo = ? AND estacionamento_id = ? AND id != ?";
        $servicoExistente = fetchOne($sql, [$tipo, $estacionamentoId, $servicoId]);
        
        if ($servicoExistente) {
            $mensagem = 'Já existe um serviço deste tipo para este estacionamento.';
            $tipoMensagem = 'danger';
        } else {
            if ($servicoId > 0) {
                // Editar serviço existente
                $resultado = update('servicos', $dadosServico, 'id = ?', [$servicoId]);
                
                if ($resultado) {
                    $mensagem = 'Serviço atualizado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = 'Erro ao atualizar serviço.';
                    $tipoMensagem = 'danger';
                }
            } else {
                // Criar novo serviço
                $servicoId = insert('servicos', $dadosServico);
                
                if ($servicoId) {
                    $mensagem = 'Serviço criado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = 'Erro ao criar serviço.';
                    $tipoMensagem = 'danger';
                }
            }
        }
    }
}

// Obter dados para exibição
$usuarios = getUsersByClient($clienteId);
$estacionamentos = getParkingsByClient($clienteId);

// Obter serviços do estacionamento atual
$servicos = [];
if ($estacionamentoId) {
    $sql = "SELECT * FROM servicos WHERE estacionamento_id = ?";
    $servicos = fetchAll($sql, [$estacionamentoId]);
}
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Administração</h2>
            <p class="text-muted">Gerencie usuários, estacionamentos e serviços.</p>
        </div>
    </div>
    
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>" role="alert">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>
    
    <div class="row mb-4">
        <div class="col-12">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php echo $subpage == 'usuarios' ? 'active' : ''; ?>" href="?page=admin&subpage=usuarios">
                        <i class="fas fa-users me-2"></i> Usuários
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $subpage == 'estacionamentos' ? 'active' : ''; ?>" href="?page=admin&subpage=estacionamentos">
                        <i class="fas fa-parking me-2"></i> Estacionamentos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $subpage == 'servicos' ? 'active' : ''; ?>" href="?page=admin&subpage=servicos">
                        <i class="fas fa-tags me-2"></i> Serviços
                    </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12">
            <?php if ($subpage == 'usuarios'): ?>
                <!-- Gerenciamento de Usuários -->
                <div class="card">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Usuários</h5>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalUsuario">
                            <i class="fas fa-plus me-1"></i> Novo Usuário
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Nome</th>
                                        <th>Email</th>
                                        <th>Tipo de Acesso</th>
                                        <th>Data de Criação</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($usuarios as $usuario): ?>
                                        <tr>
                                            <td><?php echo $usuario['nome']; ?></td>
                                            <td><?php echo $usuario['email']; ?></td>
                                            <td>
                                                <?php
                                                $tipoAcesso = $usuario['tipo_acesso'];
                                                $badgeClass = 'bg-secondary';
                                                
                                                if ($tipoAcesso == 'atendente') {
                                                    $badgeClass = 'bg-info';
                                                } elseif ($tipoAcesso == 'gerente') {
                                                    $badgeClass = 'bg-primary';
                                                } elseif ($tipoAcesso == 'admin') {
                                                    $badgeClass = 'bg-danger';
                                                }
                                                ?>
                                                <span class="badge <?php echo $badgeClass; ?>">
                                                    <?php echo ucfirst($tipoAcesso); ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDateTime($usuario['data_criacao']); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-usuario" 
                                                        data-id="<?php echo $usuario['id']; ?>"
                                                        data-nome="<?php echo $usuario['nome']; ?>"
                                                        data-email="<?php echo $usuario['email']; ?>"
                                                        data-tipo="<?php echo $usuario['tipo_acesso']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger btn-excluir-usuario" 
                                                        data-id="<?php echo $usuario['id']; ?>"
                                                        data-nome="<?php echo $usuario['nome']; ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Modal de Usuário -->
                <div class="modal fade" id="modalUsuario" tabindex="-1" aria-labelledby="modalUsuarioLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalUsuarioLabel">Novo Usuário</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div>
                            <form method="POST" action="">
                                <div class="modal-body">
                                    <input type="hidden" id="user_id" name="user_id" value="0">
                                    
                                    <div class="mb-3">
                                        <label for="nome" class="form-label">Nome</label>
                                        <input type="text" class="form-control" id="nome" name="nome" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="senha" class="form-label">Senha</label>
                                        <input type="password" class="form-control" id="senha" name="senha">
                                        <small class="form-text text-muted" id="senhaHelp">Deixe em branco para manter a senha atual (ao editar).</small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="tipo_acesso" class="form-label">Tipo de Acesso</label>
                                        <select class="form-select" id="tipo_acesso" name="tipo_acesso" required>
                                            <option value="">Selecione...</option>
                                            <option value="atendente">Atendente</option>
                                            <option value="gerente">Gerente</option>
                                            <option value="admin">Administrador</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Modal de Exclusão de Usuário -->
                <div class="modal fade" id="modalExcluirUsuario" tabindex="-1" aria-labelledby="modalExcluirUsuarioLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalExcluirUsuarioLabel">Confirmar Exclusão</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div>
                            <div class="modal-body">
                                <p>Tem certeza que deseja excluir o usuário <strong id="nomeUsuarioExcluir"></strong>?</p>
                                <p class="text-danger">Esta ação não pode ser desfeita.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <form method="POST" action="ajax/excluir_usuario.php" id="formExcluirUsuario">
                                    <input type="hidden" id="excluir_user_id" name="user_id" value="0">
                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <script>
                    // Editar usuário
                    document.querySelectorAll('.btn-editar-usuario').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            const id = this.getAttribute('data-id');
                            const nome = this.getAttribute('data-nome');
                            const email = this.getAttribute('data-email');
                            const tipo = this.getAttribute('data-tipo');
                            
                            document.getElementById('modalUsuarioLabel').textContent = 'Editar Usuário';
                            document.getElementById('user_id').value = id;
                            document.getElementById('nome').value = nome;
                            document.getElementById('email').value = email;
                            document.getElementById('senha').value = '';
                            document.getElementById('senhaHelp').style.display = 'block';
                            document.getElementById('tipo_acesso').value = tipo;
                            
                            const modal = new bootstrap.Modal(document.getElementById('modalUsuario'));
                            modal.show();
                        });
                    });
                    
                    // Novo usuário
                    document.querySelector('[data-bs-target="#modalUsuario"]').addEventListener('click', function() {
                        document.getElementById('modalUsuarioLabel').textContent = 'Novo Usuário';
                        document.getElementById('user_id').value = '0';
                        document.getElementById('nome').value = '';
                        document.getElementById('email').value = '';
                        document.getElementById('senha').value = '';
                        document.getElementById('senhaHelp').style.display = 'none';
                        document.getElementById('tipo_acesso').value = '';
                    });
                    
                    // Excluir usuário
                    document.querySelectorAll('.btn-excluir-usuario').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            const id = this.getAttribute('data-id');
                            const nome = this.getAttribute('data-nome');
                            
                            document.getElementById('nomeUsuarioExcluir').textContent = nome;
                            document.getElementById('excluir_user_id').value = id;
                            
                            const modal = new bootstrap.Modal(document.getElementById('modalExcluirUsuario'));
                            modal.show();
                        });
                    });
                </script>
            <?php elseif ($subpage == 'estacionamentos'): ?>
                <!-- Gerenciamento de Estacionamentos -->
                <div class="card">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Estacionamentos</h5>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalEstacionamento">
                            <i class="fas fa-plus me-1"></i> Novo Estacionamento
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Nome</th>
                                        <th>Endereço</th>
                                        <th>Capacidade</th>
                                        <th>Horário de Funcionamento</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($estacionamentos as $estacionamento): ?>
                                        <tr>
                                            <td><?php echo $estacionamento['nome']; ?></td>
                                            <td><?php echo $estacionamento['endereco']; ?></td>
                                            <td><?php echo $estacionamento['capacidade']; ?> vagas</td>
                                            <td>
                                                <?php 
                                                echo $estacionamento['horario_abertura'] . ' às ' . $estacionamento['horario_fechamento']; 
                                                ?>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-estacionamento" 
                                                        data-id="<?php echo $estacionamento['id']; ?>"
                                                        data-nome="<?php echo $estacionamento['nome']; ?>"
                                                        data-endereco="<?php echo $estacionamento['endereco']; ?>"
                                                        data-capacidade="<?php echo $estacionamento['capacidade']; ?>"
                                                        data-abertura="<?php echo $estacionamento['horario_abertura']; ?>"
                                                        data-fechamento="<?php echo $estacionamento['horario_fechamento']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger btn-excluir-estacionamento" 
                                                        data-id="<?php echo $estacionamento['id']; ?>"
                                                        data-nome="<?php echo $estacionamento['nome']; ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Modal de Estacionamento -->
                <div class="modal fade" id="modalEstacionamento" tabindex="-1" aria-labelledby="modalEstacionamentoLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalEstacionamentoLabel">Novo Estacionamento</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div>
                            <form method="POST" action="">
                                <div class="modal-body">
                                    <input type="hidden" id="parking_id" name="parking_id" value="0">
                                    
                                    <div class="mb-3">
                                        <label for="nome" class="form-label">Nome</label>
                                        <input type="text" class="form-control" id="nome_estacionamento" name="nome" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="endereco" class="form-label">Endereço</label>
                                        <input type="text" class="form-control" id="endereco" name="endereco" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="capacidade" class="form-label">Capacidade (vagas)</label>
                                        <input type="number" class="form-control" id="capacidade" name="capacidade" min="1" required>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="horario_abertura" class="form-label">Horário de Abertura</label>
                                            <input type="time" class="form-control" id="horario_abertura" name="horario_abertura" required>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label for="horario_fechamento" class="form-label">Horário de Fechamento</label>
                                            <input type="time" class="form-control" id="horario_fechamento" name="horario_fechamento" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Modal de Exclusão de Estacionamento -->
                <div class="modal fade" id="modalExcluirEstacionamento" tabindex="-1" aria-labelledby="modalExcluirEstacionamentoLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalExcluirEstacionamentoLabel">Confirmar Exclusão</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div>
                            <div class="modal-body">
                                <p>Tem certeza que deseja excluir o estacionamento <strong id="nomeEstacionamentoExcluir"></strong>?</p>
                                <p class="text-danger">Esta ação não pode ser desfeita e excluirá todos os dados relacionados a este estacionamento.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <form method="POST" action="ajax/excluir_estacionamento.php" id="formExcluirEstacionamento">
                                    <input type="hidden" id="excluir_parking_id" name="parking_id" value="0">
                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <script>
                    // Editar estacionamento
                    document.querySelectorAll('.btn-editar-estacionamento').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            const id = this.getAttribute('data-id');
                            const nome = this.getAttribute('data-nome');
                            const endereco = this.getAttribute('data-endereco');
                            const capacidade = this.getAttribute('data-capacidade');
                            const abertura = this.getAttribute('data-abertura');
                            const fechamento = this.getAttribute('data-fechamento');
                            
                            document.getElementById('modalEstacionamentoLabel').textContent = 'Editar Estacionamento';
                            document.getElementById('parking_id').value = id;
                            document.getElementById('nome_estacionamento').value = nome;
                            document.getElementById('endereco').value = endereco;
                            document.getElementById('capacidade').value = capacidade;
                            document.getElementById('horario_abertura').value = abertura;
                            document.getElementById('horario_fechamento').value = fechamento;
                            
                            const modal = new bootstrap.Modal(document.getElementById('modalEstacionamento'));
                            modal.show();
                        });
                    });
                    
                    // Novo estacionamento
                    document.querySelector('[data-bs-target="#modalEstacionamento"]').addEventListener('click', function() {
                        document.getElementById('modalEstacionamentoLabel').textContent = 'Novo Estacionamento';
                        document.getElementById('parking_id').value = '0';
                        document.getElementById('nome_estacionamento').value = '';
                        document.getElementById('endereco').value = '';
                        document.getElementById('capacidade').value = '';
                        document.getElementById('horario_abertura').value = '08:00';
                        document.getElementById('horario_fechamento').value = '18:00';
                    });
                    
                    // Excluir estacionamento
                    document.querySelectorAll('.btn-excluir-estacionamento').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            const id = this.getAttribute('data-id');
                            const nome = this.getAttribute('data-nome');
                            
                            document.getElementById('nomeEstacionamentoExcluir').textContent = nome;
                            document.getElementById('excluir_parking_id').value = id;
                            
                            const modal = new bootstrap.Modal(document.getElementById('modalExcluirEstacionamento'));
                            modal.show();
                        });
                    });
                </script>
            <?php elseif ($subpage == 'servicos'): ?>
                <!-- Gerenciamento de Serviços -->
                <?php if (!$estacionamentoId): ?>
                    <div class="alert alert-warning">
                        Selecione um estacionamento para gerenciar os serviços.
                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Serviços</h5>
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalServico">
                                <i class="fas fa-plus me-1"></i> Novo Serviço
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Tipo</th>
                                            <th>Valor</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($servicos as $servico): ?>
                                            <tr>
                                                <td>
                                                    <?php
                                                    $tipoServico = $servico['tipo'];
                                                    $badgeClass = 'bg-secondary';
                                                    
                                                    if ($tipoServico == 'hora') {
                                                        $badgeClass = 'bg-info';
                                                    } elseif ($tipoServico == 'diaria') {
                                                        $badgeClass = 'bg-primary';
                                                        $tipoExibicao = 'Diária';
                                                    } elseif ($tipoServico == 'mensalista') {
                                                        $badgeClass = 'bg-success';
                                                        $tipoExibicao = 'Mensalista';
                                                    } else {
                                                        $tipoExibicao = ucfirst($tipoServico);
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $badgeClass; ?>">
                                                        <?php echo $tipoExibicao; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php 
                                                    if ($tipoServico == 'mensalista') {
                                                        echo 'N/A';
                                                    } else {
                                                        echo 'R$ ' . number_format($servico['valor'], 2, ',', '.');
                                                        
                                                        if ($tipoServico == 'hora') {
                                                            echo '/hora';
                                                        } elseif ($tipoServico == 'diaria') {
                                                            echo '/dia';
                                                        }
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-outline-primary me-1 btn-editar-servico" 
                                                            data-id="<?php echo $servico['id']; ?>"
                                                            data-tipo="<?php echo $servico['tipo']; ?>"
                                                            data-valor="<?php echo $servico['valor']; ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-danger btn-excluir-servico" 
                                                            data-id="<?php echo $servico['id']; ?>"
                                                            data-tipo="<?php echo $tipoExibicao; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Modal de Serviço -->
                    <div class="modal fade" id="modalServico" tabindex="-1" aria-labelledby="modalServicoLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalServicoLabel">Novo Serviço</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                </div>
                                <form method="POST" action="">
                                    <div class="modal-body">
                                        <input type="hidden" id="servico_id" name="servico_id" value="0">
                                        <input type="hidden" name="estacionamento_id" value="<?php echo $estacionamentoId; ?>">
                                        
                                        <div class="mb-3">
                                            <label for="tipo" class="form-label">Tipo de Serviço</label>
                                            <select class="form-select" id="tipo" name="tipo" required>
                                                <option value="">Selecione...</option>
                                                <option value="hora">Por Hora</option>
                                                <option value="diaria">Diária</option>
                                                <option value="mensalista">Mensalista</option>
                                            </select>
                                        </div>
                                        
                                        <div class="mb-3" id="divValor">
                                            <label for="valor" class="form-label">Valor</label>
                                            <div class="input-group">
                                                <span class="input-group-text">R$</span>
                                                <input type="text" class="form-control" id="valor" name="valor" placeholder="0,00">
                                            </div>
                                            <small class="form-text text-muted" id="valorHelp"></small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary">Salvar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Modal de Exclusão de Serviço -->
                    <div class="modal fade" id="modalExcluirServico" tabindex="-1" aria-labelledby="modalExcluirServicoLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalExcluirServicoLabel">Confirmar Exclusão</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Tem certeza que deseja excluir o serviço <strong id="tipoServicoExcluir"></strong>?</p>
                                    <p class="text-danger">Esta ação não pode ser desfeita.</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <form method="POST" action="ajax/excluir_servico.php" id="formExcluirServico">
                                        <input type="hidden" id="excluir_servico_id" name="servico_id" value="0">
                                        <button type="submit" class="btn btn-danger">Excluir</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                        // Controlar exibição do campo de valor
                        document.getElementById('tipo').addEventListener('change', function() {
                            const tipo = this.value;
                            const divValor = document.getElementById('divValor');
                            const valorHelp = document.getElementById('valorHelp');
                            
                            if (tipo === 'mensalista') {
                                divValor.style.display = 'none';
                                document.getElementById('valor').value = '0,00';
                            } else {
                                divValor.style.display = 'block';
                                
                                if (tipo === 'hora') {
                                    valorHelp.textContent = 'Valor cobrado por hora de permanência.';
                                } else if (tipo === 'diaria') {
                                    valorHelp.textContent = 'Valor fixo cobrado por dia.';
                                }
                            }
                        });
                        
                        // Formatar valor
                        document.getElementById('valor').addEventListener('blur', function(e) {
                            const valor = parseFloat(e.target.value.replace('.', '').replace(',', '.'));
                            
                            if (!isNaN(valor)) {
                                e.target.value = valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                            }
                        });
                        
                        // Editar serviço
                        document.querySelectorAll('.btn-editar-servico').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                const id = this.getAttribute('data-id');
                                const tipo = this.getAttribute('data-tipo');
                                const valor = parseFloat(this.getAttribute('data-valor'));
                                
                                document.getElementById('modalServicoLabel').textContent = 'Editar Serviço';
                                document.getElementById('servico_id').value = id;
                                document.getElementById('tipo').value = tipo;
                                
                                if (tipo === 'mensalista') {
                                    document.getElementById('divValor').style.display = 'none';
                                    document.getElementById('valor').value = '0,00';
                                } else {
                                    document.getElementById('divValor').style.display = 'block';
                                    document.getElementById('valor').value = valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                                    
                                    const valorHelp = document.getElementById('valorHelp');
                                    if (tipo === 'hora') {
                                        valorHelp.textContent = 'Valor cobrado por hora de permanência.';
                                    } else if (tipo === 'diaria') {
                                        valorHelp.textContent = 'Valor fixo cobrado por dia.';
                                    }
                                }
                                
                                const modal = new bootstrap.Modal(document.getElementById('modalServico'));
                                modal.show();
                            });
                        });
                        
                        // Novo serviço
                        document.querySelector('[data-bs-target="#modalServico"]').addEventListener('click', function() {
                            document.getElementById('modalServicoLabel').textContent = 'Novo Serviço';
                            document.getElementById('servico_id').value = '0';
                            document.getElementById('tipo').value = '';
                            document.getElementById('valor').value = '';
                            document.getElementById('divValor').style.display = 'block';
                            document.getElementById('valorHelp').textContent = '';
                        });
                        
                        // Excluir serviço
                        document.querySelectorAll('.btn-excluir-servico').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                const id = this.getAttribute('data-id');
                                const tipo = this.getAttribute('data-tipo');
                                
                                document.getElementById('tipoServicoExcluir').textContent = tipo;
                                document.getElementById('excluir_servico_id').value = id;
                                
                                const modal = new bootstrap.Modal(document.getElementById('modalExcluirServico'));
                                modal.show();
                            });
                        });
                    </script>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

