<?php
// Verificar se é super admin
$isSuperAdmin = isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'super_admin';

// Obter o estacionamento atual
$estacionamentoId = $_SESSION['estacionamento_id'] ?? null;

// Se for super admin e não tiver estacionamento selecionado, mostrar lista de clientes e estacionamentos
if ($isSuperAdmin && !$estacionamentoId) {
    // Obter todos os clientes
    $sql = "SELECT id, nome FROM clientes ORDER BY nome";
    $clientes = fetchAll($sql);
    
    // Obter todos os estacionamentos
    $sql = "SELECT e.id, e.nome, e.endereco, c.nome as cliente_nome 
            FROM estacionamentos e 
            JOIN clientes c ON e.cliente_id = c.id 
            ORDER BY c.nome, e.nome";
    $todosEstacionamentos = fetchAll($sql);
    
    // Exibir seletor de estacionamentos para super admin
    ?>
    <div class="container-fluid py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="mb-0">Dashboard - Super Admin</h2>
                <p class="text-muted">Selecione um estacionamento para visualizar os dados</p>
            </div>
        </div>
        
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Selecionar Estacionamento</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="ajax/set_estacionamento.php" class="mb-4">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-6">
                                    <label for="estacionamento_id" class="form-label">Estacionamento</label>
                                    <select class="form-select" id="estacionamento_id" name="estacionamento_id" required>
                                        <option value="">Selecione um estacionamento...</option>
                                        <?php foreach ($todosEstacionamentos as $estacionamento): ?>
                                            <option value="<?php echo $estacionamento['id']; ?>">
                                                <?php echo $estacionamento['nome']; ?> (<?php echo $estacionamento['cliente_nome']; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-check me-2"></i> Selecionar
                                    </button>
                                </div>
                            </div>
                        </form>
                        
                        <h6 class="mb-3">Estacionamentos por Cliente</h6>
                        <div class="accordion" id="accordionClientes">
                            <?php foreach ($clientes as $index => $cliente): ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo $cliente['id']; ?>">
                                        <button class="accordion-button <?php echo $index > 0 ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $cliente['id']; ?>" aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>" aria-controls="collapse<?php echo $cliente['id']; ?>">
                                            <?php echo $cliente['nome']; ?>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo $cliente['id']; ?>" class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $cliente['id']; ?>" data-bs-parent="#accordionClientes">
                                        <div class="accordion-body">
                                            <div class="list-group">
                                                <?php 
                                                $sql = "SELECT id, nome, endereco FROM estacionamentos WHERE cliente_id = ? ORDER BY nome";
                                                $estacionamentosCliente = fetchAll($sql, [$cliente['id']]);
                                                
                                                if (empty($estacionamentosCliente)) {
                                                    echo '<div class="text-muted">Nenhum estacionamento cadastrado para este cliente.</div>';
                                                } else {
                                                    foreach ($estacionamentosCliente as $estacionamento):
                                                ?>
                                                    <a href="ajax/set_estacionamento.php?estacionamento_id=<?php echo $estacionamento['id']; ?>" class="list-group-item list-group-item-action">
                                                        <div class="d-flex w-100 justify-content-between">
                                                            <h6 class="mb-1"><?php echo $estacionamento['nome']; ?></h6>
                                                        </div>
                                                        <p class="mb-1"><?php echo $estacionamento['endereco']; ?></p>
                                                    </a>
                                                <?php 
                                                    endforeach;
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return; // Encerrar a execução aqui para super admin sem estacionamento selecionado
}

// Para usuários normais ou super admin com estacionamento selecionado, continuar com o código original
if (!$estacionamentoId) {
  // Se não houver estacionamento selecionado, pegar o primeiro disponível
  $clienteId = $_SESSION['cliente_id'] ?? null;
  
  if ($clienteId) {
      $estacionamentos = getParkingsByClient($clienteId);
      
      if (!empty($estacionamentos)) {
          $estacionamentoId = $estacionamentos[0]['id'];
          $_SESSION['estacionamento_id'] = $estacionamentoId;
      }
  }
}

// Obter informações do estacionamento
$estacionamento = null;
if ($estacionamentoId) {
  $sql = "SELECT * FROM estacionamentos WHERE id = ?";
  $estacionamento = fetchOne($sql, [$estacionamentoId]);
}

// Obter veículos estacionados
$veiculosEstacionados = [];
if ($estacionamentoId) {
  $sql = "SELECT 
              r.id, 
              r.data_entrada, 
              v.modelo, 
              v.cor, 
              v.placa, 
              v.proprietario, 
              s.tipo AS servico_tipo 
          FROM 
              registros r
          JOIN 
              veiculos v ON r.veiculo_id = v.id
          JOIN 
              servicos s ON r.servico_id = s.id
          WHERE 
              r.estacionamento_id = ? AND 
              r.data_saida IS NULL
          ORDER BY 
              r.data_entrada DESC";
  
  $veiculosEstacionados = fetchAll($sql, [$estacionamentoId]);
}

// Calcular estatísticas
$vagasDisponiveis = 0;
$vagasOcupadas = 0;
$percentualOcupacao = 0;

if ($estacionamento) {
  $vagasDisponiveis = checkAvailableSpots($estacionamentoId);
  $vagasOcupadas = $estacionamento['capacidade'] - $vagasDisponiveis;
  $percentualOcupacao = ($vagasOcupadas / $estacionamento['capacidade']) * 100;
}

// Obter estatísticas do dia
$hoje = date('Y-m-d');
$estatisticasDia = [];

if ($estacionamentoId) {
  $sql = "SELECT 
              COUNT(*) as total_entradas,
              SUM(CASE WHEN data_saida IS NOT NULL THEN valor_pago ELSE 0 END) as total_faturado
          FROM 
              registros 
          WHERE 
              estacionamento_id = ? AND 
              DATE(data_entrada) = ?";
  
  $estatisticasDia = fetchOne($sql, [$estacionamentoId, $hoje]);
}
?>

<div class="container-fluid py-4">
  <div class="row mb-4">
      <div class="col-12">
          <h2 class="mb-0">Dashboard</h2>
          <?php if ($estacionamento): ?>
              <p class="text-muted">Estacionamento: <?php echo $estacionamento['nome']; ?></p>
          <?php else: ?>
              <p class="text-danger">Nenhum estacionamento selecionado ou disponível.</p>
          <?php endif; ?>
      </div>
  </div>
  
  <?php if ($estacionamento): ?>
      <!-- Cards de estatísticas -->
      <div class="row mb-4">
          <div class="col-md-3">
              <div class="card bg-primary text-white">
                  <div class="card-body">
                      <h5 class="card-title">Vagas Disponíveis</h5>
                      <h2 class="display-4"><?php echo $vagasDisponiveis; ?></h2>
                      <p class="card-text">de <?php echo $estacionamento['capacidade']; ?> vagas totais</p>
                  </div>
              </div>
          </div>
          
          <div class="col-md-3">
              <div class="card bg-info text-white">
                  <div class="card-body">
                      <h5 class="card-title">Ocupação</h5>
                      <h2 class="display-4"><?php echo number_format($percentualOcupacao, 1); ?>%</h2>
                      <p class="card-text"><?php echo $vagasOcupadas; ?> vagas ocupadas</p>
                  </div>
              </div>
          </div>
          
          <div class="col-md-3">
              <div class="card bg-success text-white">
                  <div class="card-body">
                      <h5 class="card-title">Entradas Hoje</h5>
                      <h2 class="display-4"><?php echo $estatisticasDia['total_entradas'] ?? 0; ?></h2>
                      <p class="card-text">veículos registrados hoje</p>
                  </div>
              </div>
          </div>
          
          <div class="col-md-3">
              <div class="card bg-warning text-dark">
                  <div class="card-body">
                      <h5 class="card-title">Faturamento Hoje</h5>
                      <h2 class="display-4">R$ <?php echo number_format($estatisticasDia['total_faturado'] ?? 0, 2, ',', '.'); ?></h2>
                      <p class="card-text">valor total recebido hoje</p>
                  </div>
              </div>
          </div>
      </div>
      
      <!-- Botão de entrada rápida -->
      <div class="row mb-4">
          <div class="col-12">
              <a href="?page=entrada" class="btn btn-primary btn-lg">
                  <i class="fas fa-car me-2"></i> Nova Entrada de Veículo
              </a>
          </div>
      </div>
      
      <!-- Lista de veículos estacionados -->
      <div class="row">
          <div class="col-12">
              <div class="card">
                  <div class="card-header bg-light">
                      <h5 class="mb-0">Veículos Estacionados</h5>
                  </div>
                  <div class="card-body">
                      <?php if (empty($veiculosEstacionados)): ?>
                          <p class="text-center text-muted">Não há veículos estacionados no momento.</p>
                      <?php else: ?>
                          <div class="table-responsive">
                              <table class="table table-striped table-hover">
                                  <thead>
                                      <tr>
                                          <th>Placa</th>
                                          <th>Modelo/Cor</th>
                                          <th>Proprietário</th>
                                          <th>Entrada</th>
                                          <th>Permanência</th>
                                          <th>Tipo</th>
                                          <th>Ações</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php foreach ($veiculosEstacionados as $veiculo): ?>
                                          <?php
                                          $duracao = calculateDuration($veiculo['data_entrada']);
                                          $duracaoFormatada = $duracao['hours'] . 'h ' . $duracao['minutes'] . 'min';
                                          ?>
                                          <tr>
                                              <td><?php echo $veiculo['placa']; ?></td>
                                              <td><?php echo $veiculo['modelo'] . ' / ' . $veiculo['cor']; ?></td>
                                              <td><?php echo $veiculo['proprietario']; ?></td>
                                              <td><?php echo formatDateTime($veiculo['data_entrada']); ?></td>
                                              <td><?php echo $duracaoFormatada; ?></td>
                                              <td>
                                                  <?php
                                                  $tipoServico = $veiculo['servico_tipo'];
                                                  $badgeClass = 'bg-secondary';
                                                  
                                                  if ($tipoServico == 'hora') {
                                                      $badgeClass = 'bg-info';
                                                  } elseif ($tipoServico == 'diaria') {
                                                      $badgeClass = 'bg-primary';
                                                  } elseif ($tipoServico == 'mensalista') {
                                                      $badgeClass = 'bg-success';
                                                  }
                                                  ?>
                                                  <span class="badge <?php echo $badgeClass; ?>">
                                                      <?php echo ucfirst($tipoServico); ?>
                                                  </span>
                                              </td>
                                              <td>
                                                  <a href="?page=saida&id=<?php echo $veiculo['id']; ?>" class="btn btn-sm btn-warning">
                                                      <i class="fas fa-sign-out-alt me-1"></i> Saída
                                                  </a>
                                              </td>
                                          </tr>
                                      <?php endforeach; ?>
                                  </tbody>
                              </table>
                          </div>
                      <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  <?php endif; ?>
</div>

