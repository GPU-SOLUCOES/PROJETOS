<?php
// Verificar permissões
if ($_SESSION['user_type'] != 'admin') {
    echo '<div class="alert alert-danger">Você não tem permissão para acessar esta página.</div>';
    exit;
}

// Obter o cliente atual
$clienteId = $_SESSION['cliente_id'] ?? null;

if (!$clienteId) {
    echo '<div class="alert alert-danger">Cliente não identificado.</div>';
    exit;
}

// Obter configurações atuais
$sql = "SELECT * FROM configuracoes WHERE cliente_id = ?";
$configuracoes = fetchOne($sql, [$clienteId]);

// Se não existir configuração, criar uma padrão
if (!$configuracoes) {
    $dadosConfig = [
        'cliente_id' => $clienteId,
        'cor_primaria' => '#007bff',
        'cor_secundaria' => '#6c757d',
        'cor_destaque' => '#ffc107',
        'logo' => '',
        'mensagem_ticket' => 'Obrigado por utilizar nosso estacionamento!',
        'exibir_logo_ticket' => 1
    ];
    
    $configId = insert('configuracoes', $dadosConfig);
    
    if ($configId) {
        $configuracoes = $dadosConfig;
        $configuracoes['id'] = $configId;
    }
}

// Processar formulário
$mensagem = '';
$tipoMensagem = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $corPrimaria = sanitizeInput($_POST['cor_primaria'] ?? '#007bff');
    $corSecundaria = sanitizeInput($_POST['cor_secundaria'] ?? '#6c757d');
    $corDestaque = sanitizeInput($_POST['cor_destaque'] ?? '#ffc107');
    $mensagemTicket = sanitizeInput($_POST['mensagem_ticket'] ?? '');
    $exibirLogoTicket = isset($_POST['exibir_logo_ticket']) ? 1 : 0;
    
    // Processar upload de logo
    $logo = $configuracoes['logo'] ?? '';
    
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $uploadDir = 'uploads/logos/';
        
        // Criar diretório se não existir
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = $clienteId . '_' . time() . '_' . basename($_FILES['logo']['name']);
        $uploadFile = $uploadDir . $fileName;
        
        // Verificar tipo de arquivo
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileType = $_FILES['logo']['type'];
        
        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                $logo = $uploadFile;
            } else {
                $mensagem = 'Erro ao fazer upload da logo.';
                $tipoMensagem = 'danger';
            }
        } else {
            $mensagem = 'Tipo de arquivo não permitido. Use apenas JPG, PNG ou GIF.';
            $tipoMensagem = 'danger';
        }
    }
    
    // Atualizar configurações
    $dadosConfig = [
        'cor_primaria' => $corPrimaria,
        'cor_secundaria' => $corSecundaria,
        'cor_destaque' => $corDestaque,
        'mensagem_ticket' => $mensagemTicket,
        'exibir_logo_ticket' => $exibirLogoTicket
    ];
    
    // Adicionar logo apenas se foi feito upload
    if (!empty($logo)) {
        $dadosConfig['logo'] = $logo;
    }
    
    if (isset($configuracoes['id'])) {
        // Atualizar configuração existente
        $resultado = update('configuracoes', $dadosConfig, 'id = ?', [$configuracoes['id']]);
    } else {
        // Criar nova configuração
        $dadosConfig['cliente_id'] = $clienteId;
        $configId = insert('configuracoes', $dadosConfig);
        $resultado = $configId > 0;
    }
    
    if ($resultado) {
        $mensagem = 'Configurações atualizadas com sucesso!';
        $tipoMensagem = 'success';
        
        // Atualizar dados para exibição
        $sql = "SELECT * FROM configuracoes WHERE cliente_id = ?";
        $configuracoes = fetchOne($sql, [$clienteId]);
    } else {
        $mensagem = 'Erro ao atualizar configurações.';
        $tipoMensagem = 'danger';
    }
}

// Obter dados do cliente
$sql = "SELECT * FROM clientes WHERE id = ?";
$cliente = fetchOne($sql, [$clienteId]);
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Configurações do Sistema</h2>
            <p class="text-muted">Personalize a aparência e comportamento do sistema.</p>
        </div>
    </div>
    
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>" role="alert">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Personalização</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-4">
                            <h6>Cores do Sistema</h6>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="cor_primaria" class="form-label">Cor Primária</label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color" id="cor_primaria" name="cor_primaria" value="<?php echo $configuracoes['cor_primaria'] ?? '#007bff'; ?>">
                                        <input type="text" class="form-control" id="cor_primaria_text" value="<?php echo $configuracoes['cor_primaria'] ?? '#007bff'; ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="cor_secundaria" class="form-label">Cor Secundária</label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color" id="cor_secundaria" name="cor_secundaria" value="<?php echo $configuracoes['cor_secundaria'] ?? '#6c757d'; ?>">
                                        <input type="text" class="form-control" id="cor_secundaria_text" value="<?php echo $configuracoes['cor_secundaria'] ?? '#6c757d'; ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <label for="cor_destaque" class="form-label">Cor de Destaque</label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color" id="cor_destaque" name="cor_destaque" value="<?php echo $configuracoes['cor_destaque'] ?? '#ffc107'; ?>">
                                        <input type="text" class="form-control" id="cor_destaque_text" value="<?php echo $configuracoes['cor_destaque'] ?? '#ffc107'; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="mb-4">
                            <h6>Logo</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <label for="logo" class="form-label">Upload de Logo</label>
                                    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                                    <small class="form-text text-muted">Formatos aceitos: JPG, PNG, GIF. Tamanho máximo: 2MB.</small>
                                </div>
                                
                                <div class="col-md-4">
                                    <?php if (!empty($configuracoes['logo'])): ?>
                                        <div class="text-center">
                                            <p>Logo atual:</p>
                                            <img src="<?php echo $configuracoes['logo']; ?>" alt="Logo" class="img-thumbnail" style="max-height: 100px;">
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center">
                                            <p>Nenhuma logo definida</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="mb-4">
                            <h6>Configurações de Ticket/Recibo</h6>
                            <div class="mb-3">
                                <label for="mensagem_ticket" class="form-label">Mensagem no Ticket</label>
                                <textarea class="form-control" id="mensagem_ticket" name="mensagem_ticket" rows="2"><?php echo $configuracoes['mensagem_ticket'] ?? 'Obrigado por utilizar nosso estacionamento!'; ?></textarea>
                                <small class="form-text text-muted">Esta mensagem será exibida no recibo de pagamento.</small>
                            </div>
                            
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="exibir_logo_ticket" name="exibir_logo_ticket" <?php echo (isset($configuracoes['exibir_logo_ticket']) && $configuracoes['exibir_logo_ticket']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="exibir_logo_ticket">
                                    Exibir logo no ticket
                                </label>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i> Salvar Configurações
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Informações do Cliente</h5>
                </div>
                <div class="card-body">
                    <p><strong>Nome:</strong> <?php echo $cliente['nome'] ?? 'N/A'; ?></p>
                    <p><strong>Endereço:</strong> <?php echo $cliente['endereco'] ?? 'N/A'; ?></p>
                    <p><strong>Telefone:</strong> <?php echo $cliente['telefone'] ?? 'N/A'; ?></p>
                    <p><strong>Email:</strong> <?php echo $cliente['email'] ?? 'N/A'; ?></p>
                    
                    <hr>
                    
                    <div class="d-grid">
                        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalEditarCliente">
                            <i class="fas fa-edit me-2"></i> Editar Informações
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Visualização</h5>
                </div>
                <div class="card-body">
                    <p>Veja como as cores selecionadas afetam a aparência do sistema:</p>
                    
                    <div id="previewContainer" class="border rounded p-3 mb-3">
                        <div id="previewHeader" class="p-2 text-white mb-3" style="background-color: <?php echo $configuracoes['cor_primaria'] ?? '#007bff'; ?>;">
                            <h6 class="mb-0">Cabeçalho do Sistema</h6>
                        </div>
                        
                        <div class="mb-3">
                            <button id="previewButton" class="btn" style="background-color: <?php echo $configuracoes['cor_primaria'] ?? '#007bff'; ?>; color: white;">
                                Botão Primário
                            </button>
                            <button id="previewButtonSecondary" class="btn" style="background-color: <?php echo $configuracoes['cor_secundaria'] ?? '#6c757d'; ?>; color: white;">
                                Botão Secundário
                            </button>
                        </div>
                        
                        <div id="previewAlert" class="p-2 mb-3" style="background-color: <?php echo $configuracoes['cor_destaque'] ?? '#ffc107'; ?>; color: black;">
                            <small>Elemento de Destaque</small>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i> As alterações de cores serão aplicadas após salvar e recarregar a página.
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal de Edição de Cliente -->
    <div class="modal fade" id="modalEditarCliente" tabindex="-1" aria-labelledby="modalEditarClienteLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditarClienteLabel">Editar Informações do Cliente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form method="POST" action="ajax/editar_cliente.php">
                    <div class="modal-body">
                        <input type="hidden" name="cliente_id" value="<?php echo $clienteId; ?>">
                        
                        <div class="mb-3">
                            <label for="nome_cliente" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="nome_cliente" name="nome" value="<?php echo $cliente['nome'] ?? ''; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="endereco_cliente" class="form-label">Endereço</label>
                            <input type="text" class="form-control" id="endereco_cliente" name="endereco" value="<?php echo $cliente['endereco'] ?? ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="telefone_cliente" class="form-label">Telefone</label>
                            <input type="text" class="form-control" id="telefone_cliente" name="telefone" value="<?php echo $cliente['telefone'] ?? ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="email_cliente" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email_cliente" name="email" value="<?php echo $cliente['email'] ?? ''; ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Sincronizar inputs de cor
    document.getElementById('cor_primaria').addEventListener('input', function(e) {
        document.getElementById('cor_primaria_text').value = e.target.value;
        updatePreview();
    });
    
    document.getElementById('cor_primaria_text').addEventListener('input', function(e) {
        document.getElementById('cor_primaria').value = e.target.value;
        updatePreview();
    });
    
    document.getElementById('cor_secundaria').addEventListener('input', function(e) {
        document.getElementById('cor_secundaria_text').value = e.target.value;
        updatePreview();
    });
    
    document.getElementById('cor_secundaria_text').addEventListener('input', function(e) {
        document.getElementById('cor_secundaria').value = e.target.value;
        updatePreview();
    });
    
    document.getElementById('cor_destaque').addEventListener('input', function(e) {
        document.getElementById('cor_destaque_text').value = e.target.value;
        updatePreview();
    });
    
    document.getElementById('cor_destaque_text').addEventListener('input', function(e) {
        document.getElementById('cor_destaque').value = e.target.value;
        updatePreview();
    });
    
    // Atualizar preview
    function updatePreview() {
        const corPrimaria = document.getElementById('cor_primaria').value;
        const corSecundaria = document.getElementById('cor_secundaria').value;
        const corDestaque = document.getElementById('cor_destaque').value;
        
        document.getElementById('previewHeader').style.backgroundColor = corPrimaria;
        document.getElementById('previewButton').style.backgroundColor = corPrimaria;
        document.getElementById('previewButtonSecondary').style.backgroundColor = corSecundaria;
        document.getElementById('previewAlert').style.backgroundColor = corDestaque;
    }
</script>

