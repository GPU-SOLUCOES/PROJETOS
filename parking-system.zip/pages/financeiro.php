<?php
// Verificar permissões
if ($_SESSION['user_type'] != 'gerente' && $_SESSION['user_type'] != 'admin') {
  echo '<div class="alert alert-danger">Você não tem permissão para acessar esta página.</div>';
  exit;
}

// Obter o estacionamento atual
$estacionamentoId = $_SESSION['estacionamento_id'] ?? null;

if (!$estacionamentoId) {
  echo '<div class="alert alert-warning">Selecione um estacionamento para visualizar os relatórios financeiros.</div>';
  exit;
}

// Definir período padrão (últimos 30 dias)
$dataFim = date('Y-m-d');
$dataInicio = date('Y-m-d', strtotime('-30 days'));

// Processar filtros
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['filtrar'])) {
  $dataInicio = $_GET['data_inicio'] ?? $dataInicio;
  $dataFim = $_GET['data_fim'] ?? $dataFim;
}

// Obter dados financeiros
$sql = "SELECT 
          DATE(data_saida) as data,
          COUNT(*) as total_veiculos,
          SUM(valor_pago) as total_faturado,
          forma_pagamento
      FROM 
          registros
      WHERE 
          estacionamento_id = ? AND 
          data_saida IS NOT NULL AND
          DATE(data_saida) BETWEEN ? AND ?
      GROUP BY 
          DATE(data_saida), forma_pagamento
      ORDER BY 
          data DESC";

$dadosFinanceiros = fetchAll($sql, [$estacionamentoId, $dataInicio, $dataFim]);

// Processar dados para gráficos
$datasGrafico = [];
$valoresGrafico = [];
$totalPeriodo = 0;
$totalVeiculos = 0;
$dadosPorFormaPagamento = [
  'dinheiro' => 0,
  'cartao_credito' => 0,
  'cartao_debito' => 0,
  'pix' => 0,
  'mensalidade' => 0
];

$dadosPorData = [];

foreach ($dadosFinanceiros as $dado) {
  $data = $dado['data'];
  $valor = floatval($dado['total_faturado']);
  $veiculos = intval($dado['total_veiculos']);
  $formaPagamento = $dado['forma_pagamento'];
  
  // Acumular totais
  $totalPeriodo += $valor;
  $totalVeiculos += $veiculos;
  
  // Acumular por forma de pagamento
  if (isset($dadosPorFormaPagamento[$formaPagamento])) {
      $dadosPorFormaPagamento[$formaPagamento] += $valor;
  }
  
  // Agrupar por data para o gráfico
  if (!isset($dadosPorData[$data])) {
      $dadosPorData[$data] = 0;
  }
  
  $dadosPorData[$data] += $valor;
}

// Preparar dados para o gráfico
foreach ($dadosPorData as $data => $valor) {
  $datasGrafico[] = date('d/m/Y', strtotime($data));
  $valoresGrafico[] = $valor;
}

// Obter dados por tipo de serviço
$sql = "SELECT 
          s.tipo,
          COUNT(*) as total_veiculos,
          SUM(r.valor_pago) as total_faturado
      FROM 
          registros r
      JOIN 
          servicos s ON r.servico_id = s.id
      WHERE 
          r.estacionamento_id = ? AND 
          r.data_saida IS NOT NULL AND
          DATE(r.data_saida) BETWEEN ? AND ?
      GROUP BY 
          s.tipo";

$dadosPorServico = fetchAll($sql, [$estacionamentoId, $dataInicio, $dataFim]);

// Obter nome do estacionamento
$sql = "SELECT nome FROM estacionamentos WHERE id = ?";
$estacionamento = fetchOne($sql, [$estacionamentoId]);
$nomeEstacionamento = $estacionamento ? $estacionamento['nome'] : 'Estacionamento';
?>

<div class="container-fluid py-4">
  <div class="row mb-4">
      <div class="col-12">
          <h2>Relatório Financeiro</h2>
          <p class="text-muted">Estacionamento: <?php echo $nomeEstacionamento; ?></p>
      </div>
  </div>
  
  <!-- Filtros -->
  <div class="row mb-4">
      <div class="col-12">
          <div class="card">
              <div class="card-body">
                  <form method="GET" action="" class="row g-3 align-items-end">
                      <input type="hidden" name="page" value="financeiro">
                      <input type="hidden" name="filtrar" value="1">
                      
                      <div class="col-md-4">
                          <label for="data_inicio" class="form-label">Data Inicial</label>
                          <input type="date" class="form-control" id="data_inicio" name="data_inicio" value="<?php echo $dataInicio; ?>">
                      </div>
                      
                      <div class="col-md-4">
                          <label for="data_fim" class="form-label">Data Final</label>
                          <input type="date" class="form-control" id="data_fim" name="data_fim" value="<?php echo $dataFim; ?>">
                      </div>
                      
                      <div class="col-md-4">
                          <button type="submit" class="btn btn-primary w-100">
                              <i class="fas fa-filter me-2"></i> Filtrar
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      </div>
  </div>
  
  <!-- Cards de resumo -->
  <div class="row mb-4">
      <div class="col-md-4">
          <div class="card bg-primary text-white">
              <div class="card-body">
                  <h5 class="card-title">Faturamento Total</h5>
                  <h2 class="display-4">R$ <?php echo number_format($totalPeriodo, 2, ',', '.'); ?></h2>
                  <p class="card-text">Período: <?php echo date('d/m/Y', strtotime($dataInicio)) . ' a ' . date('d/m/Y', strtotime($dataFim)); ?></p>
              </div>
          </div>
      </div>
      
      <div class="col-md-4">
          <div class="card bg-success text-white">
              <div class="card-body">
                  <h5 class="card-title">Veículos Atendidos</h5>
                  <h2 class="display-4"><?php echo $totalVeiculos; ?></h2>
                  <p class="card-text">Ticket médio: R$ <?php echo $totalVeiculos > 0 ? number_format($totalPeriodo / $totalVeiculos, 2, ',', '.') : '0,00'; ?></p>
              </div>
          </div>
      </div>
      
      <div class="col-md-4">
          <div class="card bg-info text-white">
              <div class="card-body">
                  <h5 class="card-title">Média Diária</h5>
                  <?php
                  $diasPeriodo = max(1, (strtotime($dataFim) - strtotime($dataInicio)) / (60 * 60 * 24) + 1);
                  $mediaDiaria = $totalPeriodo / $diasPeriodo;
                  ?>
                  <h2 class="display-4">R$ <?php echo number_format($mediaDiaria, 2, ',', '.'); ?></h2>
                  <p class="card-text">Baseado em <?php echo round($diasPeriodo); ?> dias</p>
              </div>
          </div>
      </div>
  </div>
  
  <!-- Gráfico de faturamento -->
  <div class="row mb-4">
      <div class="col-12">
          <div class="card">
              <div class="card-header bg-light">
                  <h5 class="mb-0">Faturamento por Dia</h5>
              </div>
              <div class="card-body">
                  <canvas id="graficoFaturamento" height="100"></canvas>
              </div>
          </div>
      </div>
  </div>
  
  <!-- Gráficos de análise -->
  <div class="row mb-4">
      <div class="col-md-6">
          <div class="card">
              <div class="card-header bg-light">
                  <h5 class="mb-0">Faturamento por Forma de Pagamento</h5>
              </div>
              <div class="card-body">
                  <canvas id="graficoPagamentos" height="200"></canvas>
              </div>
          </div>
      </div>
      
      <div class="col-md-6">
          <div class="card">
              <div class="card-header bg-light">
                  <h5 class="mb-0">Faturamento por Tipo de Serviço</h5>
              </div>
              <div class="card-body">
                  <canvas id="graficoServicos" height="200"></canvas>
              </div>
          </div>
      </div>
  </div>
  
  <!-- Tabela detalhada -->
  <div class="row">
      <div class="col-12">
          <div class="card">
              <div class="card-header bg-light d-flex justify-content-between align-items-center">
                  <h5 class="mb-0">Detalhamento por Dia</h5>
                  <button type="button" class="btn btn-sm btn-outline-primary" id="btnExportar">
                      <i class="fas fa-file-export me-1"></i> Exportar
                  </button>
              </div>
              <div class="card-body">
                  <div class="table-responsive">
                      <table class="table table-striped table-hover" id="tabelaFinanceiro">
                          <thead>
                              <tr>
                                  <th>Data</th>
                                  <th>Veículos</th>
                                  <th>Faturamento</th>
                                  <th>Forma de Pagamento</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php foreach ($dadosFinanceiros as $dado): ?>
                                  <tr>
                                      <td><?php echo date('d/m/Y', strtotime($dado['data'])); ?></td>
                                      <td><?php echo $dado['total_veiculos']; ?></td>
                                      <td>R$ <?php echo number_format($dado['total_faturado'], 2, ',', '.'); ?></td>
                                      <td>
                                          <?php
                                          $formaPagamento = $dado['forma_pagamento'];
                                          $badgeClass = 'bg-secondary';
                                          $formaPagamentoTexto = 'Outro';
                                          
                                          if ($formaPagamento == 'dinheiro') {
                                              $badgeClass = 'bg-success';
                                              $formaPagamentoTexto = 'Dinheiro';
                                          } elseif ($formaPagamento == 'cartao_credito') {
                                              $badgeClass = 'bg-primary';
                                              $formaPagamentoTexto = 'Cartão de Crédito';
                                          } elseif ($formaPagamento == 'cartao_debito') {
                                              $badgeClass = 'bg-info';
                                              $formaPagamentoTexto = 'Cartão de Débito';
                                          } elseif ($formaPagamento == 'pix') {
                                              $badgeClass = 'bg-warning';
                                              $formaPagamentoTexto = 'PIX';
                                          } elseif ($formaPagamento == 'mensalidade') {
                                              $badgeClass = 'bg-dark';
                                              $formaPagamentoTexto = 'Mensalidade';
                                          }
                                          ?>
                                          <span class="badge <?php echo $badgeClass; ?>">
                                              <?php echo $formaPagamentoTexto; ?>
                                          </span>
                                      </td>
                                  </tr>
                              <?php endforeach; ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<script>
  // Gráfico de faturamento por dia
  const ctxFaturamento = document.getElementById('graficoFaturamento').getContext('2d');
  const graficoFaturamento = new Chart(ctxFaturamento, {
      type: 'line',
      data: {
          labels: <?php echo json_encode($datasGrafico); ?>,
          datasets: [{
              label: 'Faturamento (R$)',
              data: <?php echo json_encode($valoresGrafico); ?>,
              backgroundColor: 'rgba(54, 162, 235, 0.2)',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              tension: 0.1
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true,
                  ticks: {
                      callback: function(value) {
                          return 'R$ ' + value.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                      }
                  }
              }
          },
          plugins: {
              tooltip: {
                  callbacks: {
                      label: function(context) {
                          return 'R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                      }
                  }
              }
          }
      }
  });
  
  // Gráfico de formas de pagamento
  const ctxPagamentos = document.getElementById('graficoPagamentos').getContext('2d');
  const graficoPagamentos = new Chart(ctxPagamentos, {
      type: 'pie',
      data: {
          labels: ['Dinheiro', 'Cartão de Crédito', 'Cartão de Débito', 'PIX', 'Mensalidade'],
          datasets: [{
              data: [
                  <?php echo $dadosPorFormaPagamento['dinheiro']; ?>,
                  <?php echo $dadosPorFormaPagamento['cartao_credito']; ?>,
                  <?php echo $dadosPorFormaPagamento['cartao_debito']; ?>,
                  <?php echo $dadosPorFormaPagamento['pix']; ?>,
                  <?php echo $dadosPorFormaPagamento['mensalidade']; ?>
              ],
              backgroundColor: [
                  'rgba(40, 167, 69, 0.7)',
                  'rgba(0, 123, 255, 0.7)',
                  'rgba(23, 162, 184, 0.7)',
                  'rgba(255, 193, 7, 0.7)',
                  'rgba(52, 58, 64, 0.7)'
              ],
              borderWidth: 1
          }]
      },
      options: {
          responsive: true,
          plugins: {
              tooltip: {
                  callbacks: {
                      label: function(context) {
                          const value = context.raw;
                          const total = context.dataset.data.reduce((a, b) => a + b, 0);
                          const percentage = ((value / total) * 100).toFixed(1);
                          return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${percentage}%)`;
                      }
                  }
              }
          }
      }
  });
  
  // Gráfico de tipos de serviço
  const ctxServicos = document.getElementById('graficoServicos').getContext('2d');
  const graficoServicos = new Chart(ctxServicos, {
      type: 'bar',
      data: {
          labels: [
              <?php 
              foreach ($dadosPorServico as $servico) {
                  $tipo = $servico['tipo'];
                  if ($tipo == 'hora') {
                      echo "'Por Hora', ";
                  } elseif ($tipo == 'diaria') {
                      echo "'Diária', ";
                  } elseif ($tipo == 'mensalista') {
                      echo "'Mensalista', ";
                  } else {
                      echo "'" . ucfirst($tipo) . "', ";
                  }
              }
              ?>
          ],
          datasets: [{
              label: 'Faturamento (R$)',
              data: [
                  <?php 
                  foreach ($dadosPorServico as $servico) {
                      echo $servico['total_faturado'] . ', ';
                  }
                  ?>
              ],
              backgroundColor: [
                  'rgba(255, 99, 132, 0.7)',
                  'rgba(54, 162, 235, 0.7)',
                  'rgba(255, 206, 86, 0.7)'
              ],
              borderWidth: 1
          }]
      },
      options: {
          responsive: true,
          scales: {
              y: {
                  beginAtZero: true,
                  ticks: {
                      callback: function(value) {
                          return 'R$ ' + value.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                      }
                  }
              }
          },
          plugins: {
              tooltip: {
                  callbacks: {
                      label: function(context) {
                          return 'R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                      }
                  }
              }
          }
      }
  });
  
  // Exportar relatório
  document.getElementById('btnExportar').addEventListener('click', function() {
      // Criar um elemento temporário para download
      const a = document.createElement('a');
      
      // Obter dados da tabela
      const table = document.getElementById('tabelaFinanceiro');
      let csv = 'Data,Veículos,Faturamento,Forma de Pagamento\n';
      
      for (let i = 1; i < table.rows.length; i++) {
          const row = table.rows[i];
          const data = row.cells[0].textContent;
          const veiculos = row.cells[1].textContent;
          const faturamento = row.cells[2].textContent;
          const formaPagamento = row.cells[3].textContent.trim();
          
          csv += `${data},${veiculos},${faturamento},${formaPagamento}\n`;
      }
      
      // Criar blob e link para download
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      
      a.href = url;
      a.download = `relatorio_financeiro_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      
      // Limpar
      setTimeout(function() {
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
      }, 0);
  });
</script>

